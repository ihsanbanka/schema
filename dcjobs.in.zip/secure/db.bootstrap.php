<?php
/**
 * DCJOBS Database Bootstrap Credentials
 * ------------------------------------
 * File: db.bootstrap.php
 * Location: /secure (outside public_html)
 *
 * PURPOSE:
 * - Provide minimal credentials to establish first DB connection
 * - Used ONLY by Database.php bootstrap phase
 *
 * SECURITY:
 * - Never web-accessible
 * - No business logic
 * - Returns array only
 */

return [
    'host'     => 'localhost',
    'database' => 'u969009956_credable',
    'username' => 'u969009956_786credable',
    'password' => '786Dcjobs*',
    'charset'  => 'utf8mb4'
];