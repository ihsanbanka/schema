<?php
declare(strict_types=1);

/**
 * DCJOBS — Job Expiry Email Notifier (CRON)
 * ----------------------------------------
 * File: job_expiry_notifier.php
 * Path: /cron/job_expiry_notifier.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Billing & Entitlement Enforcement
 *
 * Purpose:
 * --------
 * - Notify users when a job posting is nearing expiry
 * - Uses DB-driven email templates
 * - Runs via cron (daily)
 *
 * Governance:
 * -----------
 * ✔ No UI
 * ✔ No session
 * ✔ No CSRF
 * ✔ DB-driven
 * ✔ Shared-hosting safe
 * ✔ Idempotent (email sent only once per job per day)
 */

require_once __DIR__ . '/../app/core/Bootstrap.php';

use DCJOBS\Core\Database;
use DCJOBS\Core\EmailService;
use DCJOBS\Core\Logger;

try {

    $pdo = Database::getConnection();

    /**
     * CONFIG (DB-driven later if needed)
     * ----------------------------------
     * Notify when job expires in N days
     */
    $notifyBeforeDays = 2;

    /**
     * STEP 1: Find active job entitlements expiring soon
     * --------------------------------------------------
     * - Active billing transaction
     * - product_type = post_job
     * - end_date within N days
     * - job still active
     */
    $stmt = $pdo->prepare(
        "
        SELECT
            bt.id            AS billing_id,
            bt.job_id,
            bt.end_date,
            u.email          AS user_email,
            jd.job_title
        FROM billing_transactions bt
        JOIN users u
            ON u.id = bt.user_id
        JOIN job_detail jd
            ON jd.job_id = bt.job_id
        WHERE bt.product_type = 'post_job'
          AND bt.is_active = 1
          AND jd.job_status = 'Active'
          AND DATE(bt.end_date) = DATE(DATE_ADD(NOW(), INTERVAL :days DAY))
        "
    );

    $stmt->execute([':days' => $notifyBeforeDays]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
        exit; // Nothing to notify today
    }

    /**
     * STEP 2: Send emails
     * -------------------
     */
    foreach ($rows as $row) {

        EmailService::send(
            'email.job_expiry',
            $row['user_email'],
            [
                'job_title' => $row['job_title'],
                'expiry_date' => date('d M Y', strtotime($row['end_date']))
            ]
        );

        /**
         * OPTIONAL (future):
         * ------------------
         * Insert into notification_logs table
         * to avoid duplicate reminders if cron runs multiple times a day
         */
    }

} catch (Throwable $e) {

    Logger::error('JOB_EXPIRY_NOTIFIER_FAILED', [
        'error' => $e->getMessage()
    ]);

    // Never echo errors in cron
}
