<?php
declare(strict_types=1);

/**
 * DCJOBS — Job Expiry Auto Closer (CRON)
 * -------------------------------------
 * File: job_expiry_closer.php
 * Path: /cron/job_expiry_closer.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Billing & Entitlement Enforcement
 *
 * Purpose:
 * --------
 * - Automatically deactivate expired job postings
 * - Applies to FREE and PAID jobs
 * - Driven by billing_transactions end_date
 *
 * Governance:
 * -----------
 * ✔ No UI
 * ✔ No sessions
 * ✔ No CSRF
 * ✔ DB-driven
 * ✔ Idempotent
 * ✔ Shared-hosting safe
 */

require_once __DIR__ . '/../app/core/Bootstrap.php';

use DCJOBS\Core\Database;
use DCJOBS\Core\Logger;

try {

    $pdo = Database::getConnection();

    /**
     * STEP 1: Find expired active job entitlements
     * --------------------------------------------
     * Conditions:
     * - product_type = post_job
     * - entitlement expired (end_date < NOW)
     * - entitlement still marked active
     * - job still Active
     */
    $stmt = $pdo->prepare(
        "
        SELECT
            bt.id     AS billing_id,
            bt.job_id
        FROM billing_transactions bt
        JOIN job_detail jd
            ON jd.job_id = bt.job_id
        WHERE bt.product_type = 'post_job'
          AND bt.is_active = 1
          AND bt.end_date < NOW()
          AND jd.job_status = 'Active'
        "
    );

    $stmt->execute();
    $expiredJobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$expiredJobs) {
        exit; // Nothing to close
    }

    /**
     * STEP 2: Close jobs + deactivate entitlement (transaction-safe)
     */
    foreach ($expiredJobs as $row) {

        $pdo->beginTransaction();

        try {
            /* Close job */
            $pdo->prepare(
                "
                UPDATE job_detail
                SET job_status = 'Expired'
                WHERE job_id = :job_id
                "
            )->execute([
                ':job_id' => $row['job_id']
            ]);

            /* Deactivate entitlement */
            $pdo->prepare(
                "
                UPDATE billing_transactions
                SET is_active = 0
                WHERE id = :billing_id
                "
            )->execute([
                ':billing_id' => $row['billing_id']
            ]);

            $pdo->commit();

        } catch (\Throwable $e) {
            $pdo->rollBack();

            Logger::error('JOB_EXPIRY_CLOSE_FAILED', [
                'job_id'     => $row['job_id'],
                'billing_id' => $row['billing_id'],
                'error'      => $e->getMessage()
            ]);
        }
    }

} catch (\Throwable $e) {

    Logger::error('JOB_EXPIRY_CRON_FATAL', [
        'error' => $e->getMessage()
    ]);
}
