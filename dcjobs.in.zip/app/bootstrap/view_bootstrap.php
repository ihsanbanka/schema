<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * -------------------------------------------------
 * File: view_bootstrap.php
 * Path: /app/bootstrap/view_bootstrap.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Component        : View Bootstrap Initializer
 * Phase            : Phase-3 (P3.2)
 *
 * Purpose:
 * --------
 * Initializes the View rendering system.
 *
 * Responsibilities:
 * -----------------
 * - Define views base directory
 * - Initialize View engine
 * - Keep view wiring OUT of core bootstrap
 *
 * Design Principles:
 * ------------------
 * ✔ No hardcoded paths in controllers
 * ✔ Shared hosting safe
 * ✔ Cloud-ready
 * ✔ Single responsibility
 */

declare(strict_types=1);

use DCJOBS\Core\View;

/**
 * Ensure application root is defined
 */
if (!defined('DCJOBS_ROOT')) {
    throw new RuntimeException('DCJOBS_ROOT not defined before View bootstrap');
}

/**
 * Define views directory
 *
 * NOTE:
 * -----
 * This path can later be moved to DB config
 * without changing View.php or controllers.
 */
$viewsPath = DCJOBS_ROOT . '/app/views';

/**
 * Initialize View engine
 */
View::init($viewsPath);
