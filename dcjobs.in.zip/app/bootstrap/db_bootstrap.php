<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: db_bootstrap.php
 * Path: /app/bootstrap/db_bootstrap.php
 *
 * Software Version : DCJOBS-CORE v1.0.1
 * Phase            : Phase-1 (DB Bootstrap – Corrected)
 *
 * Purpose:
 * --------
 * - Define the absolute path to DB credentials file
 * - This file MUST NOT contain credentials directly
 *
 * SECURITY:
 * ---------
 * - Credentials live in a separate file
 * - This file only defines the path
 */

declare(strict_types=1);

/**
 * Absolute path to DB credentials file
 * IMPORTANT: This file MUST return an array
 */
define(
    'DCJOBS_DB_BOOTSTRAP',
    __DIR__ . '/db_credentials.php'
);
