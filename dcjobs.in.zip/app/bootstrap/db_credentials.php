<?php
return [
    'host'     => 'localhost',
    'database' => 'u969009956_credable',
    'username' => 'u969009956_786credable',
    'password' => '786Dcjobs*',
    'charset'  => 'utf8mb4'
];