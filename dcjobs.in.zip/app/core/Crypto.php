<?php
/**
 * DCJOBS-CORE — Encryption Utility
 * --------------------------------------------
 * File: Crypto.php
 * Path: /app/core/Crypto.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Core Security Foundation
 * Component        : Encryption / Decryption Utility
 *
 * PURPOSE:
 * --------
 * - Encrypt sensitive data before database storage
 * - Decrypt sensitive data at runtime (OAuth secrets, tokens)
 *
 * GOVERNANCE:
 * -----------
 * ✔ AES-256-CBC
 * ✔ Random IV per encryption
 * ✔ Base64 encoded payload
 * ✔ Shared-hosting compatible
 * ✔ No external libraries
 * ✔ Fail-fast on misconfiguration
 *
 * SECURITY NOTES:
 * ---------------
 * - Encryption key MUST be 32 bytes (256-bit)
 * - Key must NEVER be stored in DB
 * - Key should come from ENV or Config
 */

declare(strict_types=1);

namespace DCJOBS\Core;

use RuntimeException;

final class Crypto
{
    private const CIPHER = 'AES-256-CBC';

    /**
     * Encrypt plain text
     */
    public static function encrypt(string $plainText): string
    {
        if ($plainText === '') {
            return '';
        }

        $key = self::getKey();

        $ivLength = openssl_cipher_iv_length(self::CIPHER);
        if ($ivLength === false) {
            throw new RuntimeException('Invalid cipher configuration.');
        }

        $iv = random_bytes($ivLength);

        $cipherText = openssl_encrypt(
            $plainText,
            self::CIPHER,
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );

        if ($cipherText === false) {
            throw new RuntimeException('Encryption failed.');
        }

        /**
         * Payload format:
         * base64( IV || CIPHERTEXT )
         */
        return base64_encode($iv . $cipherText);
    }

    /**
     * Decrypt cipher text
     */
    public static function decrypt(string $encrypted): string
    {
        if ($encrypted === '') {
            return '';
        }

        $key = self::getKey();

        $payload = base64_decode($encrypted, true);
        if ($payload === false) {
            throw new RuntimeException('Invalid encrypted payload.');
        }

        $ivLength = openssl_cipher_iv_length(self::CIPHER);
        if ($ivLength === false || strlen($payload) <= $ivLength) {
            throw new RuntimeException('Invalid encrypted data structure.');
        }

        $iv         = substr($payload, 0, $ivLength);
        $cipherText = substr($payload, $ivLength);

        $plainText = openssl_decrypt(
            $cipherText,
            self::CIPHER,
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );

        if ($plainText === false) {
            throw new RuntimeException('Decryption failed.');
        }

        return $plainText;
    }

    /**
     * Resolve encryption key securely
     */
    private static function getKey(): string
    {
        // Priority 1: ENV
        $key = $_ENV['DCJOBS_APP_KEY'] ?? getenv('DCJOBS_APP_KEY');

        // Priority 2: Config
        if (!$key && class_exists(Config::class)) {
            Config::load();
            $key = Config::get('security.app_key');
        }

        if (!$key) {
            throw new RuntimeException(
                'Encryption key missing. Set DCJOBS_APP_KEY in environment or config.'
            );
        }

        // Normalize key to 32 bytes
        $binaryKey = hash('sha256', $key, true);

        if (strlen($binaryKey) !== 32) {
            throw new RuntimeException('Invalid encryption key length.');
        }

        return $binaryKey;
    }

    /**
     * Disallow instantiation
     */
    private function __construct()
    {
    }
}
