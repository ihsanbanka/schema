<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: Router.php
 * Path: /app/core/Router.php
 *
 * Software Version : DCJOBS-CORE v2.5.0
 * Phase            : Phase-3.8 (Hardened Dynamic Routing)
 *
 * Purpose:
 * --------
 * - Match incoming HTTP request using DB routes
 * - Support secure dynamic routes (/verify/{token}, /reset/{token})
 * - Dispatch controller actions deterministically
 *
 * Governance:
 * -----------
 * ✔ No debug output
 * ✔ No hardcoded routes
 * ✔ DB-driven only
 * ✔ Token-safe dynamic dispatch
 * ✔ Shared-hosting compatible
 */

declare(strict_types=1);

namespace DCJOBS\Core;

use PDO;
use RuntimeException;

final class Router
{
    /**
     * Dispatch the current HTTP request.
     */
    public static function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $uri    = self::normalizeUri($_SERVER['REQUEST_URI'] ?? '/');

        $route = self::matchRoute($method, $uri);

        if ($route === null) {
            http_response_code(404);
            echo '404 Not Found';
            return;
        }

        self::dispatchController($route);
    }

    /**
     * Normalize URI (strip query string, trailing slash).
     */
    private static function normalizeUri(string $uri): string
    {
        $path = parse_url($uri, PHP_URL_PATH) ?? '/';
        return rtrim($path, '/') ?: '/';
    }

    /**
     * Match route from database.
     *
     * Priority:
     * 1) Exact match (/login, /reset-password)
     * 2) Token-based dynamic match (/verify/{token}, /reset/{token})
     */
    private static function matchRoute(string $method, string $uri): ?array
    {
        $pdo = Database::getConnection();

        /* =========================================================
           1️⃣ EXACT MATCH (HIGHEST PRIORITY)
           ========================================================= */
        $stmt = $pdo->prepare(
            'SELECT *
             FROM app_routes
             WHERE http_method = :method
               AND route_path  = :path
               AND is_active   = 1
             ORDER BY priority ASC
             LIMIT 1'
        );

        $stmt->execute([
            ':method' => $method,
            ':path'   => $uri
        ]);

        $route = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($route) {
            return $route;
        }

        /* =========================================================
           2️⃣ DYNAMIC TOKEN ROUTES
           Matches: /verify/{token}, /reset/{token}
           ========================================================= */
        $stmt = $pdo->prepare(
            'SELECT *
             FROM app_routes
             WHERE http_method = :method
               AND is_active   = 1
               AND :path LIKE CONCAT(route_path, "/%")
             ORDER BY LENGTH(route_path) DESC, priority ASC
             LIMIT 1'
        );

        $stmt->execute([
            ':method' => $method,
            ':path'   => $uri
        ]);

        $route = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$route) {
            return null;
        }

        /**
         * Extract token safely
         */
        $base = $route['route_path'] . '/';
        if (!str_starts_with($uri, $base)) {
            return null;
        }

        $token = substr($uri, strlen($base));

        // Token must be non-empty and sane
        if ($token === '' || strlen($token) < 20) {
            return null;
        }

        $route['__param'] = $token;
        return $route;
    }

    /**
     * Dispatch controller + action.
     */
    private static function dispatchController(array $route): void
    {
        $controllerClass = $route['controller'];
        $action          = $route['action'];

        if (!class_exists($controllerClass)) {
            throw new RuntimeException(
                'Controller not found: ' . $controllerClass
            );
        }

        $controller = new $controllerClass();

        if (!method_exists($controller, $action)) {
            throw new RuntimeException(
                'Action not found: ' . $action
            );
        }

        // Pass token if dynamic
        if (isset($route['__param'])) {
            $controller->{$action}($route['__param']);
            return;
        }

        $controller->{$action}();
    }
}
