<?php
declare(strict_types=1);

/**
 * DCJOBS — Stripe Service (Production)
 * -----------------------------------
 * File: StripeService.php
 * Path: /app/core/StripeService.php
 *
 * Software Version : DCJOBS-CORE v1.2.0
 * Phase            : Payments & Billing (Option A)
 *
 * Purpose:
 * --------
 * - Centralized Stripe Checkout Session creation
 * - NO DB writes here
 * - Metadata-driven (job_id, user_id, plan_id)
 * - Used by PostJobController
 *
 * GOVERNANCE:
 * -----------
 * ✔ No hardcoding
 * ✔ DB = source of truth (amount already resolved)
 * ✔ Webhook is authoritative
 * ✔ Shared hosting safe
 */

namespace DCJOBS\Core;

use RuntimeException;

final class StripeService
{
    /**
     * Create Stripe Checkout Session
     *
     * @param array{
     *   amount: float,
     *   currency: string,
     *   metadata: array<string,string>,
     *   success_url: string,
     *   cancel_url: string
     * } $data
     *
     * @return string Redirect URL to Stripe Checkout
     */
    public static function createCheckoutSession(array $data): string
    {
        /* -----------------------------------------
           VALIDATION (DEFENSIVE)
        ----------------------------------------- */
        if (empty($data['amount']) || $data['amount'] <= 0) {
            throw new RuntimeException('Invalid Stripe amount');
        }

        if (empty($data['currency'])) {
            throw new RuntimeException('Currency not provided');
        }

        if (empty($data['success_url']) || empty($data['cancel_url'])) {
            throw new RuntimeException('Redirect URLs missing');
        }

        /* -----------------------------------------
           LOAD STRIPE CONFIG (DB-DRIVEN)
        ----------------------------------------- */
        $secretKey = Config::get('stripe_secret_key');

        if (empty($secretKey)) {
            throw new RuntimeException('Stripe secret key not configured');
        }

        /* -----------------------------------------
           STRIPE SDK LOAD (NO AUTOLOADER ASSUMED)
        ----------------------------------------- */
        if (!class_exists('\Stripe\Stripe')) {
            require_once DCJOBS_ROOT . '/vendor/stripe/stripe-php/init.php';
        }

        \Stripe\Stripe::setApiKey($secretKey);

        /* -----------------------------------------
           BUILD CHECKOUT SESSION
        ----------------------------------------- */
        $session = \Stripe\Checkout\Session::create([
            'mode' => 'payment',

            'payment_method_types' => ['card'],

            'line_items' => [[
                'price_data' => [
                    'currency' => strtolower($data['currency']),
                    'product_data' => [
                        'name' => 'DCJOBS Job Posting',
                    ],
                    'unit_amount' => (int) round($data['amount'] * 100), // paise
                ],
                'quantity' => 1,
            ]],

            'metadata' => $data['metadata'] ?? [],

            'success_url' => $data['success_url'],
            'cancel_url'  => $data['cancel_url'],

            /* -------------------------------------
               IMPORTANT SAFETY FLAGS
            ------------------------------------- */
            'allow_promotion_codes' => false,
            'billing_address_collection' => 'auto',
        ]);

        if (empty($session->url)) {
            throw new RuntimeException('Stripe session URL not generated');
        }

        return $session->url;
    }
}
