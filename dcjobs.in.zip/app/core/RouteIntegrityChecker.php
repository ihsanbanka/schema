<?php
/**
 * DCJOBS-CORE — Route vs Controller Integrity Checker
 * --------------------------------------------------
 * File: RouteIntegrityChecker.php
 * Path: /app/core/RouteIntegrityChecker.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7 (Developer Safety Net)
 *
 * Purpose:
 * --------
 * - Validate DB routes against actual controllers & methods
 * - Detect missing controller classes
 * - Detect missing controller actions
 * - Prevent runtime "Action not found" failures
 *
 * Governance:
 * -----------
 * ✔ READ-ONLY
 * ✔ No DB writes
 * ✔ No routing changes
 * ✔ No autoload hacks
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Core;

use PDO;
use ReflectionClass;
use Throwable;

final class RouteIntegrityChecker
{
    /**
     * Run full integrity check.
     *
     * @return array
     */
    public static function check(): array
    {
        $pdo = Database::getConnection();

        $stmt = $pdo->query(
            'SELECT id, http_method, route_path, controller, action
             FROM app_routes
             WHERE is_active = 1
             ORDER BY id ASC'
        );

        $results = [];

        while ($route = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = self::checkRoute($route);
        }

        return $results;
    }

    /**
     * Check a single route definition.
     *
     * @param array $route
     * @return array
     */
    private static function checkRoute(array $route): array
    {
        $controllerClass = $route['controller'];
        $action          = $route['action'];

        $status  = 'OK';
        $details = 'Valid';

        try {
            if (!class_exists($controllerClass)) {
                return self::fail(
                    $route,
                    'CONTROLLER_MISSING',
                    'Controller class not found'
                );
            }

            $ref = new ReflectionClass($controllerClass);

            if (!$ref->hasMethod($action)) {
                return self::fail(
                    $route,
                    'ACTION_MISSING',
                    'Method does not exist in controller'
                );
            }

            if (!$ref->getMethod($action)->isPublic()) {
                return self::fail(
                    $route,
                    'ACTION_NOT_PUBLIC',
                    'Method exists but is not public'
                );
            }

        } catch (Throwable $e) {
            return self::fail(
                $route,
                'REFLECTION_ERROR',
                $e->getMessage()
            );
        }

        return [
            'route_id'   => $route['id'],
            'method'     => $route['http_method'],
            'path'       => $route['route_path'],
            'controller' => $controllerClass,
            'action'     => $action,
            'status'     => $status,
            'details'    => $details
        ];
    }

    /**
     * Build failure response.
     *
     * @param array  $route
     * @param string $status
     * @param string $details
     * @return array
     */
    private static function fail(array $route, string $status, string $details): array
    {
        return [
            'route_id'   => $route['id'],
            'method'     => $route['http_method'],
            'path'       => $route['route_path'],
            'controller' => $route['controller'],
            'action'     => $route['action'],
            'status'     => $status,
            'details'    => $details
        ];
    }
}
