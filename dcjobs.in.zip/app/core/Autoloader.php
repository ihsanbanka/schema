<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: Autoloader.php
 * Path: /app/core/Autoloader.php
 *
 * Software Version : DCJOBS-CORE v2.4.2
 * Phase            : Phase-4.3 (Autoload Diagnostics ENABLED)
 */

declare(strict_types=1);

namespace DCJOBS\Core;

/**
 * 🔍 AUTOLoader diagnostics:
 * - Logs when autoloader is REGISTERED
 * - Logs every class resolution attempt
 * - Logs missing file paths
 */
final class Autoloader
{
    public static function register(): void
    {
        // 🔥 PROOF #1 — Autoloader is registered
        error_log('[AUTOLOADER] register() called');

        spl_autoload_register(
            function (string $class): void {

                // 🔥 PROOF #2 — Autoload invoked
                error_log('[AUTOLOADER] Attempting: ' . $class);

                // Only DCJOBS namespace
                if (strpos($class, 'DCJOBS\\') !== 0) {
                    return;
                }

                $basePath = dirname(__DIR__) . '/';

                $map = [
                    'DCJOBS\\Core\\'         => 'core/',
                    'DCJOBS\\Controllers\\' => 'controllers/',
                ];

                foreach ($map as $prefix => $dir) {
                    if (strpos($class, $prefix) === 0) {

                        $relative = substr($class, strlen($prefix));
                        $file = $basePath . $dir . str_replace('\\', '/', $relative) . '.php';

                        if (is_file($file)) {
                            error_log('[AUTOLOADER] Loaded: ' . $file);
                            require_once $file;
                        } else {
                            error_log('[AUTOLOADER] FILE NOT FOUND: ' . $file);
                        }

                        return;
                    }
                }

                error_log('[AUTOLOADER] No namespace match for ' . $class);
            }
        );
    }
}
