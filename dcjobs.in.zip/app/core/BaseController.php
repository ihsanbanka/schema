<?php
declare(strict_types=1);

/**
 * DCJOBS-CORE — Base Controller
 * --------------------------------
 * Path: /app/core/BaseController.php
 * Version: v2.1.0 (SESSION HARDENED + CSRF RESTORED)
 *
 * ✔ Centralized session enforcement
 * ✔ AJAX + Page safe
 * ✔ Redirect to /error/session-expired
 * ✔ Session destroyed properly
 * ✔ No output before redirect
 * ✔ CSRF support restored (generate + validate + rotate)
 */

namespace DCJOBS\Core;

use PDO;
use RuntimeException;
use DCJOBS\Core\Database;

abstract class BaseController
{
    public function __construct()
    {
        $this->initializeSession();
    }

    /* =========================================================
       SESSION INIT
    ========================================================= */
    protected function initializeSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }

    /* =========================================================
       REQUIRE AUTHENTICATED USER
    ========================================================= */
    protected function requireUser(): array
    {
        if (empty($_SESSION['user_id'])) {
            $this->handleSessionExpired();
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            "SELECT id, is_active
             FROM users
             WHERE id = :id
             LIMIT 1"
        );

        $stmt->execute([
            ':id' => (int) $_SESSION['user_id']
        ]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user || (int)$user['is_active'] !== 1) {
            $this->handleSessionExpired();
        }

        return $user;
    }

    /* =========================================================
       REQUIRE PERSONA
    ========================================================= */
    protected function requirePersona(array $allowed): void
    {
        if (empty($_SESSION['persona'])) {
            $this->handleSessionExpired();
        }

        if (!in_array($_SESSION['persona'], $allowed, true)) {
            $this->handleSessionExpired();
        }
    }

    /* =========================================================
       SESSION EXPIRED HANDLER (FINAL FIX)
    ========================================================= */
    protected function handleSessionExpired(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_unset();
            session_destroy();
        }

        $isAjax =
            (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
             strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
            ||
            (isset($_SERVER['HTTP_ACCEPT']) &&
             str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'));

        if ($isAjax) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'SESSION_EXPIRED']);
            exit;
        }

        header('Location: /error/session-expired', true, 302);
        exit;
    }

    /* =========================================================
       CSRF SUPPORT (RESTORED — NON-BREAKING)
    ========================================================= */

    protected function generateCsrfToken(): string
    {
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['_csrf_token'];
    }

    protected function validateCsrfToken(?string $token): bool
    {
        return !empty($_SESSION['_csrf_token']) &&
               !empty($token) &&
               hash_equals($_SESSION['_csrf_token'], $token);
    }

    protected function rotateCsrfToken(): void
    {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
}
