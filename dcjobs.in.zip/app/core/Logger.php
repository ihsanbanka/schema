<?php
declare(strict_types=1);

namespace DCJOBS\Core;

use Throwable;

final class Logger
{
    private const LEVEL_INFO    = 'INFO';
    private const LEVEL_WARNING = 'WARNING';
    private const LEVEL_ERROR   = 'ERROR';

    private const LOG_FILE = __DIR__ . '/../logs/app.log';

    public static function log(string $level, string $message, array $context = []): void
    {
        $timestamp = date('Y-m-d H:i:s');
        $entry = sprintf(
            "[%s] [%s] %s %s\n",
            $timestamp,
            $level,
            $message,
            $context ? json_encode($context, JSON_UNESCAPED_UNICODE) : ''
        );

        /* -------------------------------
           1️⃣ FILE LOG (PRIMARY)
        -------------------------------- */
        try {
            file_put_contents(self::LOG_FILE, $entry, FILE_APPEND | LOCK_EX);
        } catch (Throwable) {
            // ignore — move on
        }

        /* -------------------------------
           2️⃣ DB LOG (SECONDARY)
        -------------------------------- */
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare(
                'INSERT INTO app_logs (level, message, context, created_at)
                 VALUES (:level, :message, :context, NOW())'
            );
            $stmt->execute([
                ':level'   => $level,
                ':message' => $message,
                ':context' => json_encode($context, JSON_UNESCAPED_UNICODE),
            ]);
        } catch (Throwable $e) {
            // final fallback
            error_log('[DCJOBS-LOGGER-DB-FAIL] ' . $e->getMessage());
        }
    }

    public static function info(string $message, array $context = []): void
    {
        self::log(self::LEVEL_INFO, $message, $context);
    }

    public static function warning(string $message, array $context = []): void
    {
        self::log(self::LEVEL_WARNING, $message, $context);
    }

    public static function error(string $message, array $context = []): void
    {
        self::log(self::LEVEL_ERROR, $message, $context);
    }
}
