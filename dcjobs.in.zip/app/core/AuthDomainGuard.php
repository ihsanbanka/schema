<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: AuthDomainGuard.php
 * Path: /app/core/AuthDomainGuard.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-6 (Security Foundation)
 * Component        : Recruiter Email Domain Guard
 *
 * Purpose:
 * --------
 * - Enforce company-domain-only emails for Recruiter
 * - Block free/public email domains (DB-driven)
 * - Act as single authoritative validation point
 *
 * GOVERNANCE:
 * -----------
 * ✔ No hardcoded domains
 * ✔ Database-driven blocklist
 * ✔ Backend authoritative
 * ✔ Reusable across controllers
 * ✔ User-friendly errors
 * ✔ Log-safe
 */

declare(strict_types=1);

namespace DCJOBS\Core;

use RuntimeException;
use PDO;

final class AuthDomainGuard
{
    /**
     * Enforce recruiter email domain rules.
     *
     * @param string $email
     * @throws RuntimeException
     */
    public static function assertRecruiterEmailAllowed(string $email): void
    {
        $email = strtolower(trim($email));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Please enter a valid company email address.');
        }

        $domain = self::extractDomain($email);

        if ($domain === '') {
            throw new RuntimeException('Invalid email domain.');
        }

        if (self::isBlockedDomain($domain)) {
            throw new RuntimeException(
                'Free email domains are not allowed for recruiter accounts. ' .
                'Please use your official company email address.'
            );
        }
    }

    /**
     * Extract domain from email.
     *
     * @param string $email
     * @return string
     */
    private static function extractDomain(string $email): string
    {
        $parts = explode('@', $email);
        return $parts[1] ?? '';
    }

    /**
     * Check domain against DB blocklist.
     *
     * Table expectation:
     * ------------------
     * blocked_email_domains
     * - id
     * - domain (e.g. gmail.com)
     * - is_active (1/0)
     *
     * @param string $domain
     * @return bool
     */
    private static function isBlockedDomain(string $domain): bool
    {
        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            'SELECT 1
             FROM blocked_email_domains
             WHERE domain = :domain
               AND is_active = 1
             LIMIT 1'
        );

        $stmt->execute([
            ':domain' => $domain
        ]);

        return (bool) $stmt->fetchColumn();
    }
}
