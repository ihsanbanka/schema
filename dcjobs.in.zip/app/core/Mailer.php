<?php
/**
 * DCJOBS-CORE — SMTP Mailer
 * ------------------------------------------------
 * File: Mailer.php
 * Path: /app/core/Mailer.php
 *
 * Software Version : DCJOBS-CORE v1.3.3
 * Phase            : Phase-6 (Multilingual SMTP Mail)
 *
 * Fix:
 * ----
 * ✔ Forced translation cache refresh for emails
 * ✔ Prevents stale {link} placeholders
 * ✔ Clickable verification link guaranteed
 * ✔ Yahoo / Gmail / Mobile compatible
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Core;

/* -------------------------------------------------
   PHPMailer bootstrap (NO Composer, shared hosting)
------------------------------------------------- */
$projectRoot   = dirname(__DIR__, 2);
$phpMailerBase = $projectRoot . '/app/lib/PHPMailer/src/';

if (!class_exists(\PHPMailer\PHPMailer\PHPMailer::class)) {
    require_once $phpMailerBase . 'Exception.php';
    require_once $phpMailerBase . 'PHPMailer.php';
    require_once $phpMailerBase . 'SMTP.php';
}

use PHPMailer\PHPMailer\PHPMailer;
use Throwable;

final class Mailer
{
    public static function send(
        string $toEmail,
        string $subjectKey,
        string $bodyKey,
        array $params = [],
        ?string $language = null
    ): bool {
        try {
            /* ---------------------------------
               Load configuration
            --------------------------------- */
            Config::load();

            if ((string) Config::get('smtp.enabled', '0') !== '1') {
                Logger::warning('SMTP_DISABLED', ['to' => $toEmail]);
                return false;
            }

            /* ---------------------------------
               Safety check
            --------------------------------- */
            if (!class_exists(PHPMailer::class)) {
                Logger::error('EMAIL_FAILED', [
                    'to'    => $toEmail,
                    'error' => 'PHPMailer class not loaded'
                ]);
                return false;
            }

            /* ---------------------------------
               Resolve language
            --------------------------------- */
            $lang = $language
                ?: ($_SESSION['language'] ?? Language::getDefault());

            /**
             * 🔑 CRITICAL FIX:
             * Force-refresh translations so email templates
             * never use stale cached values.
             */
            unset($_SESSION['_translations'][$lang]);
            Translator::load($lang);

            /* ---------------------------------
               Resolve translations
            --------------------------------- */
            $subject = Translator::t($subjectKey, $params);
            $body    = Translator::t($bodyKey, $params);

            if ($subject === $subjectKey || $body === $bodyKey) {
                Logger::warning('EMAIL_TRANSLATION_MISSING', [
                    'to'   => $toEmail,
                    'lang' => $lang
                ]);
                return false;
            }

            /* ---------------------------------
               RTL handling
            --------------------------------- */
            $isRtl = in_array($lang, ['ur', 'ar', 'fa'], true);
            $dir   = $isRtl ? 'rtl' : 'ltr';
            $align = $isRtl ? 'right' : 'left';

            $footer = Translator::t('email.footer.signature');
            $notice = Translator::t('email.footer.disclaimer');

            $footerHtml = '';
            if ($footer !== 'email.footer.signature') {
                $footerHtml .= "<p>{$footer}</p>";
            }
            if ($notice !== 'email.footer.disclaimer') {
                $footerHtml .= "<p style='font-size:12px;color:#64748b'>{$notice}</p>";
            }

            /* ---------------------------------
               HTML body
            --------------------------------- */
            $htmlBody = <<<HTML
<div dir="{$dir}" style="
    font-family: Arial, sans-serif;
    background-color:#f8fafc;
    padding:24px;
    color:#0f172a;
    text-align:{$align};
">
    {$body}
    {$footerHtml}
</div>
HTML;

            /* ---------------------------------
               Plain-text fallback (guaranteed link)
            --------------------------------- */
            $plainBody = trim(strip_tags($body));

            if (isset($params['verify_link'])) {
                $plainBody .= "\n\nVerify your email:\n" . $params['verify_link'];
            }

            /* ---------------------------------
               SMTP setup
            --------------------------------- */
            $mail = new PHPMailer(true);

            $mail->isSMTP();
            $mail->Host       = (string) Config::get('smtp.host');
            $mail->SMTPAuth   = true;
            $mail->Username   = (string) Config::get('smtp.username');
            $mail->Password   = (string) Config::get('smtp.password');
            $mail->Port       = (int) Config::get('smtp.port', 587);
            $mail->Timeout    = (int) Config::get('smtp.timeout', 30);

            $encryption = Config::get('smtp.encryption', 'tls');
            $mail->SMTPSecure = ($encryption === 'ssl')
                ? PHPMailer::ENCRYPTION_SMTPS
                : PHPMailer::ENCRYPTION_STARTTLS;

            $mail->SMTPDebug = (int) Config::get('smtp.debug', 0);

            /* ---------------------------------
               Email meta
            --------------------------------- */
            $mail->CharSet = 'UTF-8';
            $mail->isHTML(true);

            $mail->setFrom(
                (string) Config::get('smtp.from_email'),
                (string) Config::get('smtp.from_name', 'DCJOBS')
            );

            $mail->addAddress($toEmail);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = $plainBody;

            /* ---------------------------------
               Send
            --------------------------------- */
            $mail->send();

            Logger::info('EMAIL_SENT', [
                'to'   => $toEmail,
                'lang' => $lang
            ]);

            return true;

        } catch (Throwable $e) {

            Logger::error('EMAIL_FAILED', [
                'to'    => $toEmail,
                'error' => $e->getMessage()
            ]);

            return false;
        }
    }
}
