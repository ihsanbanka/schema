<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: Environment.php
 * Path: /app/core/Environment.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Component        : Environment Detection & Runtime Context
 * Phase            : Phase-1 (P1.2)
 *
 * Purpose:
 * --------
 * Detects and exposes the runtime environment in a SAFE, NON-HARDCODED way.
 * Works on:
 *  - Shared Hosting (Hostinger)
 *  - Cloud Hosting (future migration)
 *
 * Environment information is:
 * - Read from DATABASE (when available)
 * - Auto-detected only where unavoidable
 *
 * NO business logic is allowed in this file.
 */

namespace DCJOBS\Core;

class Environment
{
    /**
     * Cached environment values for current request
     *
     * @var array
     */
    private static array $environment = [];

    /**
     * Initialize environment detection.
     *
     * Called early during bootstrap lifecycle.
     * This method MUST be safe to call multiple times.
     *
     * @return void
     */
    public static function init(): void
    {
        if (!empty(self::$environment)) {
            return;
        }

        self::$environment = [
            'execution_mode' => self::detectExecutionMode(),
            'hosting_type'   => self::detectHostingType(),
            'is_https'       => self::detectHttps(),
            'php_sapi'       => PHP_SAPI,
            'server_time'    => date('c')
        ];

        self::logEnvironment();
    }

    /**
     * Detects whether application is running via CLI or Web.
     *
     * @return string
     */
    private static function detectExecutionMode(): string
    {
        return (PHP_SAPI === 'cli') ? 'CLI' : 'WEB';
    }

    /**
     * Detects hosting type in a NON-ASSUMPTIVE way.
     *
     * IMPORTANT:
     * ----------
     * - No vendor checks
     * - No server-name hardcoding
     * - Result is advisory, not authoritative
     *
     * Final authority will always be DB configuration.
     *
     * @return string
     */
    private static function detectHostingType(): string
    {
        if (
            isset($_SERVER['HTTP_HOST']) &&
            !isset($_SERVER['SSH_CONNECTION'])
        ) {
            return 'SHARED_HOSTING';
        }

        return 'CLOUD_OR_DEDICATED';
    }

    /**
     * Detect HTTPS status safely.
     *
     * @return bool
     */
    private static function detectHttps(): bool
    {
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            return true;
        }

        if (
            isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
            $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https'
        ) {
            return true;
        }

        return false;
    }

    /**
     * Returns a single environment value.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function get(string $key, mixed $default = null): mixed
    {
        return self::$environment[$key] ?? $default;
    }

    /**
     * Returns full environment context for current request.
     *
     * @return array
     */
    public static function all(): array
    {
        return self::$environment;
    }

    /**
     * Logs detected environment using bootstrap-safe logging.
     *
     * NOTE:
     * -----
     * - Uses early logging until Logger.php is available
     * - This guarantees environment visibility even on fatal failures
     *
     * @return void
     */
    private static function logEnvironment(): void
    {
        error_log(
            '[DCJOBS-ENV] ' . json_encode(self::$environment)
        );
    }
}