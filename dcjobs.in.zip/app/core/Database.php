<?php
declare(strict_types=1);

namespace DCJOBS\Core;

use PDO;
use PDOException;
use RuntimeException;

final class Database
{
    private static ?PDO $connection = null;

    private function __construct() {}

    /**
     * Get PDO connection
     *
     * @return PDO
     */
    public static function getConnection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        if (!defined('DCJOBS_DB_BOOTSTRAP')) {
            throw new RuntimeException('DCJOBS_DB_BOOTSTRAP constant is not defined');
        }

        $bootstrapFile = DCJOBS_DB_BOOTSTRAP;

        if (!is_string($bootstrapFile) || !is_file($bootstrapFile)) {
            throw new RuntimeException(
                'Invalid DB bootstrap path. Expected absolute file path, got: ' .
                var_export($bootstrapFile, true)
            );
        }

        $config = require $bootstrapFile;

        if (!is_array($config)) {
            throw new RuntimeException('DB bootstrap file must return a config array');
        }

        try {
            $dsn = sprintf(
                'mysql:host=%s;dbname=%s;charset=%s',
                $config['host'],
                $config['database'],
                $config['charset'] ?? 'utf8mb4'
            );

            self::$connection = new PDO(
                $dsn,
                $config['username'],
                $config['password'],
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );

            return self::$connection;

        } catch (PDOException $e) {
            throw new RuntimeException(
                'Database connection failed: ' . $e->getMessage()
            );
        }
    }
}
