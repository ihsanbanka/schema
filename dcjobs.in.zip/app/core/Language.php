<?php
/**
 * DCJOBS-CORE — Language Manager
 * ------------------------------------------------
 * File: Language.php
 * Path: /app/core/Language.php
 *
 * Software Version : DCJOBS-CORE v1.0.1
 * Phase            : Phase-6 (i18n foundation)
 *
 * Purpose:
 * --------
 * - Central language loader
 * - DB-driven (no hardcoding)
 * - Used by header, footer, controllers
 *
 * Governance:
 * -----------
 * ✔ No hardcoded languages
 * ✔ Reads only active languages
 * ✔ Respects display order
 * ✔ Default language supported
 * ✔ Session-safe
 */

declare(strict_types=1);

namespace DCJOBS\Core;

use PDO;
use Throwable;

final class Language
{
    /**
     * Cached language list (per request)
     */
    private static ?array $cache = null;

    /**
     * Fetch all active languages
     */
    public static function getAll(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        try {
            $pdo = Database::getConnection();

            $stmt = $pdo->query(
                "SELECT
                    language_key,
                    language_name,
                    native_name,
                    is_default
                 FROM app_languages
                 WHERE is_active = 1
                 ORDER BY display_order ASC"
            );

            self::$cache = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable) {
            self::$cache = [];
        }

        return self::$cache;
    }

    /**
     * Get default language key (DB-driven)
     */
    public static function getDefault(): ?string
    {
        foreach (self::getAll() as $lang) {
            if ((int)$lang['is_default'] === 1) {
                return $lang['language_key'];
            }
        }

        // Absolute fallback: first active language (if any)
        return self::$cache[0]['language_key'] ?? null;
    }

    /**
     * Get current language
     * Priority:
     * 1. Session
     * 2. DB default
     * 3. First active language
     */
    public static function getCurrent(): ?string
    {
        if (!empty($_SESSION['language']) && self::isValid($_SESSION['language'])) {
            return $_SESSION['language'];
        }

        $default = self::getDefault();

        if ($default !== null) {
            $_SESSION['language'] = $default;
        }

        return $default;
    }

    /**
     * Validate a language key
     */
    public static function isValid(string $languageKey): bool
    {
        foreach (self::getAll() as $lang) {
            if ($lang['language_key'] === $languageKey) {
                return true;
            }
        }

        return false;
    }

    /**
     * Set language (validated)
     */
    public static function set(string $languageKey): void
    {
        if (self::isValid($languageKey)) {
            $_SESSION['language'] = $languageKey;
        }
    }
}
