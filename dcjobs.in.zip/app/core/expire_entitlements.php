<?php
declare(strict_types=1);

/**
 * DCJOBS — Email Service (Template-based)
 * --------------------------------------
 * File: EmailService.php
 * Path: /app/core/EmailService.php
 *
 * Software Version : DCJOBS-CORE v1.1.0
 *
 * Purpose:
 * --------
 * - Send emails using DB-driven templates
 * - Variable interpolation
 * - Reusable across cron, controllers, webhooks
 *
 * Governance:
 * -----------
 * ✔ No hardcoding
 * ✔ DB is source of truth
 * ✔ Shared-hosting safe
 * ✔ Extensible
 */

namespace DCJOBS\Core;

use PDO;
use RuntimeException;

final class EmailService
{
    /**
     * Send email using template key
     *
     * @param string $templateKey  e.g. email.job_expiry
     * @param string $toEmail
     * @param array  $variables    key => value
     */
    public static function send(
        string $templateKey,
        string $toEmail,
        array $variables = []
    ): void {
        $pdo = Database::getConnection();

        /* ---------------------------------
           LOAD TEMPLATE
        --------------------------------- */
        $stmt = $pdo->prepare(
            "SELECT subject, body
             FROM email_templates
             WHERE template_key = :key
               AND is_active = 1
             LIMIT 1"
        );
        $stmt->execute([':key' => $templateKey]);

        $template = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$template) {
            throw new RuntimeException('Email template not found: ' . $templateKey);
        }

        /* ---------------------------------
           VARIABLE INTERPOLATION
        --------------------------------- */
        $subject = self::parse($template['subject'], $variables);
        $body    = self::parse($template['body'], $variables);

        /* ---------------------------------
           SEND (PHP mail – shared hosting)
        --------------------------------- */
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8\r\n";
        $headers .= "From: DCJOBS <" . Config::get('mail.from_address') . ">\r\n";

        mail($toEmail, $subject, $body, $headers);
    }

    /**
     * Replace {{variables}} in template
     */
    private static function parse(string $text, array $vars): string
    {
        foreach ($vars as $key => $value) {
            $text = str_replace(
                '{{' . $key . '}}',
                htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'),
                $text
            );
        }
        return $text;
    }
}
