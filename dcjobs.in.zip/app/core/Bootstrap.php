<?php
/**
 * DCJOBS Application Bootstrap
 * ----------------------------------------
 * File: Bootstrap.php
 * Path: /app/core/Bootstrap.php
 *
 * Software Version : DCJOBS-CORE v1.5.1
 * Phase            : Phase-6 (i18n Middleware Foundation)
 *
 * Purpose:
 * --------
 * - Define application root
 * - Load DB bootstrap
 * - Register PSR-4 autoloader
 * - Load core infrastructure
 * - Resolve application language (DB-driven)
 *
 * Governance:
 * -----------
 * ✔ No business logic
 * ✔ DB-driven language
 * ✔ One-time execution
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Core;

final class Bootstrap
{
    /**
     * Run application bootstrap sequence.
     */
    public static function run(): void
    {
        /* ---------------------------------
           STEP 1: Define ROOT
        --------------------------------- */
        if (!defined('DCJOBS_ROOT')) {
            define('DCJOBS_ROOT', dirname(__DIR__, 2));
        }

        /* ---------------------------------
           STEP 2: Load DB bootstrap
        --------------------------------- */
        require_once DCJOBS_ROOT . '/app/bootstrap/db_bootstrap.php';

        /* ---------------------------------
           STEP 3: Autoloader
        --------------------------------- */
        require_once DCJOBS_ROOT . '/app/core/Autoloader.php';
        Autoloader::register();

        /* ---------------------------------
           STEP 4: Core infrastructure
        --------------------------------- */
        require_once DCJOBS_ROOT . '/app/core/Database.php';
        require_once DCJOBS_ROOT . '/app/core/Logger.php';
        require_once DCJOBS_ROOT . '/app/core/Config.php';
        require_once DCJOBS_ROOT . '/app/core/BaseController.php';
        require_once DCJOBS_ROOT . '/app/core/Router.php';
        require_once DCJOBS_ROOT . '/app/core/Language.php';

        /* ✅ ADDED: Translation helper (one-time, global) */
        require_once DCJOBS_ROOT . '/app/helpers/translation_helper.php';

        /* ---------------------------------
           STEP 5: Language resolution
           Priority:
           1) Logged-in user (future)
           2) Session
           3) DB default
        --------------------------------- */
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // If language already resolved in session → trust it
        if (!empty($_SESSION['language'])) {
            return;
        }

        // Load default language from DB
        try {
            $_SESSION['language'] = Language::getDefault();
        } catch (\Throwable $e) {
            // Absolute fallback — system must not break
            $_SESSION['language'] = 'en';
        }
    }
}
