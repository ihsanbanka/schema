<?php
declare(strict_types=1);

/**
 * DCJOBS — Email Service (Template-based)
 * --------------------------------------
 * File: EmailService.php
 * Path: /app/core/EmailService.php
 *
 * Software Version : DCJOBS-CORE v1.1.1
 *
 * Purpose:
 * --------
 * - Send emails using DB-driven templates
 * - Safe variable interpolation
 * - RAW variable support (URLs, buttons)
 * - Silent failure protection
 *
 * Governance:
 * -----------
 * ✔ DB = source of truth
 * ✔ Shared-hosting safe
 * ✔ Cron-safe (never throws on send failure)
 */

namespace DCJOBS\Core;

use PDO;
use Throwable;

final class EmailService
{
    public static function send(
        string $templateKey,
        string $toEmail,
        array $variables = []
    ): void {
        try {
            $pdo = Database::getConnection();

            /* ================= LOAD TEMPLATE ================= */
            $stmt = $pdo->prepare(
                "SELECT subject, body
                 FROM email_templates
                 WHERE template_key = :key
                   AND is_active = 1
                 LIMIT 1"
            );
            $stmt->execute([':key' => $templateKey]);
            $template = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$template) {
                Logger::error('EMAIL_TEMPLATE_MISSING', [
                    'template_key' => $templateKey
                ]);
                return;
            }

            /* ================= PARSE ================= */
            $subject = self::parse($template['subject'], $variables);
            $body    = self::parse($template['body'], $variables);

            /* ================= SEND ================= */
            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8\r\n";
            $headers .= "From: DCJOBS <" . Config::get('mail.from_address') . ">\r\n";

            $sent = mail($toEmail, $subject, $body, $headers);

            if (!$sent) {
                Logger::error('EMAIL_SEND_FAILED', [
                    'to' => $toEmail,
                    'template' => $templateKey
                ]);
            }

        } catch (Throwable $e) {
            Logger::error('EMAIL_SERVICE_EXCEPTION', [
                'template' => $templateKey,
                'error'    => $e->getMessage()
            ]);
        }
    }

    /**
     * Variable replacement
     * {{var}}   → escaped
     * {{{var}}} → raw (URLs, HTML buttons)
     */
    private static function parse(string $text, array $vars): string
    {
        foreach ($vars as $key => $value) {
            // RAW first
            $text = str_replace(
                '{{{' . $key . '}}}',
                (string)$value,
                $text
            );

            // Escaped
            $text = str_replace(
                '{{' . $key . '}}',
                htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'),
                $text
            );
        }
        return $text;
    }
}
