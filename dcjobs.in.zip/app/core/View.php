<?php
declare(strict_types=1);

/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: View.php
 * Path: /app/core/View.php
 *
 * Software Version : DCJOBS-CORE v1.15.0
 * Phase            : Phase-6 UI Foundation (LOCKED)
 *
 * PURPOSE:
 * --------
 * - Centralized view renderer
 * - Enforces explicit layout usage
 * - Prevents header/footer loss
 * - Prevents accidental raw rendering
 *
 * NON-NEGOTIABLE RULE:
 * -------------------
 * ❌ NO VIEW may render without a layout
 * ❌ NO silent fallback is allowed
 *
 * Allowed layouts:
 * ----------------
 * - layout      → Public / Landing / Auth pages
 * - dashboard   → ALL authenticated user pages
 */

namespace DCJOBS\Core;

final class View
{
    /**
     * Render a view wrapped inside a REQUIRED layout.
     *
     * @param string $view   View path relative to /app/views (without .php)
     * @param array  $data   Variables passed to the view
     * @param string $layout Layout name (WITHOUT .php) — REQUIRED
     */
    public static function render(
        string $view,
        array $data,
        string $layout
    ): void {

        /* --------------------------------------------
           HARD ENFORCEMENT — NO LAYOUT, NO RENDER
        -------------------------------------------- */
        if ($layout === '') {
            http_response_code(500);
            echo 'Layout is mandatory for all views.';
            exit;
        }

        // Normalize view path
        $view = ltrim($view, '/');

        $viewsDir   = DCJOBS_ROOT . '/app/views/';
        $viewFile   = $viewsDir . $view . '.php';
        $layoutFile = $viewsDir . 'layouts/' . $layout . '.php';

        /* --------------------------------------------
           VALIDATION — VIEW FILE MUST EXIST
        -------------------------------------------- */
        if (!is_file($viewFile)) {
            http_response_code(500);
            echo 'View not found: ' . htmlspecialchars($view, ENT_QUOTES, 'UTF-8');
            exit;
        }

        /* --------------------------------------------
           VALIDATION — LAYOUT FILE MUST EXIST
        -------------------------------------------- */
        if (!is_file($layoutFile)) {
            http_response_code(500);
            echo 'Layout not found: ' . htmlspecialchars($layout, ENT_QUOTES, 'UTF-8');
            exit;
        }

        /* --------------------------------------------
           EXPOSE DATA TO VIEW
        -------------------------------------------- */
        extract($data, EXTR_SKIP);

        /* --------------------------------------------
           RENDER VIEW (BUFFERED)
        -------------------------------------------- */
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        /* --------------------------------------------
           WRAP WITH LAYOUT (MANDATORY)
        -------------------------------------------- */
        require $layoutFile;
    }
}
