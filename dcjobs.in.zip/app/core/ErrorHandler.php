<?php
/**
 * DCJOBS Error & Exception Handler
 * ------------------------------------------------------------
 * File: ErrorHandler.php
 * Path: /app/core/ErrorHandler.php
 * Version: 1.0.0
 *
 * Purpose:
 * - Centralized handling of PHP errors, exceptions, and fatal shutdowns
 * - Convert all runtime issues into structured log entries
 * - Route everything through DCJOBS\Core\Logger
 * - Prevent raw errors from leaking to end users
 *
 * Design Principles:
 * - No hardcoded environment flags
 * - No hardcoded severity thresholds
 * - All behavior controlled via database-driven Config
 * - Shared-hosting safe, cloud-ready
 *
 * Dependencies:
 * - DCJOBS\Core\Config
 * - DCJOBS\Core\Logger
 *
 * Author: DCJOBS Core System
 * ------------------------------------------------------------
 */

namespace DCJOBS\Core;

class ErrorHandler
{
    /**
     * Register all handlers (errors, exceptions, shutdown)
     * This should be called once during bootstrap.
     */
    public static function register(): void
    {
        // Handle standard PHP errors (warnings, notices, etc.)
        set_error_handler([self::class, 'handleError']);

        // Handle uncaught exceptions
        set_exception_handler([self::class, 'handleException']);

        // Handle fatal errors (E_ERROR, E_PARSE, etc.)
        register_shutdown_function([self::class, 'handleShutdown']);
    }

    /**
     * Handle non-fatal PHP errors.
     *
     * @param int    $severity
     * @param string $message
     * @param string $file
     * @param int    $line
     * @return bool
     */
    public static function handleError(
        int $severity,
        string $message,
        string $file,
        int $line
    ): bool {
        // Respect PHP error_reporting level
        if (!(error_reporting() & $severity)) {
            return false;
        }

        $logLevel = self::mapPhpErrorToLogLevel($severity);

        Logger::log($logLevel, 'PHP Error', [
            'message' => $message,
            'file'    => $file,
            'line'    => $line,
            'severity'=> $severity
        ]);

        // Do not display raw errors to users
        return true;
    }

    /**
     * Handle uncaught exceptions.
     *
     * @param \Throwable $exception
     */
    public static function handleException(\Throwable $exception): void
    {
        Logger::log('critical', 'Uncaught Exception', [
            'message' => $exception->getMessage(),
            'file'    => $exception->getFile(),
            'line'    => $exception->getLine(),
            'trace'   => $exception->getTraceAsString()
        ]);

        // Generic response to user (no sensitive data)
        self::renderSafeError();
    }

    /**
     * Handle fatal shutdown errors.
     */
    public static function handleShutdown(): void
    {
        $error = error_get_last();

        if ($error === null) {
            return;
        }

        if (in_array($error['type'], [
            E_ERROR,
            E_PARSE,
            E_CORE_ERROR,
            E_COMPILE_ERROR
        ], true)) {

            Logger::log('critical', 'Fatal Shutdown Error', [
                'message' => $error['message'],
                'file'    => $error['file'],
                'line'    => $error['line'],
                'type'    => $error['type']
            ]);

            self::renderSafeError();
        }
    }

    /**
     * Convert PHP error severity to logger level.
     *
     * @param int $severity
     * @return string
     */
    private static function mapPhpErrorToLogLevel(int $severity): string
    {
        switch ($severity) {
            case E_USER_ERROR:
            case E_ERROR:
                return 'critical';

            case E_WARNING:
            case E_USER_WARNING:
                return 'warning';

            case E_NOTICE:
            case E_USER_NOTICE:
            case E_DEPRECATED:
            case E_USER_DEPRECATED:
                return 'notice';

            default:
                return 'error';
        }
    }

    /**
     * Render a safe, non-technical error message.
     * Output behavior can later be controlled via DB config.
     */
    private static function renderSafeError(): void
    {
        if (headers_sent() === false) {
            http_response_code(500);
        }

        echo 'An unexpected error occurred. Please try again later.';
        exit;
    }
}