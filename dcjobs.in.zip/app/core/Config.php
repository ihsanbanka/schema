<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: Config.php
 * Path: /app/core/Config.php
 *
 * Software Version : DCJOBS-CORE v1.3.0
 * Phase            : Phase-6 (Infrastructure Readiness)
 * Component        : Configuration Manager
 *
 * Purpose:
 * --------
 * - Load system configuration from database
 * - Provide safe global config access
 * - Act as single source of truth for SMTP & system settings
 *
 * Governance:
 * -----------
 * ✔ DB-driven configuration
 * ✔ No hardcoded credentials
 * ✔ Shared-hosting safe
 * ✔ Cloud-ready
 */

declare(strict_types=1);

namespace DCJOBS\Core;

/**
 * Defensive include for Database during bootstrap phase
 * (Autoloader may not resolve reliably on shared hosting)
 */
require_once DCJOBS_ROOT . '/app/core/Database.php';

use PDO;
use RuntimeException;

final class Config
{
    /**
     * Cached configuration values
     *
     * @var array<string, mixed>
     */
    private static array $config = [];

    /**
     * Load active configuration from database (once per request)
     */
    public static function load(): void
    {
        if (!empty(self::$config)) {
            return;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            "SELECT config_key, config_value
             FROM system_config
             WHERE is_active = 1"
        );

        $stmt->execute();

        self::$config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];
    }

    /**
     * Get configuration value by key
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    public static function get(string $key, mixed $default = null): mixed
    {
        // Lazy-load for safety
        if (empty(self::$config)) {
            self::load();
        }

        return self::$config[$key] ?? $default;
    }

    /**
     * Check if a configuration key exists
     */
    public static function has(string $key): bool
    {
        if (empty(self::$config)) {
            self::load();
        }

        return array_key_exists($key, self::$config);
    }
}
