<?php
/**
 * DCJOBS-CORE — Translator
 * ------------------------------------------------
 * File: Translator.php
 * Path: /app/core/Translator.php
 *
 * Software Version : DCJOBS-CORE v1.1.0
 * Phase            : Phase-6 (i18n foundation)
 *
 * Purpose:
 * --------
 * - Load translations from DB (app_translations)
 * - Cache translations per language (session-level)
 * - Provide translation lookup via t()
 * - Fallback-safe (never breaks UI)
 *
 * Governance:
 * -----------
 * ✔ DB-driven (no hardcoded labels)
 * ✔ Session-cached (performance)
 * ✔ Safe fallback to key if missing
 * ✔ UTF-8 safe (multi-language ready)
 * ✔ One-load-per-request guarantee
 * ✔ Shared-hosting compatible
 */

declare(strict_types=1);

namespace DCJOBS\Core;

use PDO;
use Throwable;

final class Translator
{
    /**
     * Load translations for a language into session cache
     *
     * @param string|null $language
     * @return void
     */
    public static function load(?string $language = null): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $language = $language ?: ($_SESSION['language'] ?? 'en');

        // Already loaded → skip DB hit
        if (!empty($_SESSION['_translations'][$language])) {
            return;
        }

        try {
            $pdo = Database::getConnection();

            $stmt = $pdo->prepare(
                'SELECT translation_key, translation_value
                 FROM app_translations
                 WHERE language_key = :lang
                   AND is_active = 1'
            );

            $stmt->execute([':lang' => $language]);

            $translations = [];

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $translations[(string) $row['translation_key']] =
                    (string) $row['translation_value'];
            }

            $_SESSION['_translations'][$language] = $translations;

        } catch (Throwable) {
            // Absolute safety — UI must never break
            $_SESSION['_translations'][$language] = [];
        }
    }

    /**
     * Translate a key
     *
     * @param string $key     Translation key
     * @param array  $params Optional replacements (e.g. {year})
     * @return string
     */
    public static function t(string $key, array $params = []): string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        $language = $_SESSION['language'] ?? 'en';

        // Ensure translations are loaded
        if (empty($_SESSION['_translations'][$language])) {
            self::load($language);
        }

        $value =
            $_SESSION['_translations'][$language][$key]
            ?? $key; // fallback = key itself

        // Parameter replacement: {year}, {name}, etc.
        if (!empty($params)) {
            foreach ($params as $param => $val) {
                $value = str_replace(
                    '{' . $param . '}',
                    (string) $val,
                    $value
                );
            }
        }

        return $value;
    }
}
