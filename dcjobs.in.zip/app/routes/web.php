<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| POST A JOB — ROUTES (FINAL)
|--------------------------------------------------------------------------
| - All routes are dashboard-protected
| - No direct public access
| - Skills fetched dynamically via AJAX
*/

$router->get(
    '/dashboard/post-job',
    'PostJobController@index'
);

$router->post(
    '/dashboard/post-job',
    'PostJobController@store'
);

$router->get(
    '/dashboard/post-job/skills',
    'PostJobController@fetchSkills'
);
