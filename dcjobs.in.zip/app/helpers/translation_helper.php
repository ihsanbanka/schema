<?php
/**
 * DCJOBS-CORE — Translation Helper
 * ------------------------------------------------
 * File: translation_helper.php
 * Path: /app/helpers/translation_helper.php
 *
 * Software Version : DCJOBS-CORE v1.1.0
 * Phase            : Phase-6 (i18n foundation)
 *
 * Purpose:
 * --------
 * - Provide a global t() helper for views & templates
 * - Proxy safely to Translator class
 * - Keep views clean and readable
 *
 * Usage:
 * ------
 * <?= t('login.title') ?>
 * <?= t('footer.copyright', ['year' => date('Y')]) ?>
 *
 * Governance:
 * -----------
 * ✔ No business logic
 * ✔ No DB access
 * ✔ Thin wrapper only
 * ✔ Defensive (never breaks UI)
 * ✔ Shared-hosting compatible
 */

declare(strict_types=1);

use DCJOBS\Core\Translator;

if (!function_exists('t')) {

    /**
     * Translate a key using current session language
     *
     * @param string $key     Translation key
     * @param array  $params  Optional placeholders
     * @return string
     */
    function t(string $key, array $params = []): string
    {
        // Absolute safety: if Translator not available yet
        if (!class_exists(Translator::class)) {
            return $key;
        }

        return Translator::t($key, $params);
    }
}
