<?php
/**
 * DCJOBS Bootstrap
 * --------------------------------------------
 * File: bootstrap.php
 * Version: 1.0.0
 * Purpose:
 *  - Initialize core constants
 *  - Define DB bootstrap entry point
 *  - Prepare application for config loading
 *
 * IMPORTANT:
 *  - No credentials are hardcoded
 *  - All config will be DB-driven
 *  - Safe for shared hosting
 */

declare(strict_types=1);

// Prevent direct access
if (!defined('DCJOBS_ROOT')) {
    throw new RuntimeException('DCJOBS_ROOT not defined');
}

/**
 * Absolute path to DB bootstrap file
 * This file will later establish DB connection
 * and load runtime configuration dynamically
 */
define(
    'DCJOBS_DB_BOOTSTRAP',
    DCJOBS_ROOT . '/app/bootstrap/db_bootstrap.php'
);

/**
 * Application environment
 * Values expected: production | staging | development
 * (This will later move to DB)
 */
define('DCJOBS_ENV', 'production');

/**
 * Enable minimal error display only if not production
 */
if (DCJOBS_ENV !== 'production') {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}
