<?php
/**
 * DCJOBS — Connect Accounts Controller
 * --------------------------------------------
 * File: ConnectAccountsController.php
 * Path: /app/controllers/ConnectAccountsController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Feature Enforcement)
 * Component        : Connect Accounts (Creator Only)
 *
 * Purpose:
 * --------
 * - Entry point for creator account linking
 * - Enforce authentication
 * - Enforce email verification
 * - Enforce CREATOR persona ONLY
 *
 * GOVERNANCE:
 * -----------
 * ✔ No business logic
 * ✔ No OAuth logic
 * ✔ No DB writes
 * ✔ Persona enforced via BaseController
 * ✔ Uses user_roles → roles
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use RuntimeException;

final class ConnectAccountsController extends BaseController
{
    /**
     * Route: GET /connect-accounts
     * Allowed persona: creator ONLY
     */
    public function index(): void
    {
        /**
         * STEP 1: Require authenticated user
         */
        $user = $this->requireUser();

        /**
         * STEP 2: Enforce CREATOR persona
         */
        $this->requirePersona(['creator']);

        /**
         * STEP 3: Enforce email verification
         */
        if ((int) $user['is_email_verified'] !== 1) {
            throw new RuntimeException('Email not verified');
        }

        /**
         * STEP 4: Render Connect Accounts placeholder
         */
        View::render(
            'creator/connect-accounts',
            [
                'pageTitle' => 'Connect Your Accounts — DCJOBS',
                'userEmail' => $user['email']
            ],
            'dashboard'
        );
    }
}
