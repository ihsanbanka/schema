<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: HomeController.php
 * Path: /app/controllers/HomeController.php
 *
 * Software Version : DCJOBS-CORE v1.3.2
 * Phase            : Phase-6 PART-1
 *
 * Screens:
 * --------
 * Screen-1 : Landing Page (/)
 * Screen-2 : Hiring Options (/hire)
 *
 * Purpose:
 * --------
 * - Render public landing pages BEFORE authentication
 * - No login logic
 * - No DB writes
 * - No role or intent mutation here
 *
 * Governance:
 * -----------
 * ✔ Requirement-sequence compliant
 * ✔ UI-only controller
 * ✔ Layout explicitly enforced
 * ✔ Shared hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;

final class HomeController extends BaseController
{
    /**
     * Screen-1: Landing Page
     * Route: GET /
     */
    public function index(): void
    {
        View::render(
            'landing/home',
            [
                'pageTitle' => 'DCJOBS — Creator Economy Job Platform'
            ],
            'layout' // ✅ Public layout (NO sidebar)
        );
    }

    /**
     * Screen-2: Hiring Options
     * Route: GET /hire
     *
     * Purpose:
     * - Allow user to choose Creator or Recruiter
     * - No authentication
     * - No session mutation
     */
    public function hire(): void
    {
        View::render(
            'landing/hiring-options',
            [
                'pageTitle' => 'Choose Your Role — DCJOBS'
            ],
            'layout' // ✅ Public layout (NO sidebar)
        );
    }
}
