<?php
declare(strict_types=1);

/**
 * DCJOBS-CORE — Client Logging Controller
 * --------------------------------------
 * File: ClientLogController.php
 * Path: /app/controllers/ClientLogController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 *
 * Purpose:
 * --------
 * - Receive frontend (JS) debug logs
 * - NEVER break UI flow
 * - Write logs to /app/logs/app.log.log
 *
 * Governance:
 * -----------
 * ✔ No session dependency
 * ✔ No auth required
 * ✔ No DB access
 * ✔ No exceptions thrown
 * ✔ Silent failure safe
 */

namespace DCJOBS\Controllers;

final class ClientLogController
{
    /**
     * POST /dashboard/log-client
     */
    public function log(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $raw = file_get_contents('php://input');
            $data = json_decode($raw, true);

            if (!is_array($data)) {
                $this->writeLog('INVALID_PAYLOAD', [
                    'raw' => $raw
                ]);
                echo json_encode(['ok' => true]);
                return;
            }

            $this->writeLog(
                strtoupper((string)($data['level'] ?? 'INFO')),
                (string)($data['message'] ?? 'NO_MESSAGE'),
                (array)($data['context'] ?? [])
            );

            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            // ABSOLUTELY NO UI FAILURE
            echo json_encode(['ok' => true]);
        }
    }

    /**
     * Write log entry safely
     */
    private function writeLog(string $level, string $message, array $context = []): void
    {
        $logDir  = DCJOBS_ROOT . '/app/logs';
        $logFile = $logDir . '/app.log.log';

        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }

        $entry = sprintf(
            "[%s] [%s] %s %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            $context ? json_encode($context, JSON_UNESCAPED_UNICODE) : ''
        );

        @file_put_contents(
            $logFile,
            $entry,
            FILE_APPEND | LOCK_EX
        );
    }
}
