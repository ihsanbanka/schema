<?php
declare(strict_types=1);

/**
 * DCJOBS — Dashboard Controller
 * ------------------------------------------------
 * Version : v2.1.0 (DB SAFE)
 *
 * ✔ Session enforced
 * ✔ Persona enforced
 * ✔ No creator_points dependency
 * ✔ No undefined warnings
 */

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\View;
use PDO;

final class DashboardController extends BaseController
{
    public function index(): void
    {
        /* ================================
           SESSION + ROLE ENFORCEMENT
        ================================= */
        $this->requireUser();
        $this->requirePersona(['creator','recruiter','talent']);

        $pdo = Database::getConnection();

        $userId   = (int) $_SESSION['user_id'];
        $userRole = $_SESSION['persona'];

        /* ================================
           7 DAY STATS (SAFE DEFAULTS)
        ================================= */

        $stats7d = [
            'applied'     => 0,
            'interview'   => 0,
            'shortlisted' => 0,
            'hired'       => 0,
            'rejected'    => 0,
            'on_hold'     => 0,
        ];

        if ($userRole === 'talent') {

            $stmt = $pdo->prepare("
                SELECT application_status, COUNT(*) AS total
                FROM job_applications
                WHERE applicant_user_id = :uid
                  AND applied_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY application_status
            ");

            $stmt->execute([':uid' => $userId]);

            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $key = strtolower((string)$row['application_status']);
                if (isset($stats7d[$key])) {
                    $stats7d[$key] = (int)$row['total'];
                }
            }
        }

        /* ================================
           CREATOR POINTS (DISABLED UNTIL MODULE BUILT)
        ================================= */

        $pointsSummary = []; // intentionally empty (table not yet created)

        /* ================================
           RENDER DASHBOARD
        ================================= */

        View::render(
            'dashboard/home',
            [
                'pageTitle'     => 'Dashboard',
                'stats7d'       => $stats7d,
                'pointsSummary' => $pointsSummary,
                'userRole'      => $userRole
            ],
            'dashboard'
        );
    }
}
