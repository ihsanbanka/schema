<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: AuthController.php
 * Path: /app/controllers/AuthController.php
 *
 * Software Version : DCJOBS-CORE v1.22.5
 * Phase            : Phase-6 PART-4
 * Component        : Authentication Controller
 *
 * GOVERNANCE:
 * -----------
 * ✔ Router-complete
 * ✔ Matches current DB schema
 * ✔ No undefined columns
 * ✔ No BaseController dependencies
 * ✔ Production-safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use DCJOBS\Core\Database;
use DCJOBS\Core\Language;
use DCJOBS\Core\Mailer;
use DCJOBS\Core\Config;
use DCJOBS\Core\Logger;
use Throwable;
use RuntimeException;

final class AuthController extends BaseController
{
    /* =========================================================
       LOGIN
       ========================================================= */

    public function login(): void
    {
        View::render('auth/login', [
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    public function loginPost(): void
    {
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            $this->renderLoginError('Security validation failed.');
            return;
        }

        $pdo      = Database::getConnection();
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email === '' || $password === '') {
            $this->renderLoginError('Email and password are required.');
            return;
        }

        $stmt = $pdo->prepare(
            'SELECT id, password_hash, is_active, is_email_verified, preferred_language
             FROM users
             WHERE email = :email
             LIMIT 1'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $this->renderLoginError('Invalid email or password.');
            return;
        }

        if ((int)$user['is_active'] !== 1) {
            $this->renderLoginError('Your account is disabled.');
            return;
        }

        if ((int)$user['is_email_verified'] !== 1) {
            View::render('auth/login', [
                'email'               => $email,
                'verificationPending' => true,
                'csrfToken'           => $this->generateCsrfToken()
            ]);
            return;
        }

        $_SESSION['user_id'] = (int)$user['id'];

        $_SESSION['language'] =
            !empty($user['preferred_language']) &&
            Language::isValid((string)$user['preferred_language'])
                ? (string)$user['preferred_language']
                : Language::getDefault();

        $this->rotateCsrfToken();
        header('Location: /dashboard');
        exit;
    }

    private function renderLoginError(string $message): void
    {
        View::render('auth/login', [
            'errorMessage' => $message,
            'csrfToken'    => $this->generateCsrfToken()
        ]);
    }

    /* =========================================================
       REGISTER
       ========================================================= */

    public function register(): void
    {
        View::render('auth/register', [
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    public function registerPost(): void
    {
        try {
            $pdo = Database::getConnection();

            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if ($email === '' || $password === '') {
                throw new RuntimeException('Email and password are required.');
            }

            $check = $pdo->prepare(
                'SELECT id FROM users WHERE email = :email LIMIT 1'
            );
            $check->execute([':email' => $email]);

            if ($check->fetch()) {
                throw new RuntimeException('Email already registered.');
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            $pdo->prepare(
                'INSERT INTO users
                 (email, password_hash, is_active, is_email_verified, created_at)
                 VALUES (:email, :hash, 1, 0, NOW())'
            )->execute([
                ':email' => $email,
                ':hash'  => $hash
            ]);

            $userId = (int)$pdo->lastInsertId();

            $this->sendVerificationEmail($userId, $email);

            View::render('auth/login', [
                'infoMessage' => 'Registration successful. Please verify your email.',
                'csrfToken'   => $this->generateCsrfToken()
            ]);

        } catch (Throwable $e) {

            Logger::error('REGISTER_FAILED', [
                'error' => $e->getMessage()
            ]);

            View::render('auth/register', [
                'errorMessage' => $e->getMessage(),
                'csrfToken'    => $this->generateCsrfToken()
            ]);
        }
    }

    /* =========================================================
       RESEND VERIFICATION (ROUTER FIX)
       ========================================================= */

    public function resendVerificationPost(): void
    {
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            View::render('auth/login', [
                'errorMessage' => 'Security validation failed.',
                'csrfToken'    => $this->generateCsrfToken()
            ]);
            return;
        }

        $email = trim($_POST['email'] ?? '');

        if ($email === '') {
            View::render('auth/login', [
                'errorMessage' => 'Email is required.',
                'csrfToken'    => $this->generateCsrfToken()
            ]);
            return;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            'SELECT id, is_email_verified, preferred_language
             FROM users
             WHERE email = :email
             LIMIT 1'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || (int)$user['is_email_verified'] === 1) {
            View::render('auth/login', [
                'infoMessage' =>
                    'If the email exists, a verification link has been sent.',
                'csrfToken' => $this->generateCsrfToken()
            ]);
            return;
        }

        $this->sendVerificationEmail((int)$user['id'], $email);

        View::render('auth/login', [
            'infoMessage' =>
                'Verification email has been resent. Please check your inbox.',
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    /* =========================================================
       HELPERS
       ========================================================= */

    private function sendVerificationEmail(int $userId, string $email): void
    {
        $pdo = Database::getConnection();

        $pdo->prepare(
            'DELETE FROM email_verifications WHERE user_id = :uid'
        )->execute([':uid' => $userId]);

        $token = bin2hex(random_bytes(32));

        $pdo->prepare(
            'INSERT INTO email_verifications
             (user_id, token, expires_at, created_at)
             VALUES (:uid, :token, :exp, NOW())'
        )->execute([
            ':uid'   => $userId,
            ':token' => $token,
            ':exp'   => date('Y-m-d H:i:s', strtotime('+24 hours'))
        ]);

        Config::load();
        $verifyLink =
            rtrim((string)Config::get('app.base_url'), '/') .
            '/verify-email/' . $token;

        Mailer::send(
            $email,
            'email.verify.subject',
            'email.verify.body',
            ['verify_link' => $verifyLink],
            Language::getDefault()
        );
    }
}
