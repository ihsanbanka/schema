<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: MyApplicationsController.php
 * Path: /app/controllers/MyApplicationsController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Talent Features Foundation)
 * Component        : My Applications (Talent)
 *
 * Purpose:
 * --------
 * - Entry point for Talent → My Applications
 * - Enforce authentication
 * - Enforce TALENT persona only
 * - Render placeholder view
 *
 * GOVERNANCE:
 * -----------
 * ✔ No business logic
 * ✔ No DB writes
 * ✔ No OAuth logic
 * ✔ Persona enforced via BaseController
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use RuntimeException;

final class MyApplicationsController extends BaseController
{
    /**
     * Route: GET /applications
     * Allowed persona: talent ONLY
     */
    public function index(): void
    {
        /**
         * STEP 1: Require authenticated user
         */
        $user = $this->requireUser();

        /**
         * STEP 2: Enforce TALENT persona
         */
        $this->requirePersona(['talent']);

        /**
         * STEP 3: Enforce email verification
         */
        if ((int) $user['is_email_verified'] !== 1) {
            throw new RuntimeException('Email not verified');
        }

        /**
         * STEP 4: Render My Applications placeholder
         */
        View::render(
            'applications/index',
            [
                'pageTitle' => 'My Applications — DCJOBS',
                'userEmail' => $user['email']
            ],
            'dashboard'
        );
    }
}
