<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: ResetPasswordController.php
 * Path: /app/controllers/ResetPasswordController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-6 (Password Recovery)
 * Component        : Password Reset Controller
 *
 * PURPOSE:
 * --------
 * - Show reset password form via token
 * - Validate token securely
 * - Allow password reset
 * - Invalidate token after use
 *
 * GOVERNANCE:
 * -----------
 * ✔ No auto-login
 * ✔ One-time token
 * ✔ Transaction-safe
 * ✔ Shared-hosting safe
 * ✔ No changes to existing controllers
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use DCJOBS\Core\Database;
use DCJOBS\Core\Logger;
use Throwable;

final class ResetPasswordController extends BaseController
{
    /**
     * Route:
     * - GET /reset-password/{token}
     * - GET /reset-password?token=xxxx
     */
    public function show(?string $token = null): void
    {
        // Allow token via query string OR route param
        $token = trim($token ?? ($_GET['token'] ?? ''));

        if ($token === '') {
            $this->renderResult(false, 'Invalid password reset link.');
            return;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            'SELECT pr.user_id, pr.expires_at, u.email
             FROM password_resets pr
             INNER JOIN users u ON u.id = pr.user_id
             WHERE pr.token = :token
             LIMIT 1'
        );
        $stmt->execute([':token' => $token]);
        $row = $stmt->fetch();

        if (!$row) {
            $this->renderResult(false, 'Password reset link is invalid or expired.');
            return;
        }

        if (strtotime($row['expires_at']) < time()) {
            $this->renderResult(false, 'Password reset link has expired.');
            return;
        }

        View::render('auth/reset-password', [
            'csrfToken' => $this->generateCsrfToken(),
            'token'     => $token,
            'email'     => $row['email']
        ]);
    }

    /**
     * Route: POST /reset-password
     */
    public function submit(): void
    {
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            $this->renderResult(false, 'Security validation failed.');
            return;
        }

        $token       = trim($_POST['token'] ?? '');
        $password    = $_POST['password'] ?? '';
        $confirmPass = $_POST['confirm_password'] ?? '';

        if ($token === '' || $password === '' || $confirmPass === '') {
            $this->renderResult(false, 'All fields are required.');
            return;
        }

        if ($password !== $confirmPass) {
            $this->renderResult(false, 'Passwords do not match.');
            return;
        }

        $pdo = Database::getConnection();

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                'SELECT user_id
                 FROM password_resets
                 WHERE token = :token
                   AND expires_at >= NOW()
                 LIMIT 1'
            );
            $stmt->execute([':token' => $token]);
            $row = $stmt->fetch();

            if (!$row) {
                $pdo->rollBack();
                $this->renderResult(false, 'Password reset token is invalid or expired.');
                return;
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            $pdo->prepare(
                'UPDATE users
                 SET password_hash = :hash
                 WHERE id = :uid'
            )->execute([
                ':hash' => $hash,
                ':uid'  => (int)$row['user_id']
            ]);

            $pdo->prepare(
                'DELETE FROM password_resets WHERE user_id = :uid'
            )->execute([
                ':uid' => (int)$row['user_id']
            ]);

            $pdo->commit();

            Logger::info('PASSWORD_RESET_SUCCESS', [
                'user_id' => (int)$row['user_id']
            ]);

            $this->renderResult(true, 'Your password has been reset successfully.');

        } catch (Throwable $e) {

            $pdo->rollBack();

            Logger::error('PASSWORD_RESET_FAILED', [
                'error' => $e->getMessage()
            ]);

            $this->renderResult(false, 'Password reset failed. Please try again.');
        }
    }

    /**
     * Shared result renderer
     */
    private function renderResult(bool $success, string $message): void
    {
        View::render('auth/reset-result', [
            'pageTitle' => 'Reset Password — DCJOBS',
            'success'   => $success,
            'message'   => $message
        ]);
    }
}
