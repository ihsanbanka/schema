<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: GroqController.php
 * Path: /app/controllers/GroqController.php
 *
 * Software Version : DCJOBS-CORE v1.0.2
 * Phase            : Phase-9 (AI Integration – Groq)
 *
 * Purpose:
 * --------
 * - Generate Job Description using Groq LLM
 * - Uses Job Title, Skills, Platform (ALL mandatory)
 * - Debug logging enabled
 *
 * Governance:
 * -----------
 * ✔ Session enforced
 * ✔ CSRF enforced
 * ✔ JSON only
 * ✔ No UI logic
 * ✔ No DB writes
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Config;

final class GroqController extends BaseController
{
    /**
     * POST /dashboard/groq/generate-job-description
     */
    public function generateJobDescription(): void
    {
        $this->requireUser();
        header('Content-Type: application/json; charset=utf-8');

        /* ================= CSRF ================= */
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            $this->log('ERROR', 'Invalid CSRF token');
            echo json_encode(['success' => false]);
            return;
        }

        /* ================= INPUT ================= */
        $jobTitle = trim($_POST['job_title'] ?? '');
        $platform = trim($_POST['platform'] ?? '');
        $skills   = $_POST['skills'] ?? [];

        $this->log('INFO', 'Incoming request', [
            'job_title' => $jobTitle,
            'platform'  => $platform,
            'skills'    => $skills
        ]);

        if ($jobTitle === '' || $platform === '' || empty($skills) || !is_array($skills)) {
            $this->log('ERROR', 'Missing required fields');
            echo json_encode(['success' => false]);
            return;
        }

        /* ================= CONFIG ================= */
        $apiKey = Config::get('groq_api_key');
        if (empty($apiKey)) {
            $this->log('CRITICAL', 'Groq API key missing');
            echo json_encode(['success' => false]);
            return;
        }

        /* ================= PROMPT ================= */
        $skillsList = implode(', ', array_map('trim', $skills));

        $prompt = <<<PROMPT
Create a realistic, industry-appropriate job description.

Job Title:
{$jobTitle}

Platform:
{$platform}

Skills:
{$skillsList}

Structure the output strictly as:

1. Job Overview / Summary
2. Key Responsibilities
3. Required Skills & Qualifications
4. Preferred Qualifications
5. Company / Platform Context (tailored to {$platform})
6. Benefits / Perks (if applicable)

Guidelines:
- Professional tone
- Bullet points where appropriate
- No marketing fluff
- No salary unless explicitly required
PROMPT;

        /* ================= GROQ CALL ================= */
        $payload = [
            'model' => 'llama-3.1-8b-instant', // ✅ STABLE MODEL
            'messages' => [
                ['role' => 'user', 'content' => $prompt]
            ],
            'temperature' => 0.4,
            'max_tokens'  => 900
        ];

        $ch = curl_init('https://api.groq.com/openai/v1/chat/completions');

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $apiKey,
                'Content-Type: application/json'
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 30
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($response === false) {
            $this->log('CRITICAL', 'Curl error', ['error' => curl_error($ch)]);
            curl_close($ch);
            echo json_encode(['success' => false]);
            return;
        }

        curl_close($ch);

        $this->log('INFO', 'Groq HTTP response', [
            'http_code' => $httpCode,
            'raw_body'  => $response
        ]);

        if ($httpCode !== 200) {
            echo json_encode(['success' => false]);
            return;
        }

        $decoded = json_decode($response, true);
        $content = $decoded['choices'][0]['message']['content'] ?? '';

        if (trim($content) === '') {
            $this->log('ERROR', 'Empty response from Groq');
            echo json_encode(['success' => false]);
            return;
        }

        echo json_encode([
            'success' => true,
            'content' => trim($content)
        ]);
    }

    /* ================= LOGGER ================= */
    private function log(string $level, string $message, array $context = []): void
    {
        $dir = DCJOBS_ROOT . '/logs/groq';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $line = sprintf(
            "[%s] [%s] %s %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            $context ? json_encode($context) : ''
        );

        file_put_contents($dir . '/groq.log', $line, FILE_APPEND | LOCK_EX);
    }
}
