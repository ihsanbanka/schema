<?php
declare(strict_types=1);

/**
 * DCJOBS — Global Error Controller
 * --------------------------------
 * File: ErrorController.php
 * Path: /app/controllers/ErrorController.php
 *
 * Purpose:
 * --------
 * - Handle invalid session / unauthorized access
 * - Provide single reusable error page
 *
 * Rules:
 * ------
 * ✔ Header + Footer included
 * ✔ No auth required
 * ✔ No business logic
 */

namespace DCJOBS\Controllers;

use DCJOBS\Core\View;

final class ErrorController
{
    /**
     * Route:
     * GET /error/session-expired
     */
    public function sessionExpired(): void
    {
        View::render(
            'errors/session_expired',
            [
                'pageTitle' => 'Session Expired'
            ],
            'public'
        );
    }
}
