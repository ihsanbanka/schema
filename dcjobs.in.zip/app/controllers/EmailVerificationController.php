<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: AuthController.php
 * Path: /app/controllers/AuthController.php
 *
 * Software Version : DCJOBS-CORE v1.22.3
 * Phase            : AUTH STABILIZATION (STEP C)
 * Component        : Authentication Controller
 *
 * GUARANTEES:
 * ✔ No role usage
 * ✔ No OAuth usage
 * ✔ No schema assumptions
 * ✔ All routes restored
 * ✔ All methods preserved
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use DCJOBS\Core\Database;
use DCJOBS\Core\Language;
use DCJOBS\Core\Mailer;
use DCJOBS\Core\Config;
use DCJOBS\Core\Logger;
use Throwable;

final class AuthController extends BaseController
{
    /* =========================================================
       LOGIN
       ========================================================= */

    public function login(): void
    {
        View::render('auth/login', [
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    public function loginPost(): void
    {
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            $this->renderLoginError('Security validation failed.');
            return;
        }

        $pdo      = Database::getConnection();
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email === '' || $password === '') {
            $this->renderLoginError('Email and password are required.');
            return;
        }

        $stmt = $pdo->prepare(
            'SELECT id, password_hash, is_active, is_email_verified, preferred_language
             FROM users
             WHERE email = :email
             LIMIT 1'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $this->renderLoginError('Invalid email or password.');
            return;
        }

        if ((int)$user['is_active'] !== 1) {
            $this->renderLoginError('Your account is disabled.');
            return;
        }

        if ((int)$user['is_email_verified'] !== 1) {
            View::render('auth/login', [
                'email'               => $email,
                'verificationPending' => true,
                'csrfToken'           => $this->generateCsrfToken()
            ]);
            return;
        }

        $_SESSION['user_id'] = (int)$user['id'];

        $_SESSION['language'] =
            !empty($user['preferred_language']) &&
            Language::isValid((string)$user['preferred_language'])
                ? (string)$user['preferred_language']
                : Language::getDefault();

        $this->rotateCsrfToken();
        header('Location: /dashboard');
        exit;
    }

    private function renderLoginError(string $message): void
    {
        View::render('auth/login', [
            'errorMessage' => $message,
            'csrfToken'    => $this->generateCsrfToken()
        ]);
    }

    /* =========================================================
       REGISTER
       ========================================================= */

    public function register(): void
    {
        View::render('auth/register', [
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    /**
     * NOTE:
     * BaseController MUST contain registerPost()
     * This controller depends on it.
     */
    public function registerPost(bool $isRecruiter = true): int
    {
        try {
            $userId = parent::registerPost($isRecruiter);
            $pdo    = Database::getConnection();

            $pdo->prepare(
                'DELETE FROM email_verifications WHERE user_id = :uid'
            )->execute([':uid' => $userId]);

            $token = bin2hex(random_bytes(32));

            $pdo->prepare(
                'INSERT INTO email_verifications
                 (user_id, token, expires_at, created_at)
                 VALUES (:uid, :token, :exp, NOW())'
            )->execute([
                ':uid'   => $userId,
                ':token' => $token,
                ':exp'   => date('Y-m-d H:i:s', strtotime('+24 hours'))
            ]);

            Config::load();
            $verifyLink =
                rtrim((string)Config::get('app.base_url'), '/') .
                '/verify-email/' . $token;

            $stmt = $pdo->prepare(
                'SELECT email, preferred_language
                 FROM users
                 WHERE id = :id
                 LIMIT 1'
            );
            $stmt->execute([':id' => $userId]);
            $user = $stmt->fetch();

            Mailer::send(
                $user['email'],
                'email.verify.subject',
                'email.verify.body',
                ['verify_link' => $verifyLink],
                $user['preferred_language'] ?? Language::getDefault()
            );

            View::render('auth/login', [
                'infoMessage' =>
                    'Registration successful. Please check your email to verify your account.',
                'csrfToken' => $this->generateCsrfToken()
            ]);

            return $userId;

        } catch (Throwable $e) {
            Logger::error('REGISTER_FAILED', ['error' => $e->getMessage()]);

            View::render('auth/register', [
                'errorMessage' => 'Registration failed. Please try again.',
                'csrfToken'    => $this->generateCsrfToken()
            ]);

            throw $e;
        }
    }

    /* =========================================================
       RESEND EMAIL VERIFICATION (RESTORED)
       ========================================================= */

    public function resendVerificationPost(): void
    {
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            View::render('auth/login', [
                'errorMessage' => 'Security validation failed.',
                'csrfToken'    => $this->generateCsrfToken()
            ]);
            return;
        }

        $email = trim($_POST['email'] ?? '');
        if ($email === '') {
            View::render('auth/login', [
                'errorMessage' => 'Email is required.',
                'csrfToken'    => $this->generateCsrfToken()
            ]);
            return;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            'SELECT id, is_email_verified, preferred_language
             FROM users
             WHERE email = :email
             LIMIT 1'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || (int)$user['is_email_verified'] === 1) {
            View::render('auth/login', [
                'infoMessage' =>
                    'If the email exists, a verification link has been sent.',
                'csrfToken' => $this->generateCsrfToken()
            ]);
            return;
        }

        $pdo->prepare(
            'DELETE FROM email_verifications WHERE user_id = :uid'
        )->execute([':uid' => $user['id']]);

        $token = bin2hex(random_bytes(32));

        $pdo->prepare(
            'INSERT INTO email_verifications
             (user_id, token, expires_at, created_at)
             VALUES (:uid, :token, :exp, NOW())'
        )->execute([
            ':uid'   => $user['id'],
            ':token' => $token,
            ':exp'   => date('Y-m-d H:i:s', strtotime('+24 hours'))
        ]);

        Config::load();
        $verifyLink =
            rtrim((string)Config::get('app.base_url'), '/') .
            '/verify-email/' . $token;

        Mailer::send(
            $email,
            'email.verify.subject',
            'email.verify.body',
            ['verify_link' => $verifyLink],
            $user['preferred_language'] ?? Language::getDefault()
        );

        View::render('auth/login', [
            'infoMessage' =>
                'A new verification email has been sent.',
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    /* =========================================================
       FORGOT / RESET PASSWORD
       ========================================================= */

    public function forgotPassword(): void
    {
        View::render('auth/forgot-password', [
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }

    public function forgotPasswordPost(): void
    {
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            View::render('auth/forgot-password', [
                'errorMessage' => 'Security validation failed.',
                'csrfToken'    => $this->generateCsrfToken()
            ]);
            return;
        }

        $email = trim($_POST['email'] ?? '');
        $pdo   = Database::getConnection();

        $stmt = $pdo->prepare(
            'SELECT id, preferred_language
             FROM users
             WHERE email = :email
               AND is_active = 1
             LIMIT 1'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if ($user) {
            $pdo->prepare(
                'DELETE FROM password_resets WHERE user_id = :uid'
            )->execute([':uid' => $user['id']]);

            $token = bin2hex(random_bytes(32));

            $pdo->prepare(
                'INSERT INTO password_resets
                 (user_id, token, expires_at, created_at)
                 VALUES (:uid, :token, :exp, NOW())'
            )->execute([
                ':uid'   => $user['id'],
                ':token' => $token,
                ':exp'   => date('Y-m-d H:i:s', strtotime('+1 hour'))
            ]);

            Config::load();
            $resetLink =
                rtrim((string)Config::get('app.base_url'), '/') .
                '/reset-password?token=' . $token;

            Mailer::send(
                $email,
                'email.reset.subject',
                'email.reset.body',
                ['reset_link' => $resetLink],
                $user['preferred_language'] ?? Language::getDefault()
            );
        }

        View::render('auth/forgot-password', [
            'infoMessage' =>
                'If an account exists for this email, a reset link has been sent.',
            'csrfToken' => $this->generateCsrfToken()
        ]);
    }
}
