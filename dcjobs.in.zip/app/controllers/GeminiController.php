<?php
declare(strict_types=1);

/**
 * DCJOBS — Gemini AI Controller (FINAL, RESPONSE-SAFE)
 * ---------------------------------------------------
 * File: GeminiController.php
 * Path: /app/controllers/GeminiController.php
 *
 * Software Version : DCJOBS-CORE v1.0.2
 */

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;

final class GeminiController extends BaseController
{
    /**
     * POST /dashboard/gemini/generate-job-description
     */
    public function generateJobDescription(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator', 'recruiter']);

        /* -----------------------------------------
           READ JSON INPUT
        ----------------------------------------- */
        $rawBody = file_get_contents('php://input');
        $data    = json_decode($rawBody, true);

        if (!is_array($data)) {
            $this->json(false, 'Invalid JSON payload');
        }

        /* -----------------------------------------
           CSRF
        ----------------------------------------- */
        if (!$this->validateCsrfToken($data['csrf_token'] ?? null)) {
            $this->json(false, 'Invalid CSRF token');
        }

        /* -----------------------------------------
           INPUT VALIDATION
        ----------------------------------------- */
        $jobTitle = trim((string)($data['job_title'] ?? ''));
        $skills   = $data['skills'] ?? [];
        $platform = trim((string)($data['platform'] ?? ''));

        if ($jobTitle === '' || $platform === '' || empty($skills) || !is_array($skills)) {
            $this->json(false, 'Missing required input');
        }

        /* -----------------------------------------
           PROMPT
        ----------------------------------------- */
        $prompt = sprintf(
            "You are a professional hiring expert.

Generate a job description using the following inputs:

Job Title: %s
Platform: %s
Skills: %s

Format EXACTLY as:

1. Job Description
2. Required Experience
3. Tools / Technologies Used

Rules:
- Professional tone
- Platform-specific
- No markdown
- No extra sections",
            $jobTitle,
            $platform,
            implode(', ', $skills)
        );

        /* -----------------------------------------
           GEMINI API
        ----------------------------------------- */
        $apiKey   = 'AIzaSyA7EzANnEZBcuVt5pwg7D1cRDYXpf_xaCA';
        $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

        $payload = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ]
        ];

        $ch = curl_init($endpoint);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'X-goog-api-key: ' . $apiKey
            ],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 30
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $httpCode !== 200) {
            $this->json(false, 'Gemini API connection failed');
        }

        $decoded = json_decode($response, true);

        /* -----------------------------------------
           HANDLE GEMINI ERRORS (200 BUT BLOCKED)
        ----------------------------------------- */
        if (isset($decoded['error'])) {
            $this->json(false, 'Gemini blocked content: ' . $decoded['error']['message']);
        }

        /* -----------------------------------------
           EXTRACT TEXT SAFELY (CRITICAL FIX)
        ----------------------------------------- */
        $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? null;

        if (!$text || !is_string($text)) {
            // DEV VISIBILITY (remove later)
            $this->json(false, 'Invalid Gemini response structure', [
                'raw_response' => $decoded
            ]);
        }

        /* -----------------------------------------
           SUCCESS
        ----------------------------------------- */
        $this->json(true, trim($text));
    }

    /**
     * JSON responder
     */
    private function json(bool $success, string $message, array $extra = []): void
    {
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode(array_merge([
            'success' => $success,
            $success ? 'content' : 'error' => $message
        ], $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        exit;
    }
}
