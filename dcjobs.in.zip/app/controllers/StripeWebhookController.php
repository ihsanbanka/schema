<?php
declare(strict_types=1);

/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: StripeWebhookController.php
 * Path: /app/controllers/StripeWebhookController.php
 *
 * Software Version : DCJOBS-CORE v1.2.0
 * Phase            : Phase-8 (Payments & Billing)
 * Component        : Stripe Webhook (HARDENED – PRODUCTION)
 *
 * PURPOSE:
 * --------
 * - Receive Stripe webhook events
 * - Verify Stripe signature (mandatory)
 * - Handle FREE and PAID billing entitlements
 * - Activate job / search entitlements
 * - Idempotent & retry-safe
 *
 * GOVERNANCE:
 * -----------
 * ✔ No auth
 * ✔ No CSRF
 * ✔ No UI rendering
 * ✔ Transaction-safe
 * ✔ Stripe retry compliant
 * ✔ Shared-hosting safe
 */

namespace DCJOBS\Controllers;

use DCJOBS\Core\Database;
use DCJOBS\Core\Config;
use PDO;
use RuntimeException;

final class StripeWebhookController
{
    /**
     * Route: POST /webhooks/stripe
     */
    public function handle(): void
    {
        $this->log('INFO', 'Webhook received');

        /* =====================================================
           STEP 1: RAW PAYLOAD & SIGNATURE
        ===================================================== */
        $payload   = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

        if ($payload === false || $signature === '') {
            $this->log('ERROR', 'Missing payload or signature');
            http_response_code(400);
            echo 'Invalid webhook';
            return;
        }

        /* =====================================================
           STEP 2: LOAD WEBHOOK SECRET
        ===================================================== */
        $webhookSecret = Config::get('stripe_webhook_secret');

        if (empty($webhookSecret)) {
            $this->log('CRITICAL', 'Stripe webhook secret not configured');
            http_response_code(500);
            echo 'Server misconfiguration';
            return;
        }

        /* =====================================================
           STEP 3: VERIFY SIGNATURE
        ===================================================== */
        if (!$this->verifySignature($payload, $signature, $webhookSecret)) {
            $this->log('WARNING', 'Invalid Stripe signature');
            http_response_code(400);
            echo 'Invalid signature';
            return;
        }

        /* =====================================================
           STEP 4: DECODE EVENT
        ===================================================== */
        $event = json_decode($payload, true);

        if (!is_array($event) || empty($event['type'])) {
            $this->log('ERROR', 'Malformed Stripe event');
            http_response_code(400);
            echo 'Invalid event';
            return;
        }

        $eventType = $event['type'];
        $this->log('INFO', 'Stripe event received', ['type' => $eventType]);

        /* =====================================================
           STEP 5: PROCESS ONLY SUCCESSFUL PAYMENTS
        ===================================================== */
        if ($eventType !== 'payment_intent.succeeded') {
            http_response_code(200);
            echo 'Event ignored';
            return;
        }

        $paymentIntent = $event['data']['object'] ?? [];
        $paymentId     = $paymentIntent['id'] ?? '';
        $metadata      = $paymentIntent['metadata'] ?? [];

        /* =====================================================
           STEP 6: VALIDATE METADATA (STRICT)
        ===================================================== */
        $jobId       = isset($metadata['job_id']) ? (int)$metadata['job_id'] : null;
        $userId      = isset($metadata['user_id']) ? (int)$metadata['user_id'] : null;
        $product     = $metadata['product'] ?? '';
        $productType = $metadata['product_type'] ?? '';

        if (
            empty($paymentId) ||
            empty($userId) ||
            empty($product) ||
            !in_array($productType, ['post_job', 'recruiter_search'], true)
        ) {
            $this->log('ERROR', 'Missing or invalid metadata', $metadata);
            http_response_code(400);
            echo 'Invalid metadata';
            return;
        }

        /* =====================================================
           STEP 7: DATABASE TRANSACTION (IDEMPOTENT)
        ===================================================== */
        $db = Database::getConnection();
        $db->beginTransaction();

        try {
            /* ---------------------------------------------
               STEP 7.1: DUPLICATE CHECK (CRITICAL)
            --------------------------------------------- */
            $check = $db->prepare(
                "SELECT id
                 FROM billing_transactions
                 WHERE stripe_payment_intent = :pid
                 LIMIT 1"
            );
            $check->execute(['pid' => $paymentId]);

            if ($check->fetchColumn()) {
                $db->rollBack();
                $this->log('INFO', 'Duplicate webhook ignored', ['payment_id' => $paymentId]);
                http_response_code(200);
                echo 'Already processed';
                return;
            }

            /* ---------------------------------------------
               STEP 7.2: FETCH BILLING PLAN
            --------------------------------------------- */
            $planStmt = $db->prepare(
                "SELECT billing_plan, job_charges, job_duration
                 FROM master_billing_table
                 WHERE billing_plan = :plan
                   AND job_type = :type
                   AND is_active = 1
                 LIMIT 1"
            );
            $planStmt->execute([
                'plan' => $product,
                'type' => $productType
            ]);

            $plan = $planStmt->fetch(PDO::FETCH_ASSOC);

            if (!$plan) {
                throw new RuntimeException('Billing plan not found');
            }

            /* ---------------------------------------------
               STEP 7.3: INSERT BILLING TRANSACTION
            --------------------------------------------- */
            $insert = $db->prepare(
                "INSERT INTO billing_transactions
                 (user_id, product, product_type, job_id,
                  amount_paid, currency, payment_method, payment_status,
                  stripe_payment_intent,
                  start_date, end_date, is_active)
                 VALUES
                 (:user_id, :product, :product_type, :job_id,
                  :amount_paid, 'INR', 'STRIPE', 'PAID',
                  :stripe_pid,
                  NOW(), DATE_ADD(NOW(), INTERVAL :duration DAY), 1)"
            );

            $insert->execute([
                'user_id'      => $userId,
                'product'      => $product,
                'product_type' => $productType,
                'job_id'       => $jobId,
                'amount_paid'  => $plan['job_charges'],
                'stripe_pid'   => $paymentId,
                'duration'     => (int)$plan['job_duration']
            ]);

            /* ---------------------------------------------
               STEP 7.4: ACTIVATE JOB (ONLY FOR post_job)
            --------------------------------------------- */
            if ($productType === 'post_job' && $jobId !== null) {
                $db->prepare(
                    "UPDATE job_detail
                     SET job_status = 'Active',
                         is_draft = 0,
                         updated_at = NOW()
                     WHERE job_id = :job_id"
                )->execute(['job_id' => $jobId]);
            }

            /* ---------------------------------------------
               STEP 7.5: COMMIT
            --------------------------------------------- */
            $db->commit();

            $this->log('SUCCESS', 'Webhook processed successfully', [
                'payment_id' => $paymentId,
                'user_id'    => $userId,
                'product'    => $product,
                'job_id'     => $jobId
            ]);

            http_response_code(200);
            echo 'Processed';

        } catch (\Throwable $e) {
            $db->rollBack();

            $this->log('CRITICAL', 'Webhook processing failed', [
                'error' => $e->getMessage(),
                'payment_id' => $paymentId
            ]);

            /* Stripe MUST retry */
            http_response_code(500);
            echo 'Processing failed';
        }
    }

    /* =========================================================
       SIGNATURE VERIFICATION
    ========================================================= */
    private function verifySignature(
        string $payload,
        string $header,
        string $secret
    ): bool {
        $parts = [];

        foreach (explode(',', $header) as $item) {
            [$k, $v] = explode('=', $item, 2);
            $parts[$k] = $v;
        }

        if (!isset($parts['t'], $parts['v1'])) {
            return false;
        }

        $signedPayload = $parts['t'] . '.' . $payload;
        $expected      = hash_hmac('sha256', $signedPayload, $secret);

        return hash_equals($expected, $parts['v1']);
    }

    /* =========================================================
       FILE LOGGER (SHARED HOSTING SAFE)
    ========================================================= */
    private function log(string $level, string $message, array $context = []): void
    {
        $logDir = DCJOBS_ROOT . '/logs/stripe';

        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }

        $line = sprintf(
            "[%s] [%s] %s %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            $context ? json_encode($context) : ''
        );

        file_put_contents(
            $logDir . '/webhook.log',
            $line,
            FILE_APPEND | LOCK_EX
        );
    }
}
