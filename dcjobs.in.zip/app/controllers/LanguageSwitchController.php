<?php
/**
 * DCJOBS — Language Switch Controller
 * ------------------------------------------------
 * File: LanguageSwitchController.php
 * Path: /app/controllers/LanguageSwitchController.php
 *
 * Software Version : DCJOBS-CORE v1.1.1
 * Phase            : Phase-6 (i18n foundation)
 *
 * Purpose:
 * --------
 * - Handle language switch POST action
 * - Validate CSRF token
 * - Validate language key against DB
 * - Persist selected language in session
 * - Persist language for logged-in users
 *
 * Governance:
 * -----------
 * ✔ No hardcoded languages
 * ✔ DB-driven validation
 * ✔ CSRF protected
 * ✔ Safe redirect
 * ✔ One file, complete logic
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\Language;

final class LanguageSwitchController extends BaseController
{
    /**
     * POST /language/switch
     */
    public function switch(): void
    {
        /* -------------------------------
           CSRF validation
        -------------------------------- */
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            http_response_code(400);
            echo 'Invalid request';
            return;
        }

        /* -------------------------------
           Validate language key
        -------------------------------- */
        $language = trim((string) ($_POST['language'] ?? ''));

        if ($language === '' || !Language::isValid($language)) {
            $this->safeRedirect();
            return;
        }

        /* -------------------------------
           Store in session (always)
        -------------------------------- */
        $_SESSION['language'] = $language;

        /* -------------------------------
           Persist for logged-in user
        -------------------------------- */
        if (!empty($_SESSION['user_id'])) {
            $pdo = Database::getConnection();

            $stmt = $pdo->prepare(
                'UPDATE users
                 SET preferred_language = :lang
                 WHERE id = :uid
                 LIMIT 1'
            );

            $stmt->execute([
                ':lang' => $language,
                ':uid'  => (int) $_SESSION['user_id']
            ]);
        }

        $this->safeRedirect();
    }

    /**
     * Safe redirect back to previous page
     * Prevents open redirect and loopback
     */
    private function safeRedirect(): void
    {
        $referer = $_SERVER['HTTP_REFERER'] ?? '/';
        $path = parse_url($referer, PHP_URL_PATH);

        if (!$path || str_starts_with($path, '/language')) {
            $path = '/';
        }

        header('Location: ' . $path);
        exit;
    }
}
