<?php
declare(strict_types=1);

/**
 * DCJOBS — Post Job Controller (COMPANY SAVE FIXED)
 * -------------------------------------------------
 * File: PostJobController.php
 * Path: /app/controllers/PostJobController.php
 *
 * Software Version : DCJOBS-CORE v1.0.6
 *
 * ✔ Save job as ACTIVE
 * ✔ Recruiter company fetched from companies table
 * ✔ Creator company taken from form
 * ✔ Stay on same page
 * ✔ Success message via session flash
 * ❌ No UI changes
 * ❌ No CSS changes
 * ❌ No AI changes
 */

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\View;
use PDO;
use RuntimeException;

final class PostJobController extends BaseController
{
    /* =========================================================
       GET — POST JOB FORM
    ========================================================= */
    public function index(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator', 'recruiter']);

        $pdo = Database::getConnection();

        $jobTitles = $pdo->query(
            "SELECT id, title
             FROM master_job_titles
             WHERE is_active = 1
             ORDER BY title"
        )->fetchAll(PDO::FETCH_ASSOC);

        $platforms = $pdo->query(
            "SELECT id, platform_name
             FROM master_platforms
             WHERE is_active = 1
             ORDER BY platform_name"
        )->fetchAll(PDO::FETCH_ASSOC);

        View::render(
            'postjob/form',
            [
                'pageTitle' => 'Post a Job',
                'csrfToken' => $this->generateCsrfToken(),
                'jobTitles' => $jobTitles,
                'platforms' => $platforms,
            ],
            'dashboard'
        );
    }

    /* =========================================================
       AJAX — FETCH SKILLS
    ========================================================= */
    public function fetchSkills(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator', 'recruiter']);

        header('Content-Type: application/json; charset=utf-8');

        $jobTitleId = (int)($_GET['job_title_id'] ?? 0);

        if ($jobTitleId <= 0) {
            echo json_encode([]);
            exit;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            "SELECT s.id, s.skill_name
             FROM job_title_skill_map m
             JOIN master_skills s ON s.id = m.skill_id
             WHERE m.job_title_id = :id
               AND m.is_active = 1
               AND s.is_active = 1
             ORDER BY s.skill_name"
        );

        $stmt->execute([':id' => $jobTitleId]);

        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        exit;
    }

    /* =========================================================
       POST — SAVE JOB (ACTIVE + STAY ON PAGE)
    ========================================================= */
    public function store(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator', 'recruiter']);

        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException('Invalid CSRF token');
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {

            $userId  = (int)$_SESSION['user_id'];
            $persona = $_SESSION['persona'];

            /* =====================================================
               COMPANY NAME RESOLUTION (FINAL LOGIC)
            ===================================================== */

            $companyName = null;

            if ($persona === 'recruiter') {

                // Get recruiter email
                $userStmt = $pdo->prepare(
                    "SELECT email
                     FROM users
                     WHERE id = :id
                     LIMIT 1"
                );
                $userStmt->execute([':id' => $userId]);
                $user = $userStmt->fetch(PDO::FETCH_ASSOC);

                if (!$user) {
                    throw new RuntimeException('User not found');
                }

                // Fetch company from companies table
                $companyStmt = $pdo->prepare(
                    "SELECT company_name
                     FROM companies
                     WHERE company_email = :email
                     LIMIT 1"
                );
                $companyStmt->execute([
                    ':email' => $user['email']
                ]);

                $company = $companyStmt->fetch(PDO::FETCH_ASSOC);

                if (!$company || empty($company['company_name'])) {
                    throw new RuntimeException('Company not found for recruiter');
                }

                $companyName = $company['company_name'];

            } else {
                // Creator manually enters
                $companyName = trim($_POST['company_name'] ?? '');
                if ($companyName === '') {
                    $companyName = null;
                }
            }

            /* =====================================================
               INSERT JOB (ACTIVE)
            ===================================================== */

            $stmt = $pdo->prepare(
                "INSERT INTO job_detail (
                    job_title_id,
                    skills,
                    job_type,
                    platform_id,
                    job_description,
                    company_name,
                    salary,
                    location,
                    remote_work,
                    job_status,
                    job_posted_by,
                    user_type,
                    is_draft
                ) VALUES (
                    :job_title_id,
                    :skills,
                    :job_type,
                    :platform_id,
                    :job_description,
                    :company_name,
                    :salary,
                    :location,
                    :remote_work,
                    'Active',
                    :job_posted_by,
                    :user_type,
                    0
                )"
            );

            $stmt->execute([
                ':job_title_id'    => (int)$_POST['job_title_id'],
                ':skills'          => json_encode($_POST['skills'] ?? []),
                ':job_type'        => $_POST['job_type'],
                ':platform_id'     => (int)$_POST['platform_id'],
                ':job_description' => $_POST['job_description'],
                ':company_name'    => $companyName,
                ':salary'          => $_POST['salary'] ?: null,
                ':location'        => $_POST['location'],
                ':remote_work'     => (int)$_POST['remote_work'],
                ':job_posted_by'   => $userId,
                ':user_type'       => $persona,
            ]);

            $jobId = (int)$pdo->lastInsertId();

            /* =====================================================
               CUSTOM QUESTIONS
            ===================================================== */

            if (!empty($_POST['custom_questions'])) {

                $qStmt = $pdo->prepare(
                    "INSERT INTO job_custom_questions
                     (job_id, question, answer_type, is_required)
                     VALUES (:job_id, :question, :answer_type, :is_required)"
                );

                foreach ($_POST['custom_questions'] as $q) {

                    if (empty($q['question']) || empty($q['answer_type'])) {
                        continue;
                    }

                    $answerType = $q['answer_type'] === 'yes_no'
                        ? 'radio'
                        : 'text';

                    $qStmt->execute([
                        ':job_id'      => $jobId,
                        ':question'    => trim($q['question']),
                        ':answer_type' => $answerType,
                        ':is_required' => !empty($q['mandatory']) ? 1 : 0,
                    ]);
                }
            }

            $pdo->commit();

            $_SESSION['job_saved_success'] = 'Job details saved successfully.';

            header('Location: /dashboard/post-job');
            exit;

        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
