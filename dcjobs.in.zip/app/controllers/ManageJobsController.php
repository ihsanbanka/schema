<?php
declare(strict_types=1);

/**
 * DCJOBS — Manage Jobs Controller
 * --------------------------------------------------
 * File: ManageJobsController.php
 * Path: /app/controllers/ManageJobsController.php
 *
 * Software Version: DCJOBS-CORE v1.1.0
 *
 * Scope:
 * ✔ Status filter (DB driven)
 * ✔ "Filter Jobs" display-only handling
 * ✔ All Status / Active / Hold / Closed support
 * ✔ Applicant count aggregation
 * ✔ Creator/Recruiter filtering only
 * ✔ Logging to /app/logs/app.log.log
 * ✔ No UI logic
 */

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\View;
use PDO;

final class ManageJobsController extends BaseController
{
    public function index(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator','recruiter']);

        $userId  = (int) $_SESSION['user_id'];
        $persona = $_SESSION['persona'];

        $pdo = Database::getConnection();

        /* ================= LOG ACCESS ================= */
        $this->log('INFO', 'ManageJobsController accessed', [
            'user_id' => $userId,
            'persona' => $persona
        ]);

        /* ================= FETCH STATUS LIST ================= */
        $statusStmt = $pdo->query(
            "SELECT status_key, status_label
             FROM master_job_status
             WHERE is_active = 1
             ORDER BY id"
        );

        $statuses = $statusStmt->fetchAll(PDO::FETCH_ASSOC);

        /* ================= CURRENT FILTER ================= */
        $currentStatus = $_GET['status'] ?? 'all';

        // Normalize empty or display-only value
        if ($currentStatus === '' || $currentStatus === 'Filter Jobs') {
            $currentStatus = 'all';
        }

        /* ================= JOB QUERY ================= */
        $params = [
            ':user_id' => $userId,
            ':persona' => $persona
        ];

        $whereStatus = '';

        if ($currentStatus !== 'all') {

            // Validate status exists in DB (security hardening)
            $validStatuses = array_column($statuses, 'status_key');

            if (in_array($currentStatus, $validStatuses, true)) {
                $whereStatus = " AND j.job_status = :status ";
                $params[':status'] = $currentStatus;
            } else {
                // Invalid status fallback
                $this->log('WARN', 'Invalid status filter used', [
                    'status' => $currentStatus
                ]);
                $currentStatus = 'all';
            }
        }

        $sql = "
            SELECT
                j.job_id,
                jt.title AS job_title,
                p.platform_name,
                j.job_type,
                j.job_status,
                COUNT(a.id) AS applicant_count
            FROM job_detail j
            JOIN master_job_titles jt ON jt.id = j.job_title_id
            JOIN master_platforms p ON p.id = j.platform_id
            LEFT JOIN job_applications a ON a.job_id = j.job_id
            WHERE j.job_posted_by = :user_id
              AND j.user_type = :persona
              $whereStatus
            GROUP BY j.job_id
            ORDER BY j.created_at DESC
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        /* ================= LOG RESULT ================= */
        $this->log('INFO', 'Jobs fetched', [
            'count' => count($jobs),
            'status_filter' => $currentStatus
        ]);

        /* ================= RENDER ================= */
        View::render(
            'managejobs/index',
            [
                'pageTitle'     => 'Manage Jobs',
                'statuses'      => $statuses,
                'jobs'          => $jobs,
                'currentStatus' => $currentStatus
            ],
            'dashboard'
        );
    }

    /* ================= LOGGER ================= */
    private function log(string $level, string $message, array $context = []): void
    {
        $dir = DCJOBS_ROOT . '/app/logs';

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $line = sprintf(
            "[%s] [%s] %s %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            $context ? json_encode($context) : ''
        );

        file_put_contents(
            $dir . '/app.log.log',
            $line,
            FILE_APPEND | LOCK_EX
        );
    }
}
