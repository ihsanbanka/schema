<?php
declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\View;
use PDO;
use RuntimeException;

final class TalentJobController extends BaseController
{
    /* =========================================================
       LIST JOBS (INDEX)
    ========================================================= */
    public function index(): void
    {
        $this->requireUser();
        $this->requirePersona(['talent']);

        $pdo = Database::getConnection();

        /* -------- Filters -------- */
        $selectedPlatforms = $_GET['platform'] ?? [];
        if (!is_array($selectedPlatforms)) {
            $selectedPlatforms = [];
        }

        $allowedPageSizes = [15, 20, 25];
        $pageSize = (int)($_GET['page_size'] ?? 15);
        if (!in_array($pageSize, $allowedPageSizes, true)) {
            $pageSize = 15;
        }

        $page   = max((int)($_GET['page'] ?? 1), 1);
        $offset = ($page - 1) * $pageSize;

        /* -------- Platform List -------- */
        $platforms = $pdo->query("
            SELECT id, platform_name
            FROM master_platforms
            WHERE is_active = 1
            ORDER BY platform_name
        ")->fetchAll(PDO::FETCH_ASSOC);

        /* -------- Build Query -------- */
        $where  = "WHERE j.job_status = 'Active' AND j.is_draft = 0";
        $params = [];

        if (!empty($selectedPlatforms)) {
            $placeholders = implode(',', array_fill(0, count($selectedPlatforms), '?'));
            $where .= " AND j.platform_id IN ($placeholders)";
            $params = array_map('intval', $selectedPlatforms);
        }

        /* -------- Count -------- */
        $countStmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM job_detail j
            $where
        ");
        $countStmt->execute($params);
        $totalJobs  = (int)$countStmt->fetchColumn();
        $totalPages = max((int)ceil($totalJobs / $pageSize), 1);

        /* -------- Fetch Jobs -------- */
        $stmt = $pdo->prepare("
            SELECT j.job_id,
                   jt.title AS job_title,
                   p.platform_name,
                   j.job_type,
                   j.location,
                   j.remote_work
            FROM job_detail j
            JOIN master_job_titles jt ON jt.id = j.job_title_id
            JOIN master_platforms p ON p.id = j.platform_id
            $where
            ORDER BY j.created_at DESC
            LIMIT $pageSize OFFSET $offset
        ");

        $stmt->execute($params);
        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        View::render(
            'talent/jobs/index',
            [
                'pageTitle'         => 'Find Jobs',
                'jobs'              => $jobs,
                'platforms'         => $platforms,
                'selectedPlatforms' => $selectedPlatforms,
                'pageSize'          => $pageSize,
                'currentPage'       => $page,
                'totalPages'        => $totalPages,
                'totalJobs'         => $totalJobs
            ],
            'dashboard'
        );
    }

    /* =========================================================
       VIEW JOB
    ========================================================= */
    public function view(): void
    {
        $this->requireUser();
        $this->requirePersona(['talent']);

        $jobId = (int)($_GET['job_id'] ?? 0);
        if ($jobId <= 0) {
            header('Location: /talent/jobs');
            exit;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare("
            SELECT j.*,
                   jt.title AS job_title,
                   p.platform_name
            FROM job_detail j
            JOIN master_job_titles jt ON jt.id = j.job_title_id
            JOIN master_platforms p ON p.id = j.platform_id
            WHERE j.job_id = :job_id
              AND j.job_status = 'Active'
              AND j.is_draft = 0
            LIMIT 1
        ");
        $stmt->execute([':job_id' => $jobId]);
        $job = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$job) {
            header('Location: /talent/jobs');
            exit;
        }

        /* Resolve Skills */
        $skillsDisplay = '';
        if (!empty($job['skills'])) {
            $ids = json_decode($job['skills'], true);
            if (is_array($ids) && $ids) {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $skillStmt = $pdo->prepare("
                    SELECT skill_name FROM master_skills
                    WHERE id IN ($placeholders)
                ");
                $skillStmt->execute($ids);
                $skillsDisplay = implode(', ', $skillStmt->fetchAll(PDO::FETCH_COLUMN));
            }
        }
        $job['skills_display'] = $skillsDisplay;

        /* Questions */
        $qStmt = $pdo->prepare("
            SELECT id, question, answer_type, is_required
            FROM job_custom_questions
            WHERE job_id = :job_id
            ORDER BY id ASC
        ");
        $qStmt->execute([':job_id' => $jobId]);
        $questions = $qStmt->fetchAll(PDO::FETCH_ASSOC);

        /* Already Applied */
        $checkStmt = $pdo->prepare("
            SELECT id FROM job_applications
            WHERE job_id = :job_id
              AND applicant_user_id = :uid
            LIMIT 1
        ");
        $checkStmt->execute([
            ':job_id' => $jobId,
            ':uid'    => $_SESSION['user_id']
        ]);
        $alreadyApplied = (bool)$checkStmt->fetchColumn();

        $successMessage = $_SESSION['apply_success'] ?? null;
        unset($_SESSION['apply_success']);

        $errorMessage = $_SESSION['apply_error'] ?? null;
        unset($_SESSION['apply_error']);

        View::render(
            'talent/jobs/view',
            [
                'pageTitle'      => 'View Job',
                'job'            => $job,
                'questions'      => $questions,
                'alreadyApplied' => $alreadyApplied,
                'successMessage' => $successMessage,
                'errorMessage'   => $errorMessage,
                'csrfToken'      => $this->generateCsrfToken()
            ],
            'dashboard'
        );
    }

    /* =========================================================
       APPLY
    ========================================================= */
    public function apply(): void
    {
        $this->requireUser();
        $this->requirePersona(['talent']);

        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException('Invalid CSRF token.');
        }

        $jobId = (int)($_POST['job_id'] ?? 0);
        if ($jobId <= 0) {
            header('Location: /talent/jobs');
            exit;
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {

            $answers = $_POST['answers'] ?? [];

            /* Check duplicate */
            $check = $pdo->prepare("
                SELECT id FROM job_applications
                WHERE job_id = :job_id
                  AND applicant_user_id = :uid
                LIMIT 1
            ");
            $check->execute([
                ':job_id' => $jobId,
                ':uid'    => $_SESSION['user_id']
            ]);

            if ($check->fetch()) {
                $_SESSION['apply_success'] = 'Already Applied.';
                header('Location: /talent/jobs/view?job_id=' . $jobId);
                exit;
            }

            /* Insert application */
            $pdo->prepare("
                INSERT INTO job_applications
                (job_id, applicant_user_id, application_status)
                VALUES (:job_id, :uid, 'applied')
            ")->execute([
                ':job_id' => $jobId,
                ':uid'    => $_SESSION['user_id']
            ]);

            $applicationId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare("
                INSERT INTO job_application_answers
                (application_id, job_id, question_id, answer_text)
                VALUES (:aid, :jid, :qid, :answer)
            ");

            foreach ($answers as $qid => $answer) {
                $stmt->execute([
                    ':aid'    => $applicationId,
                    ':jid'    => $jobId,
                    ':qid'    => (int)$qid,
                    ':answer' => trim((string)$answer)
                ]);
            }

            $pdo->commit();

            $_SESSION['apply_success'] = 'Applied Successfully.';
            header('Location: /talent/jobs/view?job_id=' . $jobId);
            exit;

        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
