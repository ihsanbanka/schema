<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: TalentDashboardController.php
 * Path: /app/controllers/TalentDashboardController.php
 *
 * Software Version : DCJOBS-CORE v1.2.4
 * Phase            : Phase-7.3 (Persona Middleware — CLEAN)
 *
 * ✔ OAuth already validates is_active + is_email_verified
 * ✔ No duplicate verification checks
 * ✔ Persona enforcement only
 * ✔ Session-safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;

final class TalentDashboardController extends BaseController
{
    /**
     * Route: GET /talent/dashboard
     * Persona: TALENT
     */
    public function index(): void
    {
        // 1️⃣ Require authenticated user
        $this->requireUser();

        // 2️⃣ Enforce persona
        $this->requirePersona(['talent']);

        // 3️⃣ Render dashboard
        View::render(
            'talent/dashboard',
            [
                'pageTitle' => 'Talent Dashboard — DCJOBS',
                'userEmail' => $_SESSION['user_email'] ?? '',
                'persona'   => $_SESSION['persona'] ?? '',
            ],
            'dashboard'
        );
    }
}
