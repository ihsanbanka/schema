<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: PortfolioController.php
 * Path: /app/controllers/PortfolioController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Talent Features)
 * Component        : Talent Portfolio Controller
 *
 * Purpose:
 * --------
 * - Entry point for Talent Portfolio
 * - Enforce authentication
 * - Enforce TALENT persona only
 *
 * GOVERNANCE:
 * -----------
 * ✔ No business logic
 * ✔ No OAuth logic
 * ✔ No DB writes
 * ✔ Persona enforced via BaseController
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use RuntimeException;

final class PortfolioController extends BaseController
{
    /**
     * Route: GET /portfolio
     * Allowed persona: talent ONLY
     */
    public function index(): void
    {
        /**
         * STEP 1: Require authenticated user
         */
        $user = $this->requireUser();

        /**
         * STEP 2: Enforce TALENT persona
         */
        $this->requirePersona(['talent']);

        /**
         * STEP 3: Enforce email verification
         */
        if ((int) $user['is_email_verified'] !== 1) {
            throw new RuntimeException('Email not verified');
        }

        /**
         * STEP 4: Render Portfolio placeholder
         */
        View::render(
            'portfolio/index',
            [
                'pageTitle' => 'My Portfolio — DCJOBS',
                'userEmail' => $user['email'],
                'userRole'  => 'talent'
            ],
            'dashboard'
        );
    }
}
