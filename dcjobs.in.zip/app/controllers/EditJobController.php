<?php
declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\View;
use PDO;
use RuntimeException;

final class EditJobController extends BaseController
{
    public function index(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator','recruiter']);

        $userId  = (int) $_SESSION['user_id'];
        $persona = $_SESSION['persona'];
        $jobId   = (int) ($_GET['job_id'] ?? 0);

        if ($jobId <= 0) {
            header('Location: /dashboard/manage-jobs');
            exit;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare("
            SELECT j.job_id,
                   j.company_name,
                   j.salary,
                   j.location,
                   j.remote_work,
                   j.job_type,
                   j.job_status,
                   j.job_description,
                   j.skills,
                   jt.title AS job_title,
                   p.platform_name
            FROM job_detail j
            JOIN master_job_titles jt ON jt.id = j.job_title_id
            JOIN master_platforms p ON p.id = j.platform_id
            WHERE j.job_id = :job_id
              AND j.job_posted_by = :user_id
              AND j.user_type = :persona
            LIMIT 1
        ");

        $stmt->execute([
            ':job_id' => $jobId,
            ':user_id' => $userId,
            ':persona' => $persona
        ]);

        $job = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$job) {
            header('Location: /dashboard/manage-jobs');
            exit;
        }

        /* Company fallback */
        if (empty($job['company_name']) && $persona === 'recruiter') {
            $job['company_name'] = $_SESSION['company_name'] ?? '';
        }

        /* Skills resolution */
        $skillsDisplay = '';
        if (!empty($job['skills'])) {
            $skillIds = json_decode((string)$job['skills'], true);
            if (is_array($skillIds) && count($skillIds) > 0) {
                $placeholders = implode(',', array_fill(0, count($skillIds), '?'));
                $skillStmt = $pdo->prepare("
                    SELECT skill_name
                    FROM master_skills
                    WHERE id IN ($placeholders)
                ");
                $skillStmt->execute($skillIds);
                $skillNames = $skillStmt->fetchAll(PDO::FETCH_COLUMN);
                if ($skillNames) {
                    $skillsDisplay = implode(', ', $skillNames);
                }
            }
        }
        $job['skills_display'] = $skillsDisplay;

        /* Questions */
        $qStmt = $pdo->prepare("
            SELECT id, question, answer_type, is_required
            FROM job_custom_questions
            WHERE job_id = :job_id
            ORDER BY id ASC
        ");
        $qStmt->execute([':job_id' => $jobId]);
        $questions = $qStmt->fetchAll(PDO::FETCH_ASSOC);

        /* Status */
        $statuses = $pdo->query("
            SELECT status_key, status_label
            FROM master_job_status
            WHERE is_active = 1
            ORDER BY id ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        View::render(
            'managejobs/edit',
            [
                'pageTitle' => 'Edit Job',
                'csrfToken' => $this->generateCsrfToken(),
                'job'       => $job,
                'questions' => $questions,
                'statuses'  => $statuses
            ],
            'dashboard'
        );
    }

    public function update(): void
    {
        $this->requireUser();
        $this->requirePersona(['creator','recruiter']);

        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException('Invalid CSRF token');
        }

        $userId  = (int) $_SESSION['user_id'];
        $persona = $_SESSION['persona'];
        $jobId   = (int) ($_POST['job_id'] ?? 0);

        if ($jobId <= 0) {
            header('Location: /dashboard/manage-jobs');
            exit;
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {

            /* Update job */
            $stmt = $pdo->prepare("
                UPDATE job_detail
                SET company_name = :company_name,
                    salary       = :salary,
                    location     = :location,
                    remote_work  = :remote_work,
                    job_type     = :job_type,
                    job_status   = :job_status,
                    updated_at   = NOW()
                WHERE job_id = :job_id
                  AND job_posted_by = :user_id
                  AND user_type = :persona
            ");

            $stmt->execute([
                ':company_name' => $_POST['company_name'] ?? null,
                ':salary'       => $_POST['salary'] ?? null,
                ':location'     => $_POST['location'],
                ':remote_work'  => (int) ($_POST['remote_work'] ?? 0),
                ':job_type'     => $_POST['job_type'],
                ':job_status'   => $_POST['job_status'],
                ':job_id'       => $jobId,
                ':user_id'      => $userId,
                ':persona'      => $persona
            ]);

            /* =========================
               FIX: SAVE CUSTOM QUESTIONS
            ========================== */

            // Delete existing questions
            $pdo->prepare("
                DELETE FROM job_custom_questions
                WHERE job_id = :job_id
            ")->execute([':job_id' => $jobId]);

            // Reinsert questions
            if (!empty($_POST['questions'])) {

                $insertQ = $pdo->prepare("
                    INSERT INTO job_custom_questions
                    (job_id, question, answer_type, is_required)
                    VALUES (:job_id, :question, :answer_type, :is_required)
                ");

                foreach ($_POST['questions'] as $q) {

                    if (empty(trim($q['question'] ?? ''))) {
                        continue;
                    }

                    $answerType = ($q['answer_type'] ?? 'text') === 'radio'
                        ? 'radio'
                        : 'text';

                    $insertQ->execute([
                        ':job_id'      => $jobId,
                        ':question'    => trim($q['question']),
                        ':answer_type' => $answerType,
                        ':is_required' => !empty($q['mandatory']) ? 1 : 0
                    ]);
                }
            }

            $pdo->commit();

            $_SESSION['success_message'] = 'Job updated successfully.';
            header('Location: /dashboard/edit-job?job_id=' . $jobId);
            exit;

        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
