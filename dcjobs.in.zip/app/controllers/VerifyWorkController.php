<?php
/**
 * DCJOBS — Verify Work Controller
 * --------------------------------------------
 * File: VerifyWorkController.php
 * Path: /app/controllers/VerifyWorkController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Feature Enforcement)
 * Component        : Verify Work (Creator Only)
 *
 * Purpose:
 * --------
 * - Entry point for creator work verification flow
 * - Enforce authentication
 * - Enforce email verification
 * - Enforce CREATOR persona ONLY
 *
 * GOVERNANCE:
 * -----------
 * ✔ No business logic
 * ✔ No OAuth logic
 * ✔ No DB writes
 * ✔ Persona enforced via BaseController
 * ✔ Uses user_roles → roles
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\View;
use RuntimeException;

final class VerifyWorkController extends BaseController
{
    /**
     * Route: GET /verify-work
     * Allowed persona: creator ONLY
     */
    public function index(): void
    {
        /**
         * STEP 1: Require authenticated user
         */
        $user = $this->requireUser();

        /**
         * STEP 2: Enforce CREATOR persona
         */
        $this->requirePersona(['creator']);

        /**
         * STEP 3: Enforce email verification
         */
        if ((int) $user['is_email_verified'] !== 1) {
            throw new RuntimeException('Email not verified');
        }

        /**
         * STEP 4: Render Verify Work placeholder
         */
        View::render(
            'creator/verify-work',
            [
                'pageTitle' => 'Verify Your Work — DCJOBS',
                'userEmail' => $user['email']
            ],
            'dashboard'
        );
    }
}
