<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: IntentController.php
 * Path: /app/controllers/IntentController.php
 *
 * Software Version : DCJOBS-CORE v1.3.0
 * Phase            : Phase-6 PART-1
 * Screen           : Screen-3 (Intent Routing Logic)
 *
 * Purpose:
 * --------
 * - Capture user intent from landing & hire flows
 * - Set intent safely in session
 * - Redirect to correct next screen
 *
 * Supported Intents:
 * ------------------
 * - recruiter → /login
 * - creator   → Google OAuth (later phase)
 * - talent    → Google OAuth (later phase)
 *
 * Governance:
 * -----------
 * ✔ No authentication logic
 * ✔ No database writes
 * ✔ Session-only intent storage
 * ✔ Flow-sequence enforced
 * ✔ Shared-hosting safe
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;

final class IntentController extends BaseController
{
    /**
     * Recruiter intent
     * Flow:
     * Landing → Hire → Company/Recruiter → Login
     *
     * GET /intent/recruiter
     */
    public function recruiter(): void
    {
        $this->startSession();

        $_SESSION['intent'] = 'recruiter';

        header('Location: /login', true, 302);
        exit;
    }

    /**
     * Creator intent
     * Flow:
     * Landing → Hire → Creator → Google OAuth (later)
     *
     * GET /intent/creator
     */
    public function creator(): void
    {
        $this->startSession();

        $_SESSION['intent'] = 'creator';

        // OAuth integration comes in later phase
        header('Location: /oauth/google', true, 302);
        exit;
    }

    /**
     * Talent intent
     * Flow:
     * Landing → Apply → Google OAuth (later)
     *
     * GET /intent/apply
     */
    public function apply(): void
    {
        $this->startSession();

        $_SESSION['intent'] = 'talent';

        // OAuth integration comes in later phase
        header('Location: /oauth/google', true, 302);
        exit;
    }

    /**
     * Safe session bootstrap
     */
    private function startSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    }
}
