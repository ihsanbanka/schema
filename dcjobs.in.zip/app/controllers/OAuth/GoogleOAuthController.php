<?php
declare(strict_types=1);

namespace DCJOBS\Controllers\OAuth;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use DCJOBS\Core\Crypto;
use DCJOBS\Core\Logger;
use RuntimeException;
use Throwable;

final class GoogleOAuthController extends BaseController
{
    public function start(): void
    {
        $intent = $_GET['intent'] ?? '';

        if (!in_array($intent, ['creator', 'talent'], true)) {
            http_response_code(400);
            echo 'Invalid OAuth intent';
            return;
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            'SELECT *
             FROM auth_settings
             WHERE provider = :provider
               AND is_enabled = 1
               AND environment = :env
             LIMIT 1'
        );
        $stmt->execute([
            ':provider' => 'google',
            ':env'      => 'production'
        ]);

        $config = $stmt->fetch();

        if (!$config) {
            throw new RuntimeException('Google OAuth is not configured.');
        }

        $statePayload = [
            'intent' => $intent,
            'ts'     => time()
        ];

        $state = Crypto::encrypt(json_encode($statePayload));
        $_SESSION['oauth_state'] = $state;

        $params = [
            'client_id'     => $config['client_id'],
            'redirect_uri'  => $config['redirect_uri'],
            'response_type' => 'code',
            'scope'         => implode(' ', json_decode($config['scopes'], true)),
            'state'         => $state,
            'access_type'   => 'offline',
            'prompt'        => 'consent'
        ];

        header(
            'Location: https://accounts.google.com/o/oauth2/v2/auth?' .
            http_build_query($params)
        );
        exit;
    }

    public function callback(): void
    {
        $pdo = Database::getConnection();

        try {

            if (
                empty($_GET['state']) ||
                empty($_SESSION['oauth_state']) ||
                $_GET['state'] !== $_SESSION['oauth_state']
            ) {
                throw new RuntimeException('Invalid OAuth state.');
            }

            $stateData = json_decode(
                Crypto::decrypt($_GET['state']),
                true
            );

            if (empty($stateData['intent'])) {
                throw new RuntimeException('OAuth intent missing.');
            }

            $intent = $stateData['intent'];

            if (empty($_GET['code'])) {
                throw new RuntimeException('Authorization code missing.');
            }

            /* LOAD GOOGLE CONFIG */
            $stmt = $pdo->prepare(
                'SELECT *
                 FROM auth_settings
                 WHERE provider = :provider
                   AND is_enabled = 1
                   AND environment = :env
                 LIMIT 1'
            );
            $stmt->execute([
                ':provider' => 'google',
                ':env'      => 'production'
            ]);

            $config = $stmt->fetch();
            if (!$config) {
                throw new RuntimeException('Google OAuth config not found.');
            }

            $clientSecret = Crypto::decrypt($config['client_secret']);

            /* TOKEN EXCHANGE */
            $tokenResponse = $this->httpPost(
                'https://oauth2.googleapis.com/token',
                [
                    'client_id'     => $config['client_id'],
                    'client_secret' => $clientSecret,
                    'code'          => $_GET['code'],
                    'redirect_uri'  => $config['redirect_uri'],
                    'grant_type'    => 'authorization_code'
                ]
            );

            if (empty($tokenResponse['access_token'])) {
                throw new RuntimeException('Access token not received.');
            }

            /* FETCH USER INFO */
            $userInfo = $this->httpGet(
                'https://openidconnect.googleapis.com/v1/userinfo',
                $tokenResponse['access_token']
            );

            if (empty($userInfo['email'])) {
                throw new RuntimeException('Email not provided by Google.');
            }

            $email = strtolower(trim($userInfo['email']));

            /* ==============================
               NEW: STRICT USER VALIDATION
            =============================== */

            $stmt = $pdo->prepare(
                'SELECT id, is_active, is_email_verified
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch();

            if (!$user) {
                header('Location: /error/account-not-found');
                exit;
            }

            if ((int)$user['is_active'] !== 1) {
                header('Location: /error/account-disabled');
                exit;
            }

            if ((int)$user['is_email_verified'] !== 1) {
                header('Location: /error/email-not-verified');
                exit;
            }

            $userId = (int)$user['id'];

            /* ROLE HANDLING */
            $stmt = $pdo->prepare(
                'SELECT 1
                 FROM user_roles ur
                 JOIN roles r ON r.id = ur.role_id
                 WHERE ur.user_id = :uid
                   AND r.role_key = :role
                 LIMIT 1'
            );
            $stmt->execute([
                ':uid'  => $userId,
                ':role' => $intent
            ]);

            if (!$stmt->fetchColumn()) {

                $stmt = $pdo->prepare(
                    'SELECT id FROM roles WHERE role_key = :role LIMIT 1'
                );
                $stmt->execute([':role' => $intent]);
                $roleId = $stmt->fetchColumn();

                if (!$roleId) {
                    throw new RuntimeException('Invalid role configuration.');
                }

                $stmt = $pdo->prepare(
                    'INSERT INTO user_roles (user_id, role_id)
                     VALUES (:uid, :rid)'
                );
                $stmt->execute([
                    ':uid' => $userId,
                    ':rid' => (int)$roleId
                ]);
            }

            /* SESSION */
            $_SESSION['user_id'] = $userId;
            $_SESSION['persona'] = $intent;

            unset($_SESSION['oauth_state']);

            header(
                'Location: ' . ($intent === 'talent'
                    ? '/talent/dashboard'
                    : '/dashboard')
            );
            exit;

        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            Logger::error('GOOGLE_OAUTH_FAILED', [
                'error' => $e->getMessage()
            ]);

            header('Location: /error/oauth-failed');
            exit;
        }
    }

    private function httpPost(string $url, array $data): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($data),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/x-www-form-urlencoded'
            ]
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode((string)$response, true) ?? [];
    }

    private function httpGet(string $url, string $token): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $token
            ]
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode((string)$response, true) ?? [];
    }
}
