<?php
/**
 * DCJOBS-CORE — Language Switch Controller
 * ------------------------------------------------
 * File: LanguageController.php
 * Path: /app/controllers/LanguageController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-6 (i18n foundation)
 *
 * Purpose:
 * --------
 * - Handle language change requests
 * - Validate against DB-driven languages
 * - Persist language in session
 * - Redirect back safely
 *
 * Governance:
 * -----------
 * ✔ POST only
 * ✔ CSRF protected
 * ✔ No hardcoded languages
 * ✔ Session-safe
 * ✔ Shared-hosting compatible
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Language;

final class LanguageController extends BaseController
{
    /**
     * Handle language switch
     * Route: POST /language/switch
     */
    public function switchPost(): void
    {
        // CSRF validation
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            $this->redirectBack();
            return;
        }

        $languageKey = trim($_POST['language'] ?? '');

        // Validate language against DB
        if ($languageKey !== '') {
            Language::set($languageKey);
        }

        $this->redirectBack();
    }

    /**
     * Safe redirect back to referring page
     */
    private function redirectBack(): void
    {
        $fallback = '/';

        $referer = $_SERVER['HTTP_REFERER'] ?? $fallback;

        // Prevent open redirect
        if (!str_starts_with($referer, '/')
            && !str_contains($referer, $_SERVER['HTTP_HOST'])
        ) {
            $referer = $fallback;
        }

        header('Location: ' . $referer);
        exit;
    }
}
