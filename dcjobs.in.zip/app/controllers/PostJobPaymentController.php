<?php
/**
 * DCJOBS — Stripe Payment Intent Controller
 * -----------------------------------------
 * File: PostJobPaymentController.php
 * Path: /app/controllers/PostJobPaymentController.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Purpose:
 * - Create Stripe PaymentIntent for job posting
 *
 * GOVERNANCE:
 * ✔ No secrets hardcoded
 * ✔ DB-driven config
 * ✔ Persona enforced
 */

declare(strict_types=1);

namespace DCJOBS\Controllers;

use DCJOBS\Core\BaseController;
use DCJOBS\Core\Database;
use RuntimeException;

final class PostJobPaymentController extends BaseController
{
    /**
     * Route: POST /dashboard/post-job/pay
     */
    public function createIntent(): void
    {
        $user = $this->requireUser();
        $this->requirePersona(['creator', 'recruiter']);

        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException('Invalid CSRF token');
        }

        $jobId = (int)($_POST['job_id'] ?? 0);
        if ($jobId <= 0) {
            throw new RuntimeException('Invalid job');
        }

        $pdo = Database::getConnection();

        /* -----------------------------------------
           Fetch billing + Stripe config
        ----------------------------------------- */
        $stmt = $pdo->prepare(
            'SELECT d.job_type,
                    b.job_charges,
                    s.secret_key,
                    s.currency
             FROM job_detail d
             JOIN master_billing_table b ON b.job_type = d.job_type
             JOIN payment_settings s ON s.provider = "stripe"
             WHERE d.job_id = :job_id
               AND d.is_draft = 1
             LIMIT 1'
        );
        $stmt->execute([':job_id' => $jobId]);
        $row = $stmt->fetch();

        if (!$row) {
            throw new RuntimeException('Billing configuration missing');
        }

        $amount = (float)$row['job_charges'];
        if ($amount <= 0) {
            throw new RuntimeException('Payment not required');
        }

        /* -----------------------------------------
           Create Stripe PaymentIntent
        ----------------------------------------- */
        require_once __DIR__ . '/../../vendor/stripe/init.php';
        \Stripe\Stripe::setApiKey($row['secret_key']);

        $intent = \Stripe\PaymentIntent::create([
            'amount'   => (int)round($amount * 100),
            'currency' => strtolower($row['currency']),
            'metadata' => [
                'job_id' => $jobId,
                'user_id' => (string)$user['id']
            ]
        ]);

        header('Content-Type: application/json');
        echo json_encode([
            'client_secret' => $intent->client_secret
        ]);
        exit;
    }
}
