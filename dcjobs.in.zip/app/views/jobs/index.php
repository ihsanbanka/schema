<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: index.php
 * Path: /app/views/jobs/index.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Talent Features)
 * Component        : Talent Find Jobs View
 *
 * Purpose:
 * --------
 * - Display available jobs for Talent (placeholder)
 * - Confirms routing & persona enforcement
 *
 * GOVERNANCE:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No logic
 * ✔ No role checks
 */

declare(strict_types=1);
?>

<section class="jobs-home">

    <div class="jobs-card">
        <h1>Find Jobs</h1>

        <p class="subtitle">
            Browse verified opportunities from creators and recruiters.
        </p>

        <div class="placeholder-box">
            <p>
                Available job listings will appear here.
            </p>
            <p>
                You’ll be able to search, filter, and apply to jobs
                in the next phase.
            </p>
        </div>
    </div>

</section>

<style>
/* ------------------------------
   Talent Find Jobs — Placeholder
   ------------------------------ */

.jobs-home {
    display: flex;
    justify-content: center;
    padding-top: 24px;
}

.jobs-card {
    background: #ffffff;
    border-radius: 14px;
    padding: 40px;
    max-width: 760px;
    width: 100%;
    box-shadow: 0 16px 36px rgba(15, 23, 42, 0.08);
}

.jobs-card h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #0f172a;
}

.subtitle {
    font-size: 0.95rem;
    color: #64748b;
    margin-bottom: 26px;
}

.placeholder-box {
    border: 1px dashed #c7d2fe;
    background: #f8fafc;
    padding: 24px;
    border-radius: 10px;
    color: #475569;
    font-size: 0.9rem;
    line-height: 1.6;
}
</style>
