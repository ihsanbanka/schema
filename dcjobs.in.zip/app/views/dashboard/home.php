<?php
declare(strict_types=1);

/**
 * DCJOBS — Dashboard Home View
 * ----------------------------------
 * File: home.php
 * Path: /app/views/dashboard/home.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 *
 * Purpose:
 * --------
 * - Dashboard landing screen for Creator / Recruiter
 * - Uses DASHBOARD layout ONLY
 * - NO header / footer / sidebar here
 *
 * Governance:
 * -----------
 * ✔ Layout-driven rendering
 * ✔ UI-only
 * ✔ No DB access
 * ✔ Defensive defaults
 */

/* ------------------------------
   SAFE DEFAULTS (NO WARNINGS)
------------------------------ */

// 7-day stats
$stats = array_merge(
    [
        'applied'     => 0,
        'interview'   => 0,
        'shortlisted' => 0,
        'hired'       => 0,
        'rejected'    => 0,
        'on_hold'     => 0,
    ],
    is_array($stats7d ?? null) ? $stats7d : []
);

// Points summary (creator only)
$points = is_array($pointsSummary ?? null) ? $pointsSummary : [];

$userRole = (string)($userRole ?? '');
?>

<!-- ===============================
     DASHBOARD: HOME
================================ -->

<section class="dashboard-card">

    <h2 class="section-title">Overview (Last 7 Days)</h2>

    <div class="stats-row">

        <div class="stat-card">
            <span class="stat-label">Applied</span>
            <span class="stat-value"><?= (int)$stats['applied'] ?></span>
        </div>

        <div class="stat-card">
            <span class="stat-label">Interviews</span>
            <span class="stat-value"><?= (int)$stats['interview'] ?></span>
        </div>

        <div class="stat-card">
            <span class="stat-label">Shortlisted</span>
            <span class="stat-value"><?= (int)$stats['shortlisted'] ?></span>
        </div>

        <div class="stat-card">
            <span class="stat-label">Hired</span>
            <span class="stat-value"><?= (int)$stats['hired'] ?></span>
        </div>

        <div class="stat-card">
            <span class="stat-label">Rejected</span>
            <span class="stat-value"><?= (int)$stats['rejected'] ?></span>
        </div>

        <div class="stat-card">
            <span class="stat-label">On Hold</span>
            <span class="stat-value"><?= (int)$stats['on_hold'] ?></span>
        </div>

    </div>
</section>

<?php if ($userRole === 'creator'): ?>
    <section class="dashboard-card">

        <h2 class="section-title">My Points</h2>

        <div class="points-grid">

            <div>
                <strong>Total Points</strong><br>
                <?= (int)($points['total_points'] ?? 0) ?>
            </div>

            <div>
                <strong>Total Value</strong><br>
                ₹<?= number_format((float)($points['total_value'] ?? 0), 2) ?>
            </div>

            <div>
                <strong>Fast Approvals</strong><br>
                <?= (int)($points['fast_approvals']['points'] ?? 0) ?>
            </div>

            <div>
                <strong>Normal Approvals</strong><br>
                <?= (int)($points['normal_approvals']['points'] ?? 0) ?>
            </div>

            <div class="expiring">
                <strong>Expiring Soon</strong><br>
                <?= htmlspecialchars(
                    (string)($points['expiring_soon']['date'] ?? '—'),
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </div>

        </div>
    </section>
<?php endif; ?>

<section class="placeholder-card">
    Upcoming widgets will appear here (recent applicants, activity feed, alerts).
</section>
