<?php
declare(strict_types=1);
?>

<h1>Talent Dashboard</h1>
<p>Welcome! Your talent dashboard is now active.</p>
