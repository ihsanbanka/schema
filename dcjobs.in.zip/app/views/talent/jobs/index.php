<?php
declare(strict_types=1);

/**
 * DCJOBS — Talent Job Listing
 * Path: /app/views/talent/jobs/index.php
 * Version: v1.0.0
 *
 * ✔ Platform multi-select
 * ✔ Page size selector (15,20,25)
 * ✔ Server-side pagination
 * ✔ Same UI feel as Post Job
 * ✔ Responsive
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$jobs              = $jobs ?? [];
$platforms         = $platforms ?? [];
$selectedPlatforms = $selectedPlatforms ?? [];
$pageSize          = $pageSize ?? 15;
$currentPage       = $currentPage ?? 1;
$totalPages        = $totalPages ?? 1;
$totalJobs         = $totalJobs ?? 0;
?>

<section class="postjob-container">

<header class="postjob-head">
    <h1>Find Jobs</h1>
    <p>Explore opportunities tailored for you.</p>
</header>

<!-- ================= FILTER SECTION ================= -->
<div class="postjob-card">
<form method="get" action="/talent/jobs">

<div class="filter-row">

<div class="form-group">
<label>Platform</label>
<select name="platform[]" multiple size="4">
<?php foreach ($platforms as $pl): ?>
<option value="<?= (int)$pl['id'] ?>"
<?= in_array($pl['id'], $selectedPlatforms) ? 'selected' : '' ?>>
<?= htmlspecialchars($pl['platform_name']) ?>
</option>
<?php endforeach; ?>
</select>
<small>Multiple selection allowed</small>
</div>

<div class="form-group">
<label>Page Size</label>
<select name="page_size">
<?php foreach ([15,20,25] as $size): ?>
<option value="<?= $size ?>"
<?= $pageSize === $size ? 'selected' : '' ?>>
<?= $size ?>
</option>
<?php endforeach; ?>
</select>
</div>

</div>

<div class="postjob-actions">
<button type="submit" class="btn-primary">Apply Filters</button>
</div>

</form>
</div>

<!-- ================= JOB TABLE ================= -->
<div class="postjob-card">

<h2>Available Jobs (<?= $totalJobs ?>)</h2>

<?php if (empty($jobs)): ?>

<p>No jobs found.</p>

<?php else: ?>

<div class="table-responsive">
<table class="job-table">
<thead>
<tr>
<th>Job Title</th>
<th>Platform</th>
<th>Job Type</th>
<th>Location</th>
<th>Remote</th>
<th>Action</th>
</tr>
</thead>
<tbody>

<?php foreach ($jobs as $job): ?>
<tr>
<td><?= htmlspecialchars($job['job_title']) ?></td>
<td><?= htmlspecialchars($job['platform_name']) ?></td>
<td><?= htmlspecialchars($job['job_type']) ?></td>
<td><?= htmlspecialchars($job['location']) ?></td>
<td><?= !empty($job['remote_work']) ? 'Yes' : 'No' ?></td>
<td>
<a href="/talent/jobs/view?job_id=<?= (int)$job['job_id'] ?>"
class="btn-secondary">
View
</a>
</td>
</tr>
<?php endforeach; ?>

</tbody>
</table>
</div>

<!-- ================= PAGINATION ================= -->
<div class="pagination">

<?php if ($currentPage > 1): ?>
<a href="?<?= http_build_query(array_merge($_GET, ['page'=>$currentPage-1])) ?>"
class="page-link">Previous</a>
<?php endif; ?>

<span class="page-info">
Page <?= $currentPage ?> of <?= $totalPages ?>
</span>

<?php if ($currentPage < $totalPages): ?>
<a href="?<?= http_build_query(array_merge($_GET, ['page'=>$currentPage+1])) ?>"
class="page-link">Next</a>
<?php endif; ?>

</div>

<?php endif; ?>

</div>

</section>

<style>
.postjob-container{max-width:1000px;margin:0 auto;color:#1F2937}
.postjob-head h1{font-size:2rem;margin-bottom:4px}
.postjob-head p{color:#6B7280;margin-bottom:24px}
.postjob-card{background:#FFF;border:1px solid #8B0036;border-radius:16px;padding:24px;margin-bottom:24px}
.form-group{margin-bottom:16px}
label{font-weight:600;display:block;margin-bottom:6px}
select{width:100%;padding:10px;border:1px solid #D1D5DB;border-radius:8px}
.filter-row{display:flex;gap:40px;flex-wrap:wrap}
.btn-primary{background:#2563EB;color:#fff;border:none;padding:10px 22px;border-radius:8px}
.btn-secondary{background:#2563EB;color:#fff;border:none;padding:6px 14px;border-radius:6px;text-decoration:none}
.postjob-actions{text-align:right;margin-top:10px}
.job-table{width:100%;border-collapse:collapse}
.job-table th,.job-table td{border-bottom:1px solid #E5E7EB;padding:12px;text-align:left}
.job-table th{background:#F9FAFB;font-weight:600}
.table-responsive{overflow-x:auto}
.pagination{display:flex;justify-content:space-between;align-items:center;margin-top:16px}
.page-link{color:#2563EB;text-decoration:none;font-weight:600}
.page-info{color:#6B7280}
@media(max-width:768px){
.filter-row{flex-direction:column}
.pagination{flex-direction:column;gap:10px}
}
</style>
