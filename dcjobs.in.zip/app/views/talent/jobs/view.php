<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$job            = $job ?? [];
$questions      = $questions ?? [];
$alreadyApplied = $alreadyApplied ?? false;
$successMessage = $successMessage ?? null;
$errorMessage   = $errorMessage ?? null;
$csrfToken      = $csrfToken ?? '';
?>

<section class="postjob-container">

<header class="postjob-head">
    <h1>Job Details</h1>
</header>

<!-- ================= JOB DETAILS ================= -->
<div class="postjob-card">

<h2>Job Information</h2>

<div class="row">
    <div class="col">
        <label>Job Title</label>
        <input type="text" value="<?= htmlspecialchars($job['job_title'] ?? '') ?>" readonly>
    </div>

    <div class="col">
        <label>Skills</label>
        <input type="text" value="<?= htmlspecialchars($job['skills_display'] ?? '') ?>" readonly>
    </div>
</div>

<div class="row">
    <div class="col">
        <label>Platform</label>
        <input type="text" value="<?= htmlspecialchars($job['platform_name'] ?? '') ?>" readonly>
    </div>

    <div class="col">
        <label>Job Type</label>
        <input type="text" value="<?= htmlspecialchars($job['job_type'] ?? '') ?>" readonly>
    </div>
</div>

<div class="row">
    <div class="col">
        <label>Location</label>
        <input type="text" value="<?= htmlspecialchars($job['location'] ?? '') ?>" readonly>
    </div>

    <div class="col">
        <label>Remote Work</label>
        <input type="text" value="<?= !empty($job['remote_work']) ? 'Yes' : 'No' ?>" readonly>
    </div>
</div>

<div class="full">
    <label>Job Description</label>
    <textarea rows="8" readonly><?= htmlspecialchars($job['job_description'] ?? '') ?></textarea>
</div>

</div>

<!-- ================= SUCCESS MESSAGE BELOW JOB DETAILS ================= -->
<?php if ($successMessage): ?>
<div class="postjob-card success-msg">
    <?= htmlspecialchars($successMessage) ?>
</div>
<?php endif; ?>

<!-- ================= APPLY SECTION ================= -->
<div class="postjob-card">

<h2>Apply for this Job</h2>

<?php if ($alreadyApplied && !$successMessage): ?>
<div class="already-applied">
    Already Applied.
</div>
<?php endif; ?>

<?php if ($errorMessage): ?>
<div class="error-msg">
    <?= htmlspecialchars($errorMessage) ?>
</div>
<?php endif; ?>

<?php if (!$alreadyApplied && !$successMessage): ?>

<form method="post" action="/talent/jobs/apply" id="applyForm">

<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
<input type="hidden" name="job_id" value="<?= (int)$job['job_id'] ?>">

<?php foreach ($questions as $q): ?>
<div class="form-group">
<label>
<?= htmlspecialchars($q['question']) ?>
<?= !empty($q['is_required']) ? '<span>*</span>' : '' ?>
</label>

<?php
$qid = (int)$q['id'];
$required = !empty($q['is_required']);
?>

<?php if ($q['answer_type'] === 'radio'): ?>

<label class="inline">
<input type="radio"
       name="answers[<?= $qid ?>]"
       value="Yes"
       <?= $required ? 'data-required="1"' : '' ?>>
Yes
</label>

<label class="inline">
<input type="radio"
       name="answers[<?= $qid ?>]"
       value="No"
       <?= $required ? 'data-required="1"' : '' ?>>
No
</label>

<?php else: ?>

<input type="text"
       name="answers[<?= $qid ?>]"
       <?= $required ? 'data-required="1"' : '' ?>>

<?php endif; ?>

</div>
<?php endforeach; ?>

<div class="postjob-actions">
<button type="submit" class="btn-primary">
Submit Application
</button>
</div>

</form>

<?php endif; ?>

</div>

</section>

<!-- ================= STYLES ================= -->
<style>
.postjob-container{max-width:920px;margin:0 auto;color:#1F2937}
.postjob-card{background:#fff;border:1px solid #8B0036;border-radius:16px;padding:24px;margin-bottom:24px}
.row{display:flex;gap:20px;margin-bottom:16px}
.col{flex:1}
.full{margin-top:16px}
input,textarea{width:100%;padding:10px;border:1px solid #D1D5DB;border-radius:8px}
textarea{resize:vertical}
.inline{margin-right:20px}
.success-msg{background:#ECFDF5;color:#065F46;font-weight:600}
.error-msg{background:#FEE2E2;color:#B91C1C;padding:12px;border-radius:8px;margin-bottom:16px}
.already-applied{background:#E0F2FE;color:#075985;padding:12px;border-radius:8px;font-weight:600}
.btn-primary{background:#2563EB;color:#fff;border:none;padding:12px 28px;border-radius:10px}
.postjob-actions{text-align:right;margin-top:20px}
label span{color:#DC2626}
</style>

<!-- ================= FRONTEND VALIDATION ================= -->
<script>
document.getElementById('applyForm')?.addEventListener('submit', function(e){

    const form = this;
    const groups = form.querySelectorAll('.form-group');

    for (let group of groups) {

        const label = group.querySelector('label');
        const requiredInputs = group.querySelectorAll('[data-required="1"]');

        if (requiredInputs.length === 0) continue;

        let valid = false;

        requiredInputs.forEach(input => {
            if ((input.type === 'radio' && input.checked) ||
                (input.type === 'text' && input.value.trim() !== '')
            ) {
                valid = true;
            }
        });

        if (!valid) {
            e.preventDefault();
            alert('Please select the field: ' + label.innerText.replace('*','').trim());
            return false;
        }
    }
});
</script>
