<?php
declare(strict_types=1);

/**
 * DCJOBS — Post Job Form
 * Version: v2.3.0 (FUNCTIONALITY RESTORED)
 *
 * ✔ Company Name before Salary
 * ✔ Recruiter readonly
 * ✔ Skills loading restored
 * ✔ Validation restored
 * ✔ AI generate restored
 * ✔ Custom questions working
 * ✔ UI unchanged
 */

$csrfToken   = (string)($csrfToken ?? '');
$jobTitles   = $jobTitles ?? [];
$platforms   = $platforms ?? [];

$userRole = $_SESSION['persona'] ?? '';
$companyName = $companyName ?? ($_SESSION['company_name'] ?? '');

$successMsg = $_SESSION['job_saved_success'] ?? '';
unset($_SESSION['job_saved_success']);
?>

<section class="postjob-container">

<header class="postjob-head">
    <h1>Post New Job</h1>
    <p>Fill out the form below to find your next great hire.</p>
</header>

<?php if ($successMsg): ?>
<div class="success-msg"><?= htmlspecialchars($successMsg) ?></div>
<?php endif; ?>

<form method="post" action="/dashboard/post-job/save" id="postJobForm" novalidate>
<input type="hidden" name="csrf_token" id="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

<!-- ================= JOB DETAILS ================= -->
<div class="postjob-card">
<h2>Job Details</h2>

<div class="form-group">
<label>Job Title <span>*</span></label>
<input type="text" id="jobTitleSearch" placeholder="Search job title…" autocomplete="off">
<select name="job_title_id" id="job_title" size="6" required>
<?php foreach ($jobTitles as $jt): ?>
<option value="<?= (int)$jt['id'] ?>">
<?= htmlspecialchars($jt['title']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label>Skills <span>*</span></label>
<select name="skills[]" id="skills" multiple required>
<option>Select Job Title First</option>
</select>
<small>Multiple selection allowed</small>
</div>

<div class="form-group">
<label>Job Type <span>*</span></label>
<select name="job_type" required>
<option value="">Select</option>
<option>Full-Time</option>
<option>Part-Time</option>
<option>Contract</option>
</select>
</div>

<div class="form-group">
<label>Platform <span>*</span></label>
<select name="platform_id" id="platform" required>
<option value="">Select Platform</option>
<?php foreach ($platforms as $pl): ?>
<option value="<?= (int)$pl['id'] ?>">
<?= htmlspecialchars($pl['platform_name']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label>Job Description <span>*</span></label>
<textarea name="job_description" id="job_description" rows="6" maxlength="2000" required></textarea>

<div class="ai-row">
<button type="button" id="aiGenerateBtn" class="btn-secondary">Generate with AI</button>
<span class="hint">Uses Job Title, Skills & Platform</span>
</div>

<div id="aiError" class="error-msg"></div>
</div>
</div>

<!-- ================= COMPENSATION ================= -->
<div class="postjob-card">
<h2>Compensation & Logistics</h2>

<div class="form-group">
<label>
Company Name <?= $userRole === 'recruiter' ? '<span>*</span>' : '' ?>
</label>

<input type="text"
       name="company_name"
       value="<?= htmlspecialchars($companyName) ?>"
       <?= $userRole === 'recruiter' ? 'readonly required' : '' ?>>
</div>

<div class="form-group">
<label>Salary</label>
<input type="number" name="salary" min="0" step="0.01">
</div>

<div class="form-group">
<label>Location <span>*</span></label>
<input type="text" name="location" maxlength="100" required>
</div>

<div class="form-group horizontal">
<label>Remote Work <span>*</span></label>
<label><input type="radio" name="remote_work" value="1" required> Yes</label>
<label><input type="radio" name="remote_work" value="0" required> No</label>
</div>

</div>

<!-- ================= CUSTOM QUESTIONS ================= -->
<div class="postjob-card">
<h2>Custom Questions</h2>

<div id="questionsContainer"></div>

<button type="button" id="addQuestionBtn" class="btn-secondary">
+ Add Question
</button>
</div>

<p class="mandatory-note">* Fields marked with * are mandatory.</p>

<div class="postjob-actions">
<button type="submit" class="btn-primary">Save</button>
</div>

</form>
</section>

<style>
/* SAME CSS AS BEFORE — UNCHANGED */
.postjob-container{max-width:920px;margin:0 auto;color:#1F2937}
.postjob-head h1{font-size:2rem;margin-bottom:4px}
.postjob-head p{color:#6B7280;margin-bottom:24px}
.postjob-card{background:#FFFFFF;border:1px solid #8B0036;border-radius:16px;padding:24px;margin-bottom:24px}
.postjob-card h2{color:#1F2937;margin-bottom:16px}
.form-group{margin-bottom:14px}
label{font-weight:600;display:block;margin-bottom:6px}
label span{color:#DC2626}
input,select,textarea{width:100%;padding:10px;border:1px solid #D1D5DB;border-radius:8px}
textarea{resize:vertical}
.horizontal{display:flex;align-items:center;gap:20px}
.ai-row{display:flex;gap:12px;align-items:center}
.btn-primary{background:#2563EB;color:#fff;border:none;padding:12px 28px;border-radius:10px}
.btn-secondary{background:#2563EB;color:#fff;border:none;padding:8px 14px;border-radius:8px}
.postjob-actions{text-align:right;margin-top:24px}
.error-msg{color:#DC2626;margin-top:6px}
.success-msg{background:#ECFDF5;color:#065F46;padding:12px;border-radius:8px;margin-bottom:16px}
.mandatory-note{color:#6B7280}
</style>

<script>

/* Job title search */
document.getElementById('jobTitleSearch').addEventListener('input', function(){
    const term = this.value.toLowerCase();
    document.querySelectorAll('#job_title option').forEach(o=>{
        o.style.display = o.text.toLowerCase().includes(term) ? '' : 'none';
    });
});

/* Fetch skills */
document.getElementById('job_title').addEventListener('change', function(){
    const s = document.getElementById('skills');
    s.innerHTML = '<option>Loading...</option>';

    fetch('/dashboard/post-job/skills?job_title_id=' + this.value)
        .then(r => r.json())
        .then(d => {
            s.innerHTML = '';
            if (!d.length) {
                s.innerHTML = '<option>No skills found</option>';
                return;
            }
            d.forEach(x => {
                const o = document.createElement('option');
                o.value = x.id;
                o.text  = x.skill_name;
                s.appendChild(o);
            });
        });
});

/* Custom questions */
let q = 0;
document.getElementById('addQuestionBtn').onclick = () => {
    q++;
    const c = document.createElement('div');
    c.innerHTML = `
    <div class="form-group">
        <label>Question ${q} <span>*</span></label>
        <input type="text" name="custom_questions[${q}][question]" required>

        <div class="form-group">
            <label>Answer Type <span>*</span></label>
            <select name="custom_questions[${q}][answer_type]" required>
                <option value="text">Text</option>
                <option value="yes_no">Yes / No</option>
            </select>
        </div>

        <div class="horizontal">
            <label>
                <input type="checkbox" name="custom_questions[${q}][mandatory]">
                Answer is mandatory
            </label>
            <button type="button" class="btn-secondary"
                onclick="this.closest('.form-group').remove()">Remove</button>
        </div>
    </div>`;
    document.getElementById('questionsContainer').appendChild(c);
};

/* AI Generate */
document.getElementById('aiGenerateBtn').onclick = () => {
    const err = document.getElementById('aiError');
    err.textContent = '';

    const jt = document.getElementById('job_title');
    const pf = document.getElementById('platform');
    const sk = [...document.getElementById('skills').selectedOptions];

    if (!jt.value || !pf.value || sk.length === 0) {
        err.textContent = 'Please select Job Title, Skills and Platform.';
        return;
    }

    const p = new URLSearchParams();
    p.append('csrf_token', document.getElementById('csrf_token').value);
    p.append('job_title', jt.selectedOptions[0].text);
    p.append('platform', pf.selectedOptions[0].text);
    sk.forEach(s => p.append('skills[]', s.text));

    fetch('/dashboard/groq/generate-job-description', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:p
    })
    .then(r=>r.json())
    .then(res=>{
        if(res.success){
            document.getElementById('job_description').value = res.content;
        }else{
            err.textContent = 'Please fill the job description manually.';
        }
    });
};

</script>
