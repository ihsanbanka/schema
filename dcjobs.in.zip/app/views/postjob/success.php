<?php
declare(strict_types=1);

/**
 * DCJOBS — Post Job (Success)
 * ---------------------------
 * File: success.php
 * Path: /app/views/postjob/success.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Post Job — Success UI
 *
 * Purpose:
 * --------
 * - Confirm job posted successfully
 * - Shown after FREE publish or Stripe payment success
 * - Provide clear next actions
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ No business logic
 * ✔ Dashboard layout
 */

/* ------------------------------
   SAFE DEFAULTS
------------------------------ */
$jobId = (int)($jobId ?? 0);
?>

<section class="postjob-shell success-shell">

    <div class="success-icon">✅</div>

    <h1 class="page-title">Job Posted Successfully</h1>

    <p class="page-subtitle">
        Your job has been published and is now visible to candidates.
    </p>

    <?php if ($jobId > 0): ?>
        <div class="job-ref">
            Job Reference ID: <strong>#<?= $jobId ?></strong>
        </div>
    <?php endif; ?>

    <div class="success-actions">

        <a href="/dashboard"
           class="btn-primary">
            Go to Dashboard
        </a>

        <a href="/jobs/manage"
           class="btn-secondary">
            Manage Jobs
        </a>

        <a href="/dashboard/post-job"
           class="btn-link">
            + Post Another Job
        </a>

    </div>

</section>

<style>
/* ==============================
   Post Job — Success Page
============================== */

.success-shell {
    max-width: 640px;
    margin: 80px auto;
    background: #ffffff;
    padding: 48px 40px;
    border-radius: 16px;
    text-align: center;
    box-shadow: 0 16px 40px rgba(0,0,0,0.08);
}

.success-icon {
    font-size: 3.5rem;
    margin-bottom: 16px;
}

.page-title {
    font-size: 1.9rem;
    margin-bottom: 10px;
}

.page-subtitle {
    color: #64748b;
    font-size: 1rem;
    margin-bottom: 24px;
}

.job-ref {
    background: #f1f5f9;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 30px;
    font-size: 0.95rem;
}

.success-actions {
    display: flex;
    flex-direction: column;
    gap: 14px;
    align-items: center;
}

.btn-primary {
    background: #2563eb;
    color: #ffffff;
    border: none;
    padding: 14px 28px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
}

.btn-secondary {
    background: #e5e7eb;
    color: #0f172a;
    border: none;
    padding: 12px 26px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
}

.btn-link {
    margin-top: 6px;
    font-size: 0.9rem;
    color: #2563eb;
    text-decoration: none;
    font-weight: 600;
}

.btn-link:hover {
    text-decoration: underline;
}

@media (max-width: 640px) {
    .success-shell {
        margin: 40px 16px;
        padding: 36px 24px;
    }
}
</style>
