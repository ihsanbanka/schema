<?php
declare(strict_types=1);

/**
 * DCJOBS — Post Job Billing
 * ------------------------
 * File: billing.php
 * Path: /app/views/postjob/billing.php
 *
 * Software Version : DCJOBS-CORE v1.2.0
 * Phase            : Post Job — Billing
 *
 * Governance:
 * ✔ Dashboard layout enforced
 * ✔ DB-driven plans
 * ✔ FREE + PAID unified
 * ✔ No direct access
 */

/* ---------------- SAFE DEFAULTS ---------------- */
$jobId        = (int)($jobId ?? 0);
$billingPlans = $billingPlans ?? [];
$csrfToken    = (string)($csrfToken ?? '');

if ($jobId <= 0) {
    echo '<p>Invalid job reference.</p>';
    return;
}
?>

<section class="billing-wrapper">

    <h1 class="billing-title">Billing & Confirmation</h1>
    <p class="billing-subtitle">
        Choose a plan to publish your job. FREE jobs also expire automatically.
    </p>

    <form method="post"
          action="/dashboard/post-job/billing"
          class="billing-form">

        <input type="hidden" name="csrf_token"
               value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">

        <input type="hidden" name="job_id" value="<?= $jobId ?>">

        <!-- ===================== PLANS ===================== -->
        <div class="billing-plans">

            <?php foreach ($billingPlans as $plan): ?>
                <?php
                    $isFree = ((float)$plan['job_charges'] <= 0);
                ?>
                <label class="billing-card">

                    <input type="radio"
                           name="billing_plan_id"
                           value="<?= (int)$plan['id'] ?>"
                           required>

                    <div class="billing-card-body">
                        <h3><?= htmlspecialchars($plan['billing_plan'], ENT_QUOTES, 'UTF-8') ?></h3>

                        <p class="price">
                            <?= $isFree
                                ? 'FREE'
                                : '₹' . number_format((float)$plan['job_charges'], 2)
                            ?>
                        </p>

                        <p class="duration">
                            Valid for <?= (int)$plan['job_duration'] ?> days
                        </p>

                        <?php if ($isFree): ?>
                            <span class="badge free">FREE</span>
                        <?php else: ?>
                            <span class="badge paid">PAID</span>
                        <?php endif; ?>
                    </div>

                </label>
            <?php endforeach; ?>

        </div>

        <!-- ===================== ACTIONS ===================== -->
        <div class="billing-actions">

            <a href="/dashboard/post-job"
               class="btn-secondary">
                ← Back to Post Job
            </a>

            <button type="submit" class="btn-primary">
                Continue & Publish →
            </button>

        </div>

    </form>

</section>

<!-- ========================== STYLES ========================== -->
<style>
.billing-wrapper {
    max-width: 900px;
    margin: 0 auto;
}

.billing-title {
    font-size: 2rem;
    margin-bottom: 6px;
}

.billing-subtitle {
    color: #64748b;
    margin-bottom: 28px;
}

.billing-plans {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.billing-card {
    background: #ffffff;
    border: 2px solid #e5e7eb;
    border-radius: 16px;
    padding: 22px;
    cursor: pointer;
    position: relative;
    transition: border 0.2s ease, box-shadow 0.2s ease;
}

.billing-card input {
    display: none;
}

.billing-card:hover {
    border-color: #2563eb;
}

.billing-card input:checked + .billing-card-body {
    border-color: #2563eb;
}

.billing-card-body h3 {
    margin-bottom: 8px;
    font-size: 1.15rem;
}

.price {
    font-size: 1.6rem;
    font-weight: 700;
    margin-bottom: 6px;
}

.duration {
    color: #64748b;
    font-size: 0.9rem;
}

.badge {
    position: absolute;
    top: 16px;
    right: 16px;
    font-size: 0.75rem;
    padding: 4px 10px;
    border-radius: 999px;
    font-weight: 700;
}

.badge.free {
    background: #ecfdf5;
    color: #065f46;
}

.badge.paid {
    background: #eff6ff;
    color: #1e3a8a;
}

.billing-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 32px;
}

.btn-primary {
    background: #2563eb;
    color: #ffffff;
    border: none;
    padding: 14px 28px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
}

.btn-primary:hover {
    background: #1d4ed8;
}

.btn-secondary {
    background: #e5e7eb;
    color: #0f172a;
    border: none;
    padding: 12px 22px;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
}

@media (max-width: 768px) {
    .billing-actions {
        flex-direction: column;
        gap: 14px;
        align-items: stretch;
    }
}
</style>
