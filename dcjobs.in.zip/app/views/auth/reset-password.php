<?php
/**
 * DCJOBS — Reset Password View
 * --------------------------------------------
 * File: reset-password.php
 * Path: /app/views/auth/reset-password.php
 *
 * Governance:
 * ✔ UI only
 * ✔ Logic untouched
 * ✔ CSRF protected
 * ✔ Mobile & cross-browser compliant
 * ✔ Matches login page UI exactly
 */

declare(strict_types=1);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1>Reset password</h1>
            <p>Please enter a new password for your account.</p>
        </header>

        <form method="post" action="/reset-password" class="auth-form" id="resetForm" novalidate>

            <input type="hidden"
                   name="csrf_token"
                   value="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">

            <input type="hidden"
                   name="token"
                   value="<?= htmlspecialchars($token ?? '', ENT_QUOTES, 'UTF-8') ?>">

            <div class="form-group">
                <label for="password">
                    New password <span class="required">*</span>
                </label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    required
                    minlength="8"
                    autocomplete="new-password">
            </div>

            <div class="form-group">
                <label for="confirm_password">
                    Confirm password <span class="required">*</span>
                </label>
                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    required
                    minlength="8"
                    autocomplete="new-password">
            </div>

            <div class="auth-error" id="passwordError" style="display:none;">
                Passwords do not match.
            </div>

            <button type="submit" class="btn-primary" id="submitBtn">
                Reset password
            </button>
        </form>

        <div class="auth-links">
            <a href="/login">Back to login</a>
        </div>

    </div>
</section>

<style>
/* =================================================
   AUTH — MATCHES LOGIN PAGE (PIXEL-COMPATIBLE)
   ================================================= */

* { box-sizing: border-box; }

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 16px;
}

.auth-card {
    width: 100%;
    max-width: 420px;
    background: #ffffff;
    border-radius: 14px;
    padding: 32px 28px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
}

/* Header */
.auth-header h1 {
    font-size: 1.8rem;
    margin-bottom: 6px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 24px;
}

/* Messages */
.auth-error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 16px;
}

/* Form */
.form-group {
    margin-bottom: 18px;
}

.auth-form label {
    display: block;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 6px;
    color: #0f172a;
}

.required { color: #dc2626; }

.auth-form input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    font-size: 0.95rem;
}

.auth-form input:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

/* Button */
.btn-primary {
    width: 100%;
    margin-top: 6px;
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: #2563eb;
    color: #ffffff;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
}

.btn-primary:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.btn-primary:hover:not(:disabled) {
    background: #1d4ed8;
}

/* Links */
.auth-links {
    margin-top: 16px;
    text-align: center;
}

.auth-links a {
    font-size: 0.85rem;
    color: #2563eb;
    font-weight: 600;
    text-decoration: none;
}

.auth-links a:hover {
    text-decoration: underline;
}

@media (min-width: 768px) {
    .auth-card { padding: 40px; }
}
</style>

<script>
const password = document.getElementById('password');
const confirmPassword = document.getElementById('confirm_password');
const error = document.getElementById('passwordError');
const submitBtn = document.getElementById('submitBtn');

function validatePasswords() {
    if (password.value && confirmPassword.value && password.value !== confirmPassword.value) {
        error.style.display = 'block';
        submitBtn.disabled = true;
    } else {
        error.style.display = 'none';
        submitBtn.disabled = false;
    }
}

password.addEventListener('input', validatePasswords);
confirmPassword.addEventListener('input', validatePasswords);
</script>
