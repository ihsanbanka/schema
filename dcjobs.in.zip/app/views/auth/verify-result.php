<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: verify-result.php
 * Path: /app/views/auth/verify-result.php
 *
 * Software Version : DCJOBS-CORE v1.9.8
 * Phase            : Phase-6 PART-2
 * Screen           : Email Verification Result
 *
 * Purpose:
 * --------
 * - Display email verification success or failure
 * - Provide clear next-step navigation
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ No session mutation
 * ✔ Consistent auth design
 */

declare(strict_types=1);

$success = (bool)($success ?? false);
$message = $message ?? ($success
    ? 'Your email address has been verified successfully.'
    : 'The verification link is invalid or has expired.'
);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1>
                <?= $success ? 'Email Verified' : 'Verification Failed' ?>
            </h1>
            <p>
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
            </p>
        </header>

        <div class="auth-actions">
            <?php if ($success): ?>
                <a href="/login" class="btn-primary">
                    Proceed to Login
                </a>
            <?php else: ?>
                <a href="/login" class="btn-outline">
                    Back to Login
                </a>
            <?php endif; ?>
        </div>

    </div>
</section>

<style>
/* ---------------------------------
   Email Verification Result UI
   --------------------------------- */

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 20px;
}

.auth-card {
    width: 100%;
    max-width: 420px;
    background: #ffffff;
    border-radius: 14px;
    padding: 40px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
    text-align: center;
}

.auth-header h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 30px;
    line-height: 1.6;
}

.auth-actions {
    margin-top: 10px;
}

.btn-primary,
.btn-outline {
    display: inline-block;
    padding: 14px 30px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 0.95rem;
    text-decoration: none;
    transition: all 0.2s ease;
}

.btn-primary {
    background: #2563eb;
    color: #ffffff;
}

.btn-primary:hover {
    background: #1d4ed8;
}

.btn-outline {
    border: 2px solid #2563eb;
    color: #2563eb;
}

.btn-outline:hover {
    background: #2563eb;
    color: #ffffff;
}
</style>
