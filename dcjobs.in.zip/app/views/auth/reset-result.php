<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * View: Reset Password Result
 * Path: /app/views/auth/reset-result.php
 *
 * Purpose:
 * - Display success / failure message after password reset
 *
 * Governance:
 * ✔ No logic
 * ✔ No DB access
 * ✔ XSS-safe output
 * ✔ Mobile-first
 */

declare(strict_types=1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($pageTitle ?? 'Reset Password — DCJOBS') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        body {
            margin: 0;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: #f5f6f8;
            color: #333;
        }
        .container {
            max-width: 420px;
            margin: 60px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            text-align: center;
        }
        h1 {
            font-size: 22px;
            margin-bottom: 15px;
        }
        p {
            font-size: 15px;
            line-height: 1.6;
        }
        .success {
            color: #1e7e34;
        }
        .error {
            color: #b02a37;
        }
        .btn {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 20px;
            background: #7a003c;
            color: #fff;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>

<body>
<div class="container">
    <h1 class="<?= $success ? 'success' : 'error' ?>">
        <?= $success ? 'Password Reset Successful' : 'Password Reset Failed' ?>
    </h1>

    <p>
        <?= htmlspecialchars($message ?? '') ?>
    </p>

    <a href="/login" class="btn">Go to Login</a>
</div>
</body>
</html>
