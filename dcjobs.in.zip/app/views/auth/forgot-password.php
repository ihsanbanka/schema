<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: forgot-password.php
 * Path: /app/views/auth/forgot-password.php
 *
 * Software Version : DCJOBS-CORE v1.14.0
 * Phase            : Phase-6 PART-3
 * Screen           : Forgot Password (Login-aligned, i18n-ready)
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ No session mutation
 * ✔ Security-first messaging
 * ✔ Mobile-first & cross-browser safe
 */

declare(strict_types=1);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1><?= htmlspecialchars(t('forgot.title'), ENT_QUOTES, 'UTF-8') ?></h1>
            <p><?= htmlspecialchars(t('forgot.subtitle'), ENT_QUOTES, 'UTF-8') ?></p>
        </header>

        <!-- ✅ INFO MESSAGE (generic success) -->
        <?php if (!empty($infoMessage ?? null)) : ?>
            <div class="auth-info">
                <?= htmlspecialchars($infoMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <!-- ❌ ERROR MESSAGE -->
        <?php if (!empty($errorMessage ?? null)) : ?>
            <div class="auth-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (empty($infoMessage ?? null)) : ?>
        <form method="post"
              action="/forgot-password"
              class="auth-form"
              id="forgotPasswordForm"
              novalidate>

            <!-- CSRF -->
            <input type="hidden"
                   name="csrf_token"
                   value="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">

            <div class="form-group">
                <label for="email">
                    <?= t('forgot.email.label') ?> <span class="required">*</span>
                </label>
                <input type="email"
                       id="email"
                       name="email"
                       placeholder="<?= t('forgot.email.placeholder') ?>"
                       required
                       value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>">
                <span class="field-error" id="emailError"></span>
            </div>

            <button type="submit" class="btn-primary" id="submitBtn">
                <?= t('forgot.button.submit') ?>
            </button>
        </form>
        <?php endif; ?>

        <div class="auth-links">
            <a href="/login"><?= t('forgot.back_to_login') ?></a>
        </div>

    </div>
</section>

<style>
/* =================================================
   AUTH — SAME SYSTEM AS LOGIN / REGISTER
   ================================================= */

* { box-sizing: border-box; }

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 16px;
}

.auth-card {
    width: 100%;
    max-width: 420px;
    background: #ffffff;
    border-radius: 14px;
    padding: 32px 28px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
}

/* Header */
.auth-header h1 {
    font-size: 1.9rem;
    margin-bottom: 6px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 24px;
}

/* Messages */
.auth-info {
    background: #e0f2fe;
    color: #075985;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 16px;
}

.auth-error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 16px;
}

/* Form */
.form-group {
    margin-bottom: 18px;
}

.auth-form label {
    display: block;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 6px;
    color: #0f172a;
}

.required {
    color: #dc2626;
    font-weight: 700;
}

.auth-form input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    font-size: 0.95rem;
}

.auth-form input.input-error {
    border-color: #b91c1c;
}

.auth-form input:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

/* Field error */
.field-error {
    display: block;
    margin-top: 6px;
    font-size: 0.8rem;
    color: #b91c1c;
}

/* Button */
.btn-primary {
    width: 100%;
    margin-top: 10px;
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: #2563eb;
    color: #ffffff;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
}

.btn-primary:hover {
    background: #1d4ed8;
}

.btn-primary:disabled {
    background: #94a3b8;
    cursor: not-allowed;
}

/* Links */
.auth-links {
    margin-top: 18px;
    text-align: center;
}

.auth-links a {
    font-size: 0.85rem;
    color: #2563eb;
    font-weight: 600;
    text-decoration: none;
}

.auth-links a:hover {
    text-decoration: underline;
}

/* Desktop refinement */
@media (min-width: 768px) {
    .auth-card {
        padding: 40px;
    }
}
</style>

<script>
/* Frontend validation + loading state */
document.getElementById('forgotPasswordForm')
    ?.addEventListener('submit', function (e) {

        const emailInput = document.getElementById('email');
        const emailError = document.getElementById('emailError');
        const submitBtn  = document.getElementById('submitBtn');

        emailError.textContent = '';
        emailInput.classList.remove('input-error');

        if (!emailInput.value.trim()) {
            emailError.textContent = '<?= t('forgot.error.email_required') ?>';
            emailInput.classList.add('input-error');
            emailInput.focus();
            e.preventDefault();
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = '<?= t('forgot.button.loading') ?>';
    });
</script>
