<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: verify-pending.php
 * Path: /app/views/auth/verify-pending.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-6 PART-2
 * Screen           : Screen-4 Email Verification Pending
 *
 * Purpose:
 * --------
 * - Inform user that email verification is required
 * - Guide user to check inbox
 * - Prevent access until verified
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ No session mutation
 * ✔ Professional & consistent design
 */

declare(strict_types=1);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1>Verify Your Email</h1>
            <p>
                Your account has been created successfully.
                Please verify your email address to continue.
            </p>
        </header>

        <div class="verify-info">
            <p>
                We’ve sent a verification link to your registered business email.
            </p>

            <p>
                Click the link in that email to activate your account.
            </p>

            <p class="note">
                Didn’t receive the email?  
                Check your spam folder or wait a few minutes.
            </p>
        </div>

        <div class="verify-actions">
            <a href="/login" class="btn-secondary">
                Back to Login
            </a>
        </div>

    </div>
</section>

<style>
/* ---------------------------------
   Email Verification Pending UI
   --------------------------------- */

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 20px;
}

.auth-card {
    width: 100%;
    max-width: 440px;
    background: #ffffff;
    border-radius: 14px;
    padding: 42px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
    text-align: center;
}

.auth-header h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 26px;
}

.verify-info p {
    font-size: 0.95rem;
    color: #334155;
    line-height: 1.6;
    margin-bottom: 14px;
}

.verify-info .note {
    font-size: 0.85rem;
    color: #64748b;
}

.verify-actions {
    margin-top: 28px;
}

.btn-secondary {
    display: inline-block;
    padding: 12px 24px;
    border-radius: 8px;
    background: #e2e8f0;
    color: #0f172a;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
    transition: background 0.2s ease;
}

.btn-secondary:hover {
    background: #cbd5e1;
}
</style>
