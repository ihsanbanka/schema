<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: resend-verification.php
 * Path: /app/views/auth/resend-verification.php
 *
 * Software Version : DCJOBS-CORE v1.19.1
 * Phase            : Phase-6 PART-4
 * Screen           : Resend Verification Email (i18n + RTL)
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ No session mutation
 * ✔ No user enumeration
 * ✔ Mobile-first & RTL-safe
 * ✔ i18n via t()
 */

declare(strict_types=1);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1><?= htmlspecialchars(t('resend.title'), ENT_QUOTES, 'UTF-8') ?></h1>
            <p><?= htmlspecialchars(t('resend.subtitle'), ENT_QUOTES, 'UTF-8') ?></p>
        </header>

        <?php if (!empty($infoMessage ?? null)) : ?>
            <div class="auth-info">
                <?= htmlspecialchars($infoMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errorMessage ?? null)) : ?>
            <div class="auth-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (empty($infoMessage ?? null)) : ?>
        <form method="post"
              action="/resend-verification"
              class="auth-form"
              novalidate>

            <input type="hidden"
                   name="csrf_token"
                   value="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">

            <div class="form-group">
                <label for="email">
                    <?= htmlspecialchars(t('resend.email.label'), ENT_QUOTES, 'UTF-8') ?>
                    <span class="required">*</span>
                </label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    placeholder="<?= htmlspecialchars(t('resend.email.placeholder'), ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <button type="submit" class="btn-primary">
                <?= htmlspecialchars(t('resend.submit'), ENT_QUOTES, 'UTF-8') ?>
            </button>
        </form>
        <?php endif; ?>

        <div class="auth-links">
            <a href="/login">
                <?= htmlspecialchars(t('resend.back_to_login'), ENT_QUOTES, 'UTF-8') ?>
            </a>
        </div>

    </div>
</section>

<style>
/* =========================================
   RESEND VERIFICATION — LOGIN UX STANDARD
   ========================================= */

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 16px;
}

.auth-card {
    width: 100%;
    max-width: 420px;
    background: #ffffff;
    border-radius: 14px;
    padding: 32px 28px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
}

.auth-header h1 {
    font-size: 1.8rem;
    margin-bottom: 6px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 24px;
}

/* Messages */
.auth-info {
    background: #e0f2fe;
    color: #075985;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 18px;
}

.auth-error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 18px;
}

/* Form */
.form-group {
    margin-bottom: 18px;
}

.auth-form label {
    display: block;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 6px;
    color: #0f172a;
}

.required {
    color: #dc2626;
}

.auth-form input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    font-size: 0.95rem;
}

.auth-form input:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

/* Button */
.btn-primary {
    width: 100%;
    margin-top: 6px;
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: #2563eb;
    color: #ffffff;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
}

.btn-primary:hover {
    background: #1d4ed8;
}

/* Links */
.auth-links {
    margin-top: 18px;
    text-align: center;
}

.auth-links a {
    font-size: 0.85rem;
    color: #2563eb;
    font-weight: 600;
    text-decoration: none;
}

.auth-links a:hover {
    text-decoration: underline;
}

/* Desktop refinement */
@media (min-width: 768px) {
    .auth-card {
        padding: 40px;
    }
}
</style>
