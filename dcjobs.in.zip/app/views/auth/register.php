<?php
declare(strict_types=1);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1><?= htmlspecialchars(t('register.title'), ENT_QUOTES, 'UTF-8') ?></h1>
            <p><?= htmlspecialchars(t('register.subtitle'), ENT_QUOTES, 'UTF-8') ?></p>
        </header>

        <?php if (!empty($errorMessage ?? null)) : ?>
            <div class="auth-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="post"
              action="/register"
              class="auth-form"
              id="registerForm"
              novalidate
              data-free-domains='<?= htmlspecialchars($freeEmailDomainsJson ?? "[]", ENT_QUOTES, "UTF-8") ?>'>

            <input type="hidden"
                   name="csrf_token"
                   value="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">

            <!-- Company details -->
            <div class="form-group">
                <label><?= t('register.company.name') ?> <span class="required">*</span></label>
                <input type="text" name="company_name" required>
            </div>

            <div class="form-group">
                <label><?= t('register.company.address') ?> <span class="required">*</span></label>
                <input type="text" name="company_address" required>
            </div>

            <div class="form-group">
                <label><?= t('register.company.phone') ?> <span class="required">*</span></label>
                <input type="text" name="company_phone" required>
            </div>

            <!-- Account -->
            <div class="form-group">
                <label><?= t('register.email') ?> <span class="required">*</span></label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label><?= t('register.confirm_email') ?> <span class="required">*</span></label>
                <input type="email" id="confirm_email" required>
                <span class="field-error" id="emailError"></span>
            </div>

            <div class="form-group">
                <label><?= t('register.password') ?> <span class="required">*</span></label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label><?= t('register.confirm_password') ?> <span class="required">*</span></label>
                <input type="password" id="confirm_password" required>
                <span class="field-error" id="passwordError"></span>
            </div>

            <button type="submit" class="btn-primary" id="registerBtn">
                <?= t('register.button.submit') ?>
            </button>
        </form>

        <div class="auth-register">
            <?= t('register.login.prompt') ?>
            <a href="/login"><?= t('register.login.link') ?></a>
        </div>

    </div>
</section>

<!-- =======================
     AUTH UI CSS (REGISTER)
     ======================= -->
<style>
* { box-sizing: border-box; }

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 16px;
}

.auth-card {
    width: 100%;
    max-width: 460px;
    background: #ffffff;
    border-radius: 14px;
    padding: 32px 28px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
}

.auth-header h1 {
    font-size: 1.8rem;
    margin-bottom: 6px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 24px;
}

.auth-error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 16px;
}

.form-group {
    margin-bottom: 18px;
}

.auth-form label {
    display: block;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 6px;
    color: #0f172a;
}

.required {
    color: #dc2626;
}

.auth-form input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    font-size: 0.95rem;
}

.auth-form input:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

.field-error {
    display: block;
    margin-top: 6px;
    font-size: 0.8rem;
    color: #b91c1c;
}

.btn-primary {
    width: 100%;
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: #2563eb;
    color: #ffffff;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
}

.btn-primary:hover {
    background: #1d4ed8;
}

.auth-register {
    text-align: center;
    margin-top: 18px;
    font-size: 0.85rem;
}

.auth-register a {
    color: #2563eb;
    font-weight: 600;
    text-decoration: none;
}

.auth-register a:hover {
    text-decoration: underline;
}

@media (min-width: 768px) {
    .auth-card {
        padding: 40px;
    }
}
</style>

<script>
/* =========================================================
   Recruiter Domain Validation — DB Driven
   ========================================================= */
(function () {
    const form = document.getElementById('registerForm');
    const blockedDomains = JSON.parse(form.dataset.freeDomains || '[]');

    const email = document.getElementById('email');
    const confirmEmail = document.getElementById('confirm_email');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm_password');

    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const btn = document.getElementById('registerBtn');

    function isBlocked(email) {
        const parts = email.split('@');
        return parts.length !== 2 || blockedDomains.includes(parts[1].toLowerCase());
    }

    form.addEventListener('submit', function (e) {
        let valid = true;

        emailError.textContent = '';
        passwordError.textContent = '';

        if (email.value !== confirmEmail.value) {
            emailError.textContent = 'Email addresses do not match.';
            valid = false;
        }

        if (email.value && isBlocked(email.value)) {
            emailError.textContent =
                'Please use your company email address. Free email domains are not allowed.';
            valid = false;
        }

        if (password.value !== confirmPassword.value) {
            passwordError.textContent = 'Passwords do not match.';
            valid = false;
        }

        if (!valid) {
            e.preventDefault();
            return;
        }

        btn.disabled = true;
        btn.innerText = 'Processing...';
    });
})();
</script>
