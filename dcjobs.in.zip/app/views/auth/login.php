<?php
declare(strict_types=1);
?>

<section class="auth-wrapper">
    <div class="auth-card">

        <header class="auth-header">
            <h1><?= htmlspecialchars(t('login.title'), ENT_QUOTES, 'UTF-8') ?></h1>
            <p><?= htmlspecialchars(t('login.subtitle'), ENT_QUOTES, 'UTF-8') ?></p>
        </header>

        <?php if (!empty($infoMessage ?? null)) : ?>
            <div class="auth-info">
                <?= htmlspecialchars($infoMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($errorMessage ?? null) && empty($verificationPending ?? false)) : ?>
            <div class="auth-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($verificationPending ?? false)) : ?>
            <div class="auth-warning">
                <strong><?= htmlspecialchars(t('login.verify.title'), ENT_QUOTES, 'UTF-8') ?></strong><br>
                <?= htmlspecialchars(t('login.verify.message'), ENT_QUOTES, 'UTF-8') ?>
            </div>

            <div class="auth-resend">
                <form method="post" action="/resend-verification">
                    <input type="hidden" name="csrf_token"
                           value="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="email"
                           value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>">

                    <button type="submit" class="link-button">
                        <?= htmlspecialchars(t('login.verify.resend'), ENT_QUOTES, 'UTF-8') ?>
                    </button>
                </form>
            </div>
        <?php endif; ?>

        <form method="post"
              action="/login"
              class="auth-form"
              id="loginForm"
              novalidate
              data-free-domains='<?= htmlspecialchars($freeEmailDomainsJson ?? "[]", ENT_QUOTES, "UTF-8") ?>'>

            <input type="hidden" name="csrf_token"
                   value="<?= htmlspecialchars($csrfToken ?? '', ENT_QUOTES, 'UTF-8') ?>">

            <div class="form-group">
                <label>
                    <?= htmlspecialchars(t('login.email.label'), ENT_QUOTES, 'UTF-8') ?>
                    <span class="required">*</span>
                </label>
                <input type="email" id="email" name="email" required
                       value="<?= htmlspecialchars($email ?? '', ENT_QUOTES, 'UTF-8') ?>">
                <span class="field-error" id="emailError"></span>
            </div>

            <div class="form-group">
                <label>
                    <?= htmlspecialchars(t('login.password.label'), ENT_QUOTES, 'UTF-8') ?>
                    <span class="required">*</span>
                </label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="btn-primary" id="loginBtn">
                <?= htmlspecialchars(t('login.button.submit'), ENT_QUOTES, 'UTF-8') ?>
            </button>
        </form>

        <div class="auth-links">
            <a href="/forgot-password">
                <?= htmlspecialchars(t('login.forgot'), ENT_QUOTES, 'UTF-8') ?>
            </a>
        </div>

        <div class="auth-register">
            <?= htmlspecialchars(t('login.register.prompt'), ENT_QUOTES, 'UTF-8') ?>
            <a href="/register">
                <?= htmlspecialchars(t('login.register.link'), ENT_QUOTES, 'UTF-8') ?>
            </a>
        </div>

    </div>
</section>

<!-- =======================
     AUTH UI CSS (FIXED)
     ======================= -->
<style>
* { box-sizing: border-box; }

.auth-wrapper {
    min-height: 100vh;
    background: #f8fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 16px;
}

.auth-card {
    width: 100%;
    max-width: 420px;
    background: #ffffff;
    border-radius: 14px;
    padding: 32px 28px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
}

.auth-header h1 {
    font-size: 1.8rem;
    margin-bottom: 6px;
    color: #0f172a;
}

.auth-header p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 24px;
}

.auth-info {
    background: #e0f2fe;
    color: #075985;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 16px;
}

.auth-error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 16px;
}

.auth-warning {
    background: #fff7ed;
    color: #9a3412;
    padding: 12px 14px;
    border-radius: 8px;
    font-size: 0.9rem;
    margin-bottom: 12px;
}

.form-group {
    margin-bottom: 18px;
}

.auth-form label {
    display: block;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 6px;
    color: #0f172a;
}

.required { color: #dc2626; }

.auth-form input {
    width: 100%;
    padding: 12px 14px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    font-size: 0.95rem;
}

.auth-form input:focus {
    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

.field-error {
    display: block;
    margin-top: 6px;
    font-size: 0.8rem;
    color: #b91c1c;
}

.btn-primary {
    width: 100%;
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: #2563eb;
    color: #ffffff;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
}

.btn-primary:hover {
    background: #1d4ed8;
}

.auth-links,
.auth-register {
    text-align: center;
    margin-top: 16px;
    font-size: 0.85rem;
}

.auth-links a,
.auth-register a {
    color: #2563eb;
    font-weight: 600;
    text-decoration: none;
}

.auth-links a:hover,
.auth-register a:hover {
    text-decoration: underline;
}

@media (min-width: 768px) {
    .auth-card { padding: 40px; }
}
</style>

<script>
/* Recruiter Login — Company Email Enforcement */
(function () {
    const form = document.getElementById('loginForm');
    const blockedDomains = JSON.parse(form.dataset.freeDomains || '[]');

    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const btn = document.getElementById('loginBtn');

    function isBlockedDomain(email) {
        const parts = email.split('@');
        return parts.length !== 2 || blockedDomains.includes(parts[1].toLowerCase());
    }

    form.addEventListener('submit', function (e) {
        emailError.textContent = '';

        if (emailInput.value && isBlockedDomain(emailInput.value)) {
            emailError.textContent =
                'Recruiters must log in using a company email address.';
            e.preventDefault();
            return;
        }

        btn.disabled = true;
        btn.innerText = 'Signing in...';
    });
})();
</script>
