<?php
/**
 * DCJOBS — Global Header
 * ------------------------------------------------
 * File: header.php
 * Path: /app/views/layouts/header.php
 *
 * Software Version : DCJOBS-CORE v1.1.0
 * Phase            : Phase-6 (Layout + i18n)
 *
 * Governance:
 * -----------
 * ✔ DB-driven languages
 * ✔ Auth-aware
 * ✔ Mobile-first
 * ✔ CSRF protected
 * ✔ i18n-ready (t())
 * ✔ Defensive rendering
 */

declare(strict_types=1);

use DCJOBS\Core\Language;

/* -------------------------------
   Fetch language data safely
-------------------------------- */
$languages   = Language::getAll();
$currentLang = Language::getCurrent();
$isLoggedIn  = !empty($_SESSION['user_id']);
$csrfToken   = $_SESSION['_csrf_token'] ?? '';
?>
<header style="background:#970747;">
    <div class="container"
         style="display:flex;
                align-items:center;
                justify-content:space-between;
                padding:12px 16px;
                flex-wrap:wrap;
                gap:12px;">

        <!-- Logo -->
        <a href="/"
           style="color:#ffffff;
                  font-weight:700;
                  font-size:1.2rem;
                  text-decoration:none;">
            DCJOBS
        </a>

        <!-- Right Controls -->
        <div style="display:flex;align-items:center;gap:16px;">

            <!-- Language Switcher -->
            <form method="post" action="/language/switch">
                <input type="hidden"
                       name="csrf_token"
                       value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">

                <select name="language"
                        onchange="this.form.submit()"
                        aria-label="<?= htmlspecialchars(t('header.language'), ENT_QUOTES, 'UTF-8') ?>"
                        style="padding:6px 8px;
                               border-radius:6px;
                               border:none;
                               font-size:0.85rem;
                               cursor:pointer;">

                    <?php foreach ($languages as $lang): ?>
                        <?php
                        $key = (string) ($lang['language_key'] ?? '');
                        $label = trim(
                            (string) ($lang['native_name'] ?? '') . ' ' .
                            (string) ($lang['language_name'] ?? '')
                        );
                        ?>
                        <option value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"
                            <?= $key === $currentLang ? 'selected' : '' ?>>
                            <?= htmlspecialchars($label !== '' ? $label : $key, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>

                </select>
            </form>

            <!-- Logout (post-login only) -->
            <?php if ($isLoggedIn): ?>
                <a href="/logout"
                   style="color:#ffffff;
                          font-size:0.85rem;
                          text-decoration:none;
                          font-weight:600;">
                    <?= htmlspecialchars(t('header.logout'), ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endif; ?>

        </div>
    </div>
</header>
