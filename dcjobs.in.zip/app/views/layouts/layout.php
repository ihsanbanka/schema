<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: layout.php
 * Path: /app/views/layouts/layout.php
 *
 * Software Version : DCJOBS-CORE v1.14.1
 * Phase            : Phase-6 PART-4
 * Component        : Global Layout Wrapper
 *
 * Purpose:
 * --------
 * - Central HTML layout wrapper
 * - Injects global header & footer
 * - Provides consistent structure across app
 *
 * Governance:
 * -----------
 * ✔ Header/Footer separated
 * ✔ Mobile-first
 * ✔ Cross-browser compliant
 * ✔ Auth-agnostic (header handles auth state)
 */

declare(strict_types=1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title><?= htmlspecialchars($pageTitle ?? 'DCJOBS — Credable Creator Economy Job Portal', ENT_QUOTES, 'UTF-8') ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Meta -->
    <meta name="description" content="DCJOBS — Credable Creator Economy Job Portal">
    <meta name="author" content="DCJOBS">

    <!-- Core Application CSS -->
    <link rel="stylesheet" href="/assets/css/app.css">
</head>

<body>

<?php
/**
 * ------------------------------------------
 * GLOBAL HEADER
 * ------------------------------------------
 */
require __DIR__ . '/header.php';
?>

<main class="app-main">
    <div class="container">
        <?php
        /**
         * Inject page-specific content
         */
        echo $content ?? '';
        ?>
    </div>
</main>

<?php
/**
 * ------------------------------------------
 * GLOBAL FOOTER
 * ------------------------------------------
 */
require __DIR__ . '/footer.php';
?>

</body>
</html>
