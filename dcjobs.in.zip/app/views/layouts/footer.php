<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: footer.php
 * Path: /app/views/layouts/footer.php
 *
 * Software Version : DCJOBS-CORE v1.15.0
 * Phase            : Phase-6 PART-4
 * Component        : Global Footer (i18n-ready)
 *
 * Purpose:
 * --------
 * - Global footer for entire application
 * - Consistent branding color (#970747)
 * - Mobile-first & cross-browser compliant
 * - Translation-ready via t()
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ Reusable across entire application
 * ✔ i18n safe (fallback guaranteed)
 */

declare(strict_types=1);
?>

<footer class="app-footer">
    <div class="footer-container">

        <div class="footer-left">
            <?= htmlspecialchars(
                t('footer.copyright', ['year' => date('Y')]),
                ENT_QUOTES,
                'UTF-8'
            ) ?>
        </div>

        <div class="footer-right">
            <a href="/terms"><?= htmlspecialchars(t('footer.terms'), ENT_QUOTES, 'UTF-8') ?></a>
            <a href="/privacy"><?= htmlspecialchars(t('footer.privacy'), ENT_QUOTES, 'UTF-8') ?></a>
            <a href="/contact"><?= htmlspecialchars(t('footer.contact'), ENT_QUOTES, 'UTF-8') ?></a>
        </div>

    </div>
</footer>

<style>
/* =========================================
   GLOBAL FOOTER — DCJOBS STANDARD
   ========================================= */

.app-footer {
    background: #970747;
    color: #ffffff;
    width: 100%;
    margin-top: 60px;
}

.footer-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 18px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
}

.footer-left {
    font-size: 0.85rem;
}

.footer-right {
    display: flex;
    gap: 16px;
}

.footer-right a {
    font-size: 0.85rem;
    color: #ffffff;
    text-decoration: none;
    opacity: 0.9;
}

.footer-right a:hover {
    opacity: 1;
    text-decoration: underline;
}

/* Mobile */
@media (max-width: 640px) {
    .footer-container {
        flex-direction: column;
        text-align: center;
    }

    .footer-right {
        justify-content: center;
        flex-wrap: wrap;
    }
}
</style>
