<?php
declare(strict_types=1);

/**
 * DCJOBS — Dashboard Layout
 * ------------------------------------------------
 * File: dashboard.php
 * Path: /app/views/layouts/dashboard.php
 *
 * Software Version : DCJOBS-CORE v1.15.1
 * Phase            : Phase-6 PART-5
 *
 * UPDATE:
 * -------
 * ✔ Talent "Find Jobs" link corrected to /talent/jobs
 */

/* ---------------------------------
   SAFE CONTEXT RESOLUTION
--------------------------------- */
$userRole  = $userRole  ?? ($_SESSION['persona'] ?? '');
$userEmail = $userEmail ?? ($_SESSION['user_email'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title><?= htmlspecialchars($pageTitle ?? 'Dashboard — DCJOBS', ENT_QUOTES, 'UTF-8') ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Core App CSS -->
    <link rel="stylesheet" href="/assets/css/app.css">

    <!-- Dashboard-only CSS -->
    <link rel="stylesheet" href="/assets/css/dashboard.css">
</head>

<body>

<?php require __DIR__ . '/header.php'; ?>

<div class="dashboard-shell">

    <!-- ================= SIDEBAR ================= -->
    <aside class="dashboard-sidebar">

        <nav class="dashboard-nav">

            <?php if ($userRole === 'talent'): ?>

                <a href="/talent/dashboard" class="nav-link">Dashboard</a>
                <a href="/portfolio" class="nav-link">My Portfolio</a>
                <a href="/talent/jobs" class="nav-link">Find Jobs</a>
                <a href="/applications" class="nav-link">My Applications</a>
                <a href="/messages" class="nav-link">Messages</a>
                <a href="/profile" class="nav-link">My Profile</a>

            <?php else: ?>

                <a href="/dashboard" class="nav-link">Dashboard</a>
                <a href="/dashboard/post-job" class="nav-link">Post a Job</a>
                <a href="/dashboard/manage-jobs" class="nav-link">Manage Jobs</a>
                <a href="/applicants" class="nav-link">Applicants</a>
                <a href="/messages" class="nav-link">Messages</a>

                <?php if ($userRole === 'creator'): ?>
                    <a href="/points" class="nav-link">My Points</a>
                    <a href="/verify-work" class="nav-link">Verify Work</a>
                    <a href="/connect-accounts" class="nav-link">Connect Accounts</a>
                <?php endif; ?>

            <?php endif; ?>

        </nav>

    </aside>

    <!-- ================= MAIN CONTENT ================= -->
    <main class="dashboard-content">
        <?= $content ?? '' ?>
    </main>

</div>

<?php require __DIR__ . '/footer.php'; ?>

</body>
</html>
