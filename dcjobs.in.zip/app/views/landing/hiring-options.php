<?php
declare(strict_types=1);
?>

<section class="landing-hero">
    <div class="container">

        <header class="landing-header">
            <h1>Choose Your Role</h1>
            <p class="subtitle">
                Tell us how you want to use DCJOBS.
            </p>
        </header>

        <div class="role-cards">

            <!-- CREATOR → Google OAuth → Dashboard -->
            <a href="/oauth/google/start?intent=creator" class="role-card">
                <h3>I Am a Creator</h3>
                <p>I create content and collaborate with brands.</p>
            </a>

            <!-- RECRUITER → Existing Auth -->
            <a href="/login" class="role-card">
                <h3>I Am a Company / Recruiter</h3>
                <p>I want to hire creators and talent.</p>
            </a>

        </div>

    </div>
</section>

<style>
.role-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 32px;
    max-width: 900px;
    margin: 60px auto 0;
}
.role-card {
    padding: 36px;
    border: 1px solid #e1e5ef;
    border-radius: 12px;
    text-decoration: none;
    background: #fff;
}
.role-card:hover {
    border-color: #2b6df3;
}
</style>
