<?php
declare(strict_types=1);
?>

<section class="landing-hero">
    <div class="container">

        <header class="landing-header">
            <h1 class="landing-title">Join as a Client or Talent</h1>
            <p class="landing-subtitle">
                Are you here to hire or to find work?
            </p>
        </header>

        <div class="role-cards">

            <!-- HIRE → Screen-2 -->
            <a href="/hire" class="role-card">
                <h3>I Want to Hire</h3>
                <p>Post jobs, find creators, and manage your hiring needs.</p>
            </a>

            <!-- APPLY → Google OAuth → Talent Dashboard -->
            <a href="/oauth/google/start?intent=talent" class="role-card">
                <h3>I Want to Apply</h3>
                <p>Showcase your work, find opportunities, and apply for jobs.</p>
            </a>

        </div>

        <ul class="landing-features">
            <li>✔ Verified opportunities only</li>
            <li>✔ Creator-first hiring</li>
            <li>✔ Transparent & secure platform</li>
            <li>✔ Built for global scale</li>
        </ul>

    </div>
</section>

<style>
.landing-hero {
    padding: 80px 20px;
    background: #f8fafc;
}
.container {
    max-width: 1100px;
    margin: 0 auto;
    text-align: center;
}
.role-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 32px;
    max-width: 900px;
    margin: 0 auto 50px;
}
.role-card {
    padding: 36px;
    border: 1px solid #c7d2fe;
    border-radius: 12px;
    text-decoration: none;
    color: #0f172a;
    background: #fff;
}
.role-card:hover {
    border-color: #2563eb;
    background: #eff6ff;
}
</style>
