<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: index.php
 * Path: /app/views/messages/index.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Shared Features)
 * Component        : Messages Inbox View
 *
 * Purpose:
 * --------
 * - Display unified messages inbox placeholder
 * - Shared across Talent, Creator, Recruiter
 *
 * GOVERNANCE:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No session logic
 * ✔ No role branching
 */

declare(strict_types=1);
?>

<section class="messages-home">

    <div class="messages-card">
        <h1>Messages</h1>

        <p class="subtitle">
            Your conversations with recruiters, creators, and talent will appear here.
        </p>

        <div class="messages-empty">
            <div class="icon">💬</div>
            <h3>No messages yet</h3>
            <p>
                Once you start applying, posting jobs, or collaborating,
                your conversations will show up here.
            </p>
        </div>
    </div>

</section>

<style>
/* ------------------------------
   Messages Inbox — Placeholder
   ------------------------------ */

.messages-home {
    display: flex;
    justify-content: center;
    padding-top: 24px;
}

.messages-card {
    background: #ffffff;
    border-radius: 14px;
    padding: 40px;
    max-width: 900px;
    width: 100%;
    box-shadow: 0 16px 36px rgba(15, 23, 42, 0.08);
}

.messages-card h1 {
    font-size: 1.8rem;
    margin-bottom: 8px;
    color: #0f172a;
}

.subtitle {
    font-size: 0.95rem;
    color: #64748b;
    margin-bottom: 40px;
}

.messages-empty {
    text-align: center;
    padding: 60px 20px;
    border: 2px dashed #e2e8f0;
    border-radius: 14px;
    background: #f8fafc;
}

.messages-empty .icon {
    font-size: 2.5rem;
    margin-bottom: 12px;
}

.messages-empty h3 {
    font-size: 1.1rem;
    margin-bottom: 6px;
    color: #0f172a;
}

.messages-empty p {
    font-size: 0.9rem;
    color: #475569;
    max-width: 420px;
    margin: 0 auto;
}
</style>
