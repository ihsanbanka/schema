<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * -------------------------------------------------
 * File: layout.php
 * Path: /app/views/layout.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Component        : Base Application Layout
 * Phase            : Phase-3 (P3.3)
 *
 * Purpose:
 * --------
 * Provides the base HTML layout wrapper for all rendered views.
 *
 * Design Principles:
 * ------------------
 * ✔ No business logic
 * ✔ No framework dependency
 * ✔ Safe output escaping
 * ✔ Minimal, extensible structure
 *
 * Variables available:
 * --------------------
 * @var string $content  Rendered view content
 * @var array  $data     Optional shared data
 */

declare(strict_types=1);

/**
 * Basic safety fallback
 */
$content = $content ?? '';
$data    = $data ?? [];

$appName = $data['app_name'] ?? 'DCJOBS';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?></title>

    <!-- Future: CSS / Meta / SEO handled via DB-driven config -->
</head>
<body>

    <!-- Application Header -->
    <header>
        <h1><?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?></h1>
    </header>

    <!-- Main Content -->
    <main>
        <?= $content ?>
    </main>

    <!-- Application Footer -->
    <footer>
        <small>&copy; <?= date('Y') ?> <?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?></small>
    </footer>

</body>
</html>
