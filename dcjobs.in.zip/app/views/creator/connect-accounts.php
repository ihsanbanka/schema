<?php
/**
 * DCJOBS — Creator: Connect Accounts
 * --------------------------------------------
 * File: connect-accounts.php
 * Path: /app/views/creator/connect-accounts.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Creator Tools — UI Placeholder)
 *
 * Purpose:
 * --------
 * - Creator-only screen
 * - Placeholder for social account connections
 * - Placeholder for work verification
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No OAuth logic
 * ✔ No API calls
 * ✔ Persona already enforced by controller
 */

declare(strict_types=1);
?>

<section class="creator-tools">

    <header class="creator-header">
        <h1>Connect Your Accounts</h1>
        <p class="subtitle">
            Link your social platforms and verify your work to build trust.
        </p>
    </header>

    <div class="tool-cards">

        <!-- CONNECT ACCOUNTS -->
        <div class="tool-card">
            <h3>Social Accounts</h3>
            <p>
                Connect platforms like YouTube, Instagram, or X to showcase
                your reach and engagement.
            </p>
            <span class="status status-pending">Coming Soon</span>
        </div>

        <!-- VERIFY WORK -->
        <div class="tool-card">
            <h3>Verify Your Work</h3>
            <p>
                Submit proof of work to get verified and unlock premium
                opportunities.
            </p>
            <span class="status status-pending">Coming Soon</span>
        </div>

    </div>

</section>

<style>
/* ---------------------------------
   Creator Tools — Placeholder UI
   --------------------------------- */

.creator-tools {
    max-width: 1100px;
    margin: 40px auto;
    padding: 0 20px;
}

.creator-header {
    margin-bottom: 40px;
}

.creator-header h1 {
    font-size: 2rem;
    margin-bottom: 8px;
    color: #0f172a;
}

.creator-header .subtitle {
    color: #475569;
    font-size: 1.05rem;
}

.tool-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 24px;
}

.tool-card {
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 28px;
    background: #ffffff;
}

.tool-card h3 {
    margin-bottom: 10px;
    font-size: 1.2rem;
    color: #111827;
}

.tool-card p {
    color: #4b5563;
    line-height: 1.6;
    margin-bottom: 16px;
}

.status {
    display: inline-block;
    padding: 6px 12px;
    font-size: 0.8rem;
    border-radius: 999px;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
}
</style>
