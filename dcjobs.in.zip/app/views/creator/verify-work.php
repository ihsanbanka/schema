<?php
/**
 * DCJOBS — Creator: Verify Work
 * --------------------------------------------
 * File: verify-work.php
 * Path: /app/views/creator/verify-work.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Creator Verification — UI Placeholder)
 *
 * Purpose:
 * --------
 * - Creator-only verification screen
 * - Placeholder UI for work verification flow
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No file uploads
 * ✔ No approval logic
 * ✔ Persona enforced upstream
 */

declare(strict_types=1);
?>

<section class="creator-verify">

    <header class="verify-header">
        <h1>Verify Your Work</h1>
        <p class="subtitle">
            Submit proof of your work to become a verified creator on DCJOBS.
        </p>
    </header>

    <div class="verify-steps">

        <div class="verify-card">
            <h3>Step 1: Prepare Proof</h3>
            <p>
                Collect links or documents that demonstrate your professional
                work — portfolios, channels, campaigns, or collaborations.
            </p>
        </div>

        <div class="verify-card">
            <h3>Step 2: Submit for Review</h3>
            <p>
                Upload or link your work for review by the DCJOBS verification
                team.
            </p>
            <span class="status status-pending">Submission Coming Soon</span>
        </div>

        <div class="verify-card">
            <h3>Step 3: Get Verified</h3>
            <p>
                Once approved, your profile will display a verification badge,
                increasing trust and visibility.
            </p>
        </div>

    </div>

</section>

<style>
/* ---------------------------------
   Creator Verify Work — Placeholder
   --------------------------------- */

.creator-verify {
    max-width: 1100px;
    margin: 40px auto;
    padding: 0 20px;
}

.verify-header {
    margin-bottom: 40px;
}

.verify-header h1 {
    font-size: 2rem;
    margin-bottom: 8px;
    color: #0f172a;
}

.verify-header .subtitle {
    color: #475569;
    font-size: 1.05rem;
}

.verify-steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 24px;
}

.verify-card {
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 28px;
    background: #ffffff;
}

.verify-card h3 {
    margin-bottom: 10px;
    font-size: 1.15rem;
    color: #111827;
}

.verify-card p {
    color: #4b5563;
    line-height: 1.6;
    margin-bottom: 14px;
}

.status {
    display: inline-block;
    padding: 6px 12px;
    font-size: 0.8rem;
    border-radius: 999px;
}

.status-pending {
    background: #e0f2fe;
    color: #075985;
}
</style>
