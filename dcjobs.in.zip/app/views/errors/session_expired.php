<?php
declare(strict_types=1);

/**
 * DCJOBS — Session Expired Page
 * ----------------------------
 * Path: /app/views/errors/session_expired.php
 *
 * UI:
 * ---
 * ✔ Header
 * ✔ Footer
 * ✔ Clear user message
 * ✔ Login redirect
 */
?>

<section style="max-width: 640px; margin: 80px auto; text-align: center;">
    <h1 style="font-size: 1.8rem; margin-bottom: 16px;">
        Session Expired
    </h1>

    <p style="color: #6b7280; margin-bottom: 32px;">
        Your session has expired or you are not authorized to access this page.
        Please login again to continue.
    </p>

    <a href="/"
       style="
           display: inline-block;
           padding: 12px 28px;
           background: #2563eb;
           color: #ffffff;
           text-decoration: none;
           border-radius: 8px;
           font-weight: 600;
       ">
        Go to Login
    </a>
</section>
