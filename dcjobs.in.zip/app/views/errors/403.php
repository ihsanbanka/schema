<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: 403.php
 * Path: /app/views/errors/403.php
 *
 * Purpose:
 * --------
 * - Display access denied message
 * - Used when user hits a restricted route
 *
 * Governance:
 * -----------
 * ✔ UI only
 * ✔ No logic
 * ✔ Safe fallback
 */

declare(strict_types=1);
?>

<section class="error-page">
    <div class="error-card">
        <h1>Access Denied</h1>
        <p>
            You don’t have permission to access this page.
        </p>

        <a href="/" class="btn-primary">
            Go back to Home
        </a>
    </div>
</section>

<style>
.error-page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f8fafc;
}

.error-card {
    background: #ffffff;
    padding: 48px;
    border-radius: 14px;
    text-align: center;
    max-width: 420px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
}

.error-card h1 {
    font-size: 1.8rem;
    margin-bottom: 12px;
    color: #0f172a;
}

.error-card p {
    font-size: 0.95rem;
    color: #475569;
    margin-bottom: 24px;
}

.btn-primary {
    display: inline-block;
    padding: 12px 24px;
    background: #2563eb;
    color: #ffffff;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
}
</style>
