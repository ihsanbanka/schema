<?php
declare(strict_types=1);

$jobs      = $jobs ?? [];
$statuses  = $statuses ?? [];
$currentStatus = $currentStatus ?? 'all';
?>

<section class="postjob-container">

<header class="postjob-head">
    <h1>Manage Jobs</h1>
    <p>View and manage your posted jobs.</p>
</header>

<!-- ================= STATUS FILTER ================= -->
<div class="postjob-card">

    <form method="get" action="/dashboard/manage-jobs">
        <div class="form-group">
            <select name="status" onchange="this.form.submit()">

                <!-- Display only -->
                <option value="" disabled selected>
                    Filter Jobs
                </option>

                <!-- All Status -->
                <option value="all"
                    <?= $currentStatus === 'all' ? 'selected' : '' ?>>
                    All Status
                </option>

                <?php foreach ($statuses as $status): ?>
                    <?php if ($status['status_key'] !== 'all'): ?>
                        <option value="<?= htmlspecialchars($status['status_key']) ?>"
                            <?= $currentStatus === $status['status_key'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($status['status_label']) ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>

            </select>
        </div>
    </form>
</div>

<!-- ================= JOB LIST ================= -->
<div class="postjob-card">
    <h2>Your Jobs</h2>

    <?php if (empty($jobs)): ?>
        <p style="color:#6B7280;">No jobs found.</p>
    <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="manage-table">
                <thead>
                    <tr>
                        <th>Job Title</th>
                        <th>Platform</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Applicants</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($jobs as $job): ?>
                    <tr>
                        <td><?= htmlspecialchars($job['job_title']) ?></td>
                        <td><?= htmlspecialchars($job['platform_name']) ?></td>
                        <td><?= htmlspecialchars($job['job_type']) ?></td>
                        <td><?= htmlspecialchars($job['job_status']) ?></td>
                        <td><?= (int)$job['applicant_count'] ?></td>
                        <td>
                            <a href="/dashboard/edit-job?job_id=<?= (int)$job['job_id'] ?>">
                                Edit Job
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

</section>

<style>
.postjob-container{max-width:920px;margin:0 auto;color:#1F2937}
.postjob-head h1{font-size:2rem;margin-bottom:4px}
.postjob-head p{color:#6B7280;margin-bottom:24px}
.postjob-card{background:#FFFFFF;border:1px solid #8B0036;border-radius:16px;padding:24px;margin-bottom:24px}
.form-group{margin-bottom:14px}
select{width:100%;padding:10px;border:1px solid #D1D5DB;border-radius:8px}
.manage-table{width:100%;border-collapse:collapse}
.manage-table th,
.manage-table td{padding:12px;border-bottom:1px solid #E5E7EB;text-align:left}
.manage-table th{background:#F9FAFB;font-weight:600}
.manage-table tr:hover{background:#F3F4F6}
a{text-decoration:none;color:#2563EB;font-weight:600}
</style>
