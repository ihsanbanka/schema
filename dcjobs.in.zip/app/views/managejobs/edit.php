<?php
declare(strict_types=1);

/**
 * DCJOBS — Edit Job View
 * Path: /app/views/managejobs/edit.php
 * Version: v2.2.0 (FULL COMPLETE FILE)
 *
 * ✔ Session validation enforced
 * ✔ Skills properly populated
 * ✔ Company name properly populated
 * ✔ Recruiter company readonly
 * ✔ Dashboard layout compatible
 * ✔ Dynamic Add/Remove Questions
 * ✔ Status dropdown (DB driven)
 * ✔ UI identical to Post Job
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: /error/session-expired');
    exit;
}

$csrfToken = $csrfToken ?? '';
$job       = $job ?? [];
$statuses  = $statuses ?? [];
$questions = $questions ?? [];

$userRole       = $_SESSION['persona'] ?? '';
$sessionCompany = $_SESSION['company_name'] ?? '';

/* =========================================================
   SKILLS RESOLUTION (SAFE)
========================================================= */

$skillsDisplay = '';

if (!empty($job['skills_display'])) {
    $skillsDisplay = $job['skills_display'];
} elseif (!empty($job['skills'])) {

    $decoded = json_decode((string)$job['skills'], true);

    if (is_array($decoded)) {
        $skillsDisplay = implode(', ', $decoded);
    }
}

/* =========================================================
   COMPANY NAME RESOLUTION (SAFE)
========================================================= */

$companyValue = $job['company_name'] ?? '';

if (empty($companyValue) && $userRole === 'recruiter') {
    $companyValue = $sessionCompany;
}
?>

<section class="postjob-container">

<header class="postjob-head">
    <h1>Edit Job</h1>
    <p>Update job details.</p>
</header>

<?php if (!empty($_SESSION['success_message'])): ?>
<div class="postjob-card" style="background:#ECFDF5;border-color:#10B981;">
    <p style="color:#065F46;font-weight:600;">
        <?= htmlspecialchars($_SESSION['success_message'], ENT_QUOTES, 'UTF-8') ?>
    </p>
</div>
<?php unset($_SESSION['success_message']); endif; ?>

<form method="post" action="/dashboard/edit-job/update" novalidate>
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" name="job_id" value="<?= (int)($job['job_id'] ?? 0) ?>">

<!-- ================= JOB DETAILS ================= -->
<div class="postjob-card">
<h2>Job Details</h2>

<div class="form-group">
<label>Job Title</label>
<input type="text"
       value="<?= htmlspecialchars($job['job_title'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
       readonly>
</div>

<div class="form-group">
<label>Skills</label>
<textarea readonly><?= htmlspecialchars($skillsDisplay, ENT_QUOTES, 'UTF-8') ?></textarea>
</div>

<div class="form-group">
<label>Job Type</label>
<select name="job_type" required>
    <option value="Full-Time" <?= ($job['job_type'] ?? '')==='Full-Time'?'selected':'' ?>>Full-Time</option>
    <option value="Part-Time" <?= ($job['job_type'] ?? '')==='Part-Time'?'selected':'' ?>>Part-Time</option>
    <option value="Contract"  <?= ($job['job_type'] ?? '')==='Contract'?'selected':'' ?>>Contract</option>
</select>
</div>

<div class="form-group">
<label>Platform</label>
<input type="text"
       value="<?= htmlspecialchars($job['platform_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
       readonly>
</div>

<div class="form-group">
<label>Job Description</label>
<textarea rows="6" readonly><?= htmlspecialchars($job['job_description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
</div>

</div>

<!-- ================= COMPENSATION ================= -->
<div class="postjob-card">
<h2>Compensation & Logistics</h2>

<div class="form-group">
<label>Company Name</label>
<input type="text"
       name="company_name"
       value="<?= htmlspecialchars($companyValue, ENT_QUOTES, 'UTF-8') ?>"
       <?= $userRole === 'recruiter' ? 'readonly' : '' ?>>
</div>

<div class="form-group">
<label>Salary</label>
<input type="number"
       name="salary"
       step="0.01"
       value="<?= htmlspecialchars((string)($job['salary'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
</div>

<div class="form-group">
<label>Location <span>*</span></label>
<input type="text"
       name="location"
       required
       value="<?= htmlspecialchars($job['location'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
</div>

<div class="form-group horizontal">
<label>Remote Work <span>*</span></label>
<label>
<input type="radio" name="remote_work" value="1"
<?= !empty($job['remote_work']) ? 'checked':'' ?>> Yes
</label>
<label>
<input type="radio" name="remote_work" value="0"
<?= empty($job['remote_work']) ? 'checked':'' ?>> No
</label>
</div>

<div class="form-group">
<label>Status <span>*</span></label>
<select name="job_status" required>
<?php foreach ($statuses as $status): ?>
<option value="<?= htmlspecialchars($status['status_key']) ?>"
<?= ($job['job_status'] ?? '')===$status['status_key']?'selected':'' ?>>
<?= htmlspecialchars($status['status_label']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

</div>

<!-- ================= CUSTOM QUESTIONS ================= -->
<div class="postjob-card">
<h2>Custom Questions</h2>

<div id="questionsContainer">

<?php foreach ($questions as $index => $q): ?>
<div class="form-group question-block">

    <label>Question</label>
    <input type="text"
           name="questions[<?= $index ?>][question]"
           value="<?= htmlspecialchars($q['question'], ENT_QUOTES, 'UTF-8') ?>">

    <div class="form-group">
        <label>Answer Type</label>
        <select name="questions[<?= $index ?>][answer_type]">
            <option value="text" <?= $q['answer_type']==='text'?'selected':'' ?>>Text</option>
            <option value="radio" <?= $q['answer_type']==='radio'?'selected':'' ?>>Yes / No</option>
        </select>
    </div>

    <div class="horizontal">
        <label>
            <input type="checkbox"
                   name="questions[<?= $index ?>][mandatory]"
                   <?= !empty($q['is_required'])?'checked':'' ?>>
            Answer is mandatory
        </label>

        <button type="button"
                class="btn-secondary remove-question">
            Remove
        </button>
    </div>

</div>
<?php endforeach; ?>

</div>

<button type="button" id="addQuestionBtn" class="btn-secondary">
+ Add Question
</button>

</div>

<div class="postjob-actions">
<button type="submit" class="btn-primary">
Save Changes
</button>
</div>

</form>
</section>

<style>
.postjob-container{max-width:920px;margin:0 auto;color:#1F2937}
.postjob-head h1{font-size:2rem;margin-bottom:4px}
.postjob-head p{color:#6B7280;margin-bottom:24px}
.postjob-card{background:#FFFFFF;border:1px solid #8B0036;border-radius:16px;padding:24px;margin-bottom:24px}
.postjob-card h2{color:#1F2937;margin-bottom:16px}
.form-group{margin-bottom:14px}
label{font-weight:600;display:block;margin-bottom:6px}
input,select,textarea{width:100%;padding:10px;border:1px solid #D1D5DB;border-radius:8px}
textarea{resize:vertical}
.horizontal{display:flex;align-items:center;gap:20px}
.btn-primary{background:#2563EB;color:#fff;border:none;padding:12px 28px;border-radius:10px}
.btn-secondary{background:#2563EB;color:#fff;border:none;padding:8px 14px;border-radius:8px}
.postjob-actions{text-align:right;margin-top:24px}
</style>

<script>
let questionIndex = <?= count($questions) ?>;

document.getElementById('addQuestionBtn').addEventListener('click', function () {

    const container = document.getElementById('questionsContainer');

    const block = document.createElement('div');
    block.className = 'form-group question-block';

    block.innerHTML = `
        <label>Question</label>
        <input type="text" name="questions[${questionIndex}][question]">

        <div class="form-group">
            <label>Answer Type</label>
            <select name="questions[${questionIndex}][answer_type]">
                <option value="text">Text</option>
                <option value="radio">Yes / No</option>
            </select>
        </div>

        <div class="horizontal">
            <label>
                <input type="checkbox" name="questions[${questionIndex}][mandatory]">
                Answer is mandatory
            </label>

            <button type="button" class="btn-secondary remove-question">
                Remove
            </button>
        </div>
    `;

    container.appendChild(block);
    questionIndex++;
});

document.addEventListener('click', function(e){
    if(e.target.classList.contains('remove-question')){
        e.target.closest('.question-block').remove();
    }
});
</script>
