<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: index.php
 * Path: /app/views/portfolio/index.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Talent Features)
 * Component        : Talent Portfolio View
 *
 * Purpose:
 * --------
 * - Placeholder for Talent portfolio
 * - Confirms correct routing & persona enforcement
 *
 * GOVERNANCE:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No logic
 * ✔ No role checks
 */

declare(strict_types=1);
?>

<section class="portfolio-home">

    <div class="portfolio-card">
        <h1>My Portfolio</h1>

        <p class="subtitle">
            This is where your work, social profiles, and achievements will appear.
        </p>

        <div class="placeholder-box">
            <p>
                Portfolio setup and content management will be enabled in the next phase.
            </p>
        </div>
    </div>

</section>

<style>
/* ------------------------------
   Talent Portfolio — Placeholder
   ------------------------------ */

.portfolio-home {
    display: flex;
    justify-content: center;
    padding-top: 24px;
}

.portfolio-card {
    background: #ffffff;
    border-radius: 14px;
    padding: 40px;
    max-width: 700px;
    width: 100%;
    box-shadow: 0 16px 36px rgba(15, 23, 42, 0.08);
}

.portfolio-card h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #0f172a;
}

.subtitle {
    font-size: 0.95rem;
    color: #64748b;
    margin-bottom: 26px;
}

.placeholder-box {
    border: 1px dashed #c7d2fe;
    background: #f8fafc;
    padding: 24px;
    border-radius: 10px;
    color: #475569;
    font-size: 0.9rem;
}
</style>
