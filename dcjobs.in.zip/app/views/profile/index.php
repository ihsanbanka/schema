<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: index.php
 * Path: /app/views/profile/index.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Talent Features)
 * Component        : Talent Profile View
 *
 * Purpose:
 * --------
 * - Display Talent profile placeholder
 * - Prepare structure for profile editing
 *
 * GOVERNANCE:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No logic
 * ✔ No role checks
 */

declare(strict_types=1);
?>

<section class="profile-home">

    <div class="profile-card">
        <h1>My Profile</h1>

        <p class="subtitle">
            Manage how creators and recruiters see you on DCJOBS.
        </p>

        <div class="profile-sections">

            <div class="profile-section">
                <h3>Basic Information</h3>
                <p>Name, bio, location, and availability will appear here.</p>
            </div>

            <div class="profile-section">
                <h3>Skills & Expertise</h3>
                <p>Add your skills, tools, and areas of specialization.</p>
            </div>

            <div class="profile-section">
                <h3>Social Platforms</h3>
                <p>YouTube, Instagram, LinkedIn, and other links.</p>
            </div>

            <div class="profile-section">
                <h3>Visibility</h3>
                <p>Control who can view your profile and contact you.</p>
            </div>

        </div>
    </div>

</section>

<style>
/* ------------------------------
   Talent Profile — Placeholder
   ------------------------------ */

.profile-home {
    display: flex;
    justify-content: center;
    padding-top: 24px;
}

.profile-card {
    background: #ffffff;
    border-radius: 14px;
    padding: 40px;
    max-width: 820px;
    width: 100%;
    box-shadow: 0 16px 36px rgba(15, 23, 42, 0.08);
}

.profile-card h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #0f172a;
}

.subtitle {
    font-size: 0.95rem;
    color: #64748b;
    margin-bottom: 30px;
}

.profile-sections {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
}

.profile-section {
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 20px;
    background: #f8fafc;
}

.profile-section h3 {
    margin-bottom: 8px;
    font-size: 1rem;
    color: #0f172a;
}

.profile-section p {
    font-size: 0.85rem;
    color: #475569;
    line-height: 1.5;
}

@media (max-width: 768px) {
    .profile-sections {
        grid-template-columns: 1fr;
    }
}
</style>
