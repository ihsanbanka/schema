<?php
/**
 * DCJOBS — Dashboard Navigation (Shared)
 * --------------------------------------------
 * File: dashboard-nav.php
 * Path: /app/views/partials/dashboard-nav.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3
 * Component        : Shared Dashboard Navigation
 *
 * Purpose:
 * --------
 * - Single navigation menu for all dashboards
 * - Role-aware UI rendering ONLY
 * - Backend persona enforcement happens in controllers
 *
 * GOVERNANCE:
 * -----------
 * ✔ UI only
 * ✔ No DB access
 * ✔ No routing logic
 * ✔ No permission logic
 * ✔ Persona read from session
 */

declare(strict_types=1);

$persona = $_SESSION['persona'] ?? null;
?>

<nav class="dashboard-nav">
    <ul class="nav-list">

        <!-- COMMON -->
        <li><a href="/dashboard">Dashboard</a></li>

        <?php if (in_array($persona, ['creator', 'recruiter'], true)): ?>
            <li><a href="/jobs/create">Post a Job</a></li>
            <li><a href="/jobs/manage">Manage Jobs</a></li>
            <li><a href="/applicants">Applicants</a></li>
            <li><a href="/messages">Messages</a></li>
        <?php endif; ?>

        <?php if ($persona === 'creator'): ?>
            <li><a href="/creator/points">My Points</a></li>
            <li><a href="/verify-work">Verify Work</a></li>
            <li><a href="/connect-accounts">Connect Accounts</a></li>
        <?php endif; ?>

        <?php if ($persona === 'talent'): ?>
            <li><a href="/talent/dashboard">Dashboard</a></li>
            <li><a href="/talent/portfolio">My Portfolio</a></li>
            <li><a href="/jobs">Find Jobs</a></li>
            <li><a href="/applications">My Applications</a></li>
            <li><a href="/profile">My Profile</a></li>
            <li><a href="/messages">Messages</a></li>
        <?php endif; ?>

    </ul>
</nav>

<style>
.dashboard-nav {
    background: #ffffff;
    border-right: 1px solid #e5e7eb;
    padding: 24px;
    min-width: 220px;
}

.nav-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.nav-list li {
    margin-bottom: 14px;
}

.nav-list a {
    text-decoration: none;
    color: #0f172a;
    font-weight: 500;
    font-size: 0.95rem;
}

.nav-list a:hover {
    color: #2563eb;
}
</style>
