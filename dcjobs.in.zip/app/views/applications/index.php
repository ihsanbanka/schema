<?php
/**
 * DCJOBS — Credable Creator Economy Job Portal
 * --------------------------------------------
 * File: index.php
 * Path: /app/views/applications/index.php
 *
 * Software Version : DCJOBS-CORE v1.0.0
 * Phase            : Phase-7.3 (Talent Features)
 * Component        : Talent Applications View
 *
 * Purpose:
 * --------
 * - Display Talent job applications (placeholder)
 * - Confirms correct routing & persona enforcement
 *
 * GOVERNANCE:
 * -----------
 * ✔ UI only
 * ✔ No DB
 * ✔ No logic
 * ✔ No role checks
 */

declare(strict_types=1);
?>

<section class="applications-home">

    <div class="applications-card">
        <h1>My Applications</h1>

        <p class="subtitle">
            Track the jobs you’ve applied for and their current status.
        </p>

        <div class="placeholder-box">
            <p>
                Your submitted job applications will appear here.
            </p>
            <p>
                Status tracking, recruiter responses, and timelines
                will be enabled in the next phase.
            </p>
        </div>
    </div>

</section>

<style>
/* ------------------------------
   Talent Applications — Placeholder
   ------------------------------ */

.applications-home {
    display: flex;
    justify-content: center;
    padding-top: 24px;
}

.applications-card {
    background: #ffffff;
    border-radius: 14px;
    padding: 40px;
    max-width: 700px;
    width: 100%;
    box-shadow: 0 16px 36px rgba(15, 23, 42, 0.08);
}

.applications-card h1 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    color: #0f172a;
}

.subtitle {
    font-size: 0.95rem;
    color: #64748b;
    margin-bottom: 26px;
}

.placeholder-box {
    border: 1px dashed #c7d2fe;
    background: #f8fafc;
    padding: 24px;
    border-radius: 10px;
    color: #475569;
    font-size: 0.9rem;
    line-height: 1.6;
}
</style>
