<?php
declare(strict_types=1);

/**
 * DCJOBS — Stripe Service (FINAL)
 * --------------------------------
 * File: StripeService.php
 * Path: /app/services/StripeService.php
 *
 * Software Version : DCJOBS-CORE v1.2.0
 * Phase            : Payments (Option A)
 *
 * PURPOSE:
 * --------
 * - Create Stripe Checkout Session
 * - NO DB access
 * - NO job activation
 * - Webhook is authoritative
 *
 * GOVERNANCE:
 * -----------
 * ✔ Stateless
 * ✔ Metadata-driven
 * ✔ Shared-hosting safe
 */

namespace DCJOBS\Services;

use DCJOBS\Core\Config;
use RuntimeException;

final class StripeService
{
    /**
     * Create Stripe Checkout Session
     *
     * @param array $data
     * @return string Checkout URL
     */
    public static function createCheckoutSession(array $data): string
    {
        // -------------------------------
        // REQUIRED DATA VALIDATION
        // -------------------------------
        foreach (['user_id', 'job_id', 'product', 'product_type', 'amount'] as $key) {
            if (!isset($data[$key])) {
                throw new RuntimeException('Missing Stripe data: ' . $key);
            }
        }

        // -------------------------------
        // LOAD STRIPE CONFIG (DB-DRIVEN)
        // -------------------------------
        $secretKey = Config::get('stripe_secret_key');
        $successUrl = Config::get('stripe_success_url');
        $cancelUrl  = Config::get('stripe_cancel_url');

        if (!$secretKey || !$successUrl || !$cancelUrl) {
            throw new RuntimeException('Stripe configuration missing');
        }

        // -------------------------------
        // INIT STRIPE
        // -------------------------------
        \Stripe\Stripe::setApiKey($secretKey);

        // -------------------------------
        // CREATE CHECKOUT SESSION
        // -------------------------------
        $session = \Stripe\Checkout\Session::create([
            'mode' => 'payment',

            'payment_method_types' => ['card'],

            'line_items' => [[
                'quantity' => 1,
                'price_data' => [
                    'currency' => 'inr',
                    'unit_amount' => (int) round($data['amount'] * 100),
                    'product_data' => [
                        'name' => $data['product'],
                    ],
                ],
            ]],

            'success_url' => $successUrl,
            'cancel_url'  => $cancelUrl,

            // ---------------------------
            // CRITICAL — METADATA
            // ---------------------------
            'metadata' => [
                'user_id'      => (string) $data['user_id'],
                'job_id'       => (string) $data['job_id'],
                'product'      => (string) $data['product'],
                'product_type' => (string) $data['product_type'],
                'currency'     => 'INR',
                'environment'  => Config::get('app_env') ?? 'production',
            ],
        ]);

        if (!isset($session->url)) {
            throw new RuntimeException('Stripe checkout URL missing');
        }

        return $session->url;
    }
}
