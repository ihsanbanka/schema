<?php
$ch = curl_init('https://www.google.com');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10
]);
$response = curl_exec($ch);
$error    = curl_error($ch);
$code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

var_dump([
    'http_code' => $code,
    'curl_error' => $error,
    'response_ok' => $response !== false
]);
