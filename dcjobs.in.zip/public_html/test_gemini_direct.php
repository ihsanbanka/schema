<?php
$apiKey = 'AIzaSyA7EzANnEZBcuVt5pwg7D1cRDYXpf_xaCA';

$payload = [
    'contents' => [
        [
            'parts' => [
                ['text' => 'Write a one line job description for a Content Creator']
            ]
        ]
    ]
];

$ch = curl_init(
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent'
);

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-goog-api-key: ' . $apiKey
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT => 30
]);

$response = curl_exec($ch);
$error    = curl_error($ch);
$code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<pre>";
var_dump([
    'http_code' => $code,
    'curl_error' => $error,
    'response' => $response
]);
