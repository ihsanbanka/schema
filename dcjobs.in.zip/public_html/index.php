<?php
/**
 * DCJOBS-CORE — Credable Creator Economy Job Portal
 * ------------------------------------------------
 * File: index.php
 * Path: /public_html/index.php
 *
 * Software Version : DCJOBS-CORE v1.1.0
 * Phase            : Phase-3.7 (Front Controller – Production Safe)
 */

declare(strict_types=1);

/**
 * ==========================================================
 * ENVIRONMENT CONFIG
 * ==========================================================
 * DEV  : display_errors = 1
 * PROD : display_errors = 0
 */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);

/**
 * ==========================================================
 * DEFINE APPLICATION ROOT
 * ==========================================================
 */
define('DCJOBS_ROOT', dirname(__DIR__));

/**
 * ==========================================================
 * LOAD BOOTSTRAP
 * ==========================================================
 */
require_once DCJOBS_ROOT . '/app/core/Bootstrap.php';

/**
 * ==========================================================
 * RUN APPLICATION
 * ==========================================================
 */
try {
    DCJOBS\Core\Bootstrap::run();
    DCJOBS\Core\Router::dispatch();
} catch (Throwable $e) {

    /**
     * FAIL SAFE — USER FRIENDLY ERROR
     */
    http_response_code(500);

    if (ini_get('display_errors')) {
        echo nl2br(htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
    } else {
        echo 'Something went wrong. Please try again later.';
    }
}

exit;
