<?php
/**
 * DCJOBS Phase-1 FINAL Smoke Test
 * ------------------------------
 * Validates:
 * - Bootstrap
 * - Autoloader
 * - Database
 * - Config (DB-driven)
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "STEP 1: PHP is running<br>";

// Resolve project root
define('DCJOBS_ROOT', dirname(__DIR__));
echo "STEP 2: ROOT = " . DCJOBS_ROOT . "<br>";

// Define DB bootstrap path
define(
    'DCJOBS_DB_BOOTSTRAP',
    DCJOBS_ROOT . '/secure/db.bootstrap.php'
);

if (!file_exists(DCJOBS_DB_BOOTSTRAP)) {
    die("❌ DB bootstrap file missing<br>");
}
echo "STEP 3: DB bootstrap file found<br>";

// Load Bootstrap (registers autoloader)
require_once DCJOBS_ROOT . '/app/core/Bootstrap.php';
echo "STEP 4: Bootstrap loaded<br>";

// Run Bootstrap
DCJOBS\Core\Bootstrap::run();
echo "STEP 5: Bootstrap run completed<br>";

// IMPORTANT: DO NOT manually include Config.php
// Let autoloader do its job
use DCJOBS\Core\Config;

Config::load();
echo "STEP 6: Config loaded via autoloader<br>";

// Fetch config value
$appName = Config::get('app_name');

echo "STEP 7: APP NAME = " . $appName . "<br>";

echo "✅ PHASE-1 CORE (BOOTSTRAP + DB + CONFIG) VERIFIED";
